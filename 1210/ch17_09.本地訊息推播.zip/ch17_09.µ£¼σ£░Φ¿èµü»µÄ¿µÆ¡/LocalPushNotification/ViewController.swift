import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //初始化本地推播
        let note = UILocalNotification()
        //設定本地推播的內容
        note.alertBody = "你好！"
        note.applicationIconBadgeNumber = 5
        note.soundName = UILocalNotificationDefaultSoundName
        //設定10秒後發送推播訊息
        note.fireDate = NSDate(timeIntervalSinceNow: 10)
        //預約推播
        UIApplication.sharedApplication().scheduleLocalNotification(note)
        //立即推播
//        UIApplication.sharedApplication().presentLocalNotificationNow(note)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

