import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate
{
    var window: UIWindow?
    //記錄當次的推播訊息（主要給App從背景進入前景時使用）
    var currentMessage: String?
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool
    {
        //設定要收到的通知類型
        let setting = UIUserNotificationSettings(forTypes: [.Alert, .Badge, .Sound], categories: nil)
        //註冊通知
        application.registerUserNotificationSettings(setting)
        //如果App在沒啟動的狀態下，點了『推播通知』之後，推播資料將會以launchOptions傳入
        if let remoteNotification = launchOptions?[UIApplicationLaunchOptionsRemoteNotificationKey] as? [NSObject : AnyObject]
        {
            //將推播訊息傳送到進入前景後的推播通知事件
            //注意：缺少此步驟，點『推播通知』後，隨之開啟的App介面上將會無法顯示推播訊息！
            self.application(application, didReceiveRemoteNotification: remoteNotification)
        }
        return true
    }
    
    func application(application: UIApplication, didRegisterUserNotificationSettings notificationSettings: UIUserNotificationSettings)
    {
        //向APNS註冊遠端推播
        application.registerForRemoteNotifications()
    }
    
    //成功註冊了遠端推播時
    func application(application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: NSData)
    {
        print("Token ID：\(deviceToken.description)")
        // 取得設備的TokenID (去除掉不需要的字元)
        let strRange = NSMakeRange(1, deviceToken.description.lengthOfBytesUsingEncoding(NSUTF8StringEncoding)-2)
        var tokenID = (deviceToken.description as NSString).substringWithRange(strRange) as NSString
        //清除TokenID字串中間的空白
        tokenID = tokenID.stringByReplacingOccurrencesOfString(" ", withString: "")
        //清除TokenID字串的前後空白
        tokenID = tokenID.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        //呼叫伺服器端的PHP服務，將移動設備的TokenID記錄下來
        let strURL = String(format: "http://studio-pj.com/class_exercise/register_mobile.php?token_id=%@", tokenID)
        //傳送網址
        let url = NSURL(string: strURL)
        //非同步連接    
        //網路傳輸物件
        let session = NSURLSession.sharedSession()
        //宣告網路任務
        let dataTask = session.dataTaskWithURL(url!) { (echoData, response, error) -> Void in
            //如果伺服器為付費主機，不會傳出額外訊息時
            let strEchoMessage = String(NSString(data: echoData!, encoding: NSUTF8StringEncoding)!)
            //如果伺服器更新成功時，還多傳出其他訊息時，必須做字串擷取
            //            let strEchoMessage = String(NSString(data: echoData, encoding: NSUTF8StringEncoding)!.substringWithRange(NSMakeRange(0, 1)))
            if strEchoMessage == "1" || strEchoMessage == "2"
            {
                print("已經記錄下移動設備的TokenID")
            }
            else
            {
                print("無法成功記錄設備的TokenID")
            }
        }
        //執行網路任務
        dataTask.resume()
    }
    
    //遠端推播註冊失敗時
    func application(application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: NSError)
    {
        print("無法取得Token:\(error.localizedDescription)")
    }
    
    //接收APNs傳來的推播訊息
    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject])
    {
        print("接收到的推播訊息：\(userInfo.description)")
        //擷取推播訊息中的文字欄位
        if let dicAps = userInfo["aps"] as? [NSObject : AnyObject]
        {
            if let strAlert = dicAps["alert"] as? String
            {
                print("推播中alert的內容：\(strAlert)")
                //記錄此次的推播訊息（主要給App從背景進入前景時使用）
                currentMessage = strAlert

                //如果App在前景時，直接將推播訊息顯示在畫面上（App在前景時，不會發出推播的聲音）
                if let vc = window?.rootViewController as? ViewController
                {
                    //當App在前景時
                    if application.applicationState == UIApplicationState.Active
                    {
                        //將訊息傳遞給下一頁的方法
                        vc.showPushMessage(currentMessage)
                    }
                    //當App不在前景時
                    else
                    {
                        //將訊息傳遞給下一頁的變數（讓viewDidAppear顯示推播訊息）
                        vc.pushMessage = currentMessage
                    }
                }
            }
        }
    }
    
    //當應用程式從背景被重新啟動時
    func applicationDidBecomeActive(application: UIApplication)
    {
        //如果App在前景時，直接將推播訊息顯示在畫面上（App在前景時，不會發出推播的聲音）
        if let vc = window?.rootViewController as? ViewController
        {
            print("收到推播時，App-DidBecomeActive：\(currentMessage)")
            //將訊息傳遞給下一頁的方法
            vc.showPushMessage(currentMessage)
            //清除已記錄的推播訊息
            currentMessage = ""
        }
    }
}

