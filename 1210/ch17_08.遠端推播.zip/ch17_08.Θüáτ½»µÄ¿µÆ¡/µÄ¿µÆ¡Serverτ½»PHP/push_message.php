<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>執行訊息推播</title>
</head>
<body>
<?php
//功能說明：將訊息推播給所有已註冊的手機
//傳入參數：alert～訊息
//        sound～聲音
//        badge～標記
    
    //資料庫連線資訊("IP","資料庫帳號","資料庫密碼")
    $conn=mysql_connect("資料庫IP","資料庫帳號","資料庫密碼");
    mysql_query("use 資料庫名稱");      //資料庫名稱
    mysql_query("SET NAMES utf8");

	//宣告用來儲存推播訊息的陣列
	$message['aps'] = array('alert'=>'','badge'=>0,'sound'=>'');
    //接收上一頁（push.html）所輸入的推播訊息
	$alert = $_POST['alert'];
	$badge = $_POST['badge'];
	$sound = $_POST['sound'];
	//準備要送出的訊息
    if( isset($alert) )
    {
        $message['aps']['alert'] = $alert;
	}
	if( isset($badge) )
    {
		$message['aps']['badge'] = intval($badge);
	}
	if( isset($sound) )
    {
		$message['aps']['sound'] = $sound;
	}	
	//轉換為json格式
	$output = json_encode($message);

	//APNS主機與port,正式使用的時候應該使用 gateway.push.apple.com:2195
    $apnsHost = 'ssl://gateway.sandbox.push.apple.com:2195';

	//連線到主機
    $streamContext = stream_context_create();
    stream_context_set_option($streamContext, 'ssl', 'local_cert','apns-dev.pem');
    try
    {
        $apns = stream_socket_client($apnsHost, $error, $errorString, 60,
                                     STREAM_CLIENT_CONNECT, $streamContext);
        //從資料表中取得要推播的TokenID
        $selectSQL = "select token_id from mobile_device";
        $table=mysql_query($selectSQL) or die(mysql_error());
        
        $count = 0;
        while ($row_array=mysql_fetch_row($table))
        {
            //讀取資料表內的token_id欄位值
            $token = $row_array[0];
            //製作推播訊息
            $apnsMessage = chr(0) . chr(0) . chr(32) . pack('H*', $token) . chr(0) . chr(strlen($output)) . $output;
			//將訊息發送到APNs
            $result = fwrite($apns, $apnsMessage);
			//顯示發送狀態
            echo "發送訊息=>" . $token . "=>" . $result . "<br>";
            $count++;
        }
        
		fclose($apns);
		echo "已發送至APNS：" . $output . "<br>（共" . $count . "筆）";
	}
    catch (Exception $e)
    {
        echo "發生錯誤:" . $e;
	}
    //關閉資料庫連線
    mysql_close($conn);
?>
