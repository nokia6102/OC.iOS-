<?php
//功能說明：用來接收iPhone端的Token ID，並且將Token ID記錄到伺服器的資料庫
//傳入參數：token_id（行動裝置的ID）
//PHP回傳值：2表資料已存在，1表資料儲存成功，0表資料儲存失敗，-1表沒有傳入Token ID

    header("Content-type: text/html; charset=utf-8");
    //資料庫連線資訊("IP","資料庫帳號","資料庫密碼")
    $conn=mysql_connect("資料庫IP","資料庫帳號","資料庫密碼");
    mysql_query("use 資料庫名稱");      //資料庫名稱
    mysql_query("SET NAMES utf8");
    
    //取得傳入的tokenID
    $tokenID = $_GET['token_id'];
    
    //時區校正
    date_default_timezone_set('Asia/Taipei');
    
    if($tokenID)
    {
        //檢查tokenID資料是否已儲存於資料表
        $selectSQL = sprintf("select token_id from mobile_device where token_id = '%s'",$tokenID);
        
        $table=mysql_query($selectSQL) or die(mysql_error());
        
        if ($row_array=mysql_fetch_row($table))
        {
            //查詢資料表內已經記錄此tokenID時，回傳2
            echo 2;
        }
        else
        {
            //準備寫入資料表的指令
            $insertSQL = sprintf("insert into mobile_device (token_id,create_time) values ('%s','%s')",$tokenID,date("Y-m-d H:i:s"));
            //執行寫入
            $result=mysql_query($insertSQL) or die(mysql_error());
            //資料寫入成功回傳1，失敗回傳0
            echo $result;
        }
    }
    else
    {
        //沒有傳入Token ID時
        echo -1;
    }
    //關閉資料庫連線
    mysql_close($conn);
?>