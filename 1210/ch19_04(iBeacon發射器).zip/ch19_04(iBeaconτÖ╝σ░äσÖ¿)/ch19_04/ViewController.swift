import UIKit
import CoreLocation
import CoreBluetooth
class ViewController: UIViewController,CBPeripheralManagerDelegate
{
    var peripheralManager:CBPeripheralManager?
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let backgroudQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)
        peripheralManager = CBPeripheralManager(delegate: self, queue: backgroudQueue)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func peripheralManagerDidUpdateState(peripheral: CBPeripheralManager)
    {
        // 先判斷藍牙是否開啟，如果不是藍牙4.x ，也會傳回藍芽未開啟
        if peripheral.state != CBPeripheralManagerState.PoweredOn
        {
            print("藍芽未開啟")
            return
        }
        
        print("準備啟動 beacon")
        peripheral.delegate = self
        
        // uuid可在終端機由uuidgen指令產生
        let uuid = NSUUID(UUIDString: "6533A40F-E5AE-466F-B8FA-815A5B9171D5")
        // 定義要模擬的iBeacon裝置（雖然identifier參數在這裡沒有用處，但不可以填nil）
        let region = CLBeaconRegion(proximityUUID: uuid!, major: 20000, minor: 500, identifier: "com.studio-pj.beacon")
        // 提供給CBPeripheralManager用來當作是iBeacon裝置來廣播的字典物件
        var dict = region.peripheralDataWithMeasuredPower(nil) as Dictionary
        // fakebeacon是當某裝置進行掃描周圍藍牙裝置時會看到的名字 ⬇︎這行看不出明顯作用？
        dict.updateValue("這是模擬的iBeacon裝置", forKey: CBAdvertisementDataLocalNameKey)
        // 開始廣播訊號
        peripheral.startAdvertising(dict as? [String:AnyObject])
    }
}

