import UIKit
import CoreLocation

class MyTableViewController: UITableViewController, CLLocationManagerDelegate
{
    //提供TableView要偵測的iBeacon設備
    var iBeaconDevices = [
        ["uuid":"6533A40F-E5AE-466F-B8FA-815A5B9171D5","major":"20000","minor":"1000","identifier":"com.studio-pj.beacon","status":"確認中..."],
        ["uuid":"6533A40F-E5AE-466F-B8FA-815A5B9171D5","major":"20000","minor":"500","identifier":"com.studio-pj.beacon","status":"確認中..."]]
    
    var locationManager:CLLocationManager!   //注意：定位物件必須為全域變數
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //從AppDelegate取得位置管理員，並且指定在此實作相關的代理方法
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        locationManager = appDelegate.locationManager as CLLocationManager
        locationManager.delegate = self
        //設定要監聽的iBeacon範圍
        let uuid = NSUUID(UUIDString: "6533A40F-E5AE-466F-B8FA-815A5B9171D5")
        let region = CLBeaconRegion(proximityUUID: uuid!, identifier: "com.studio-pj.beacon")
        //設定進出region時，要收到哪些通知
        region.notifyOnEntry = true
        region.notifyOnExit = true
        region.notifyEntryStateOnDisplay = true
        
        locationManager.requestAlwaysAuthorization()
        // 用來得知附近 beacon 的資訊。觸發1號method
        locationManager.startRangingBeaconsInRegion(region)
        // 用來接收進入區域或離開區域的通知。觸發2號與3號method
        locationManager.startMonitoringForRegion(region)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return iBeaconDevices.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("MyCell", forIndexPath: indexPath) as! MyTableViewCell

        // Configure the cell...
        let dic = iBeaconDevices[indexPath.row]
        let uuid = dic["uuid"]!
        let major = dic["major"]!
        let minor = dic["minor"]!
        let identifier = dic["identifier"]!
        let status = dic["status"]!
        cell.lblUUID.text = uuid
        cell.lblMajor.text = major
        cell.lblMinor.text = minor
        cell.lblIdentifier.text = identifier
        cell.lblStatus.text = status
        return cell
    }

    // 1號 method
    func locationManager(manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], inRegion region: CLBeaconRegion)
    {
        //搜尋每一個beacon裝置
        print("\(beacons.count)")
        for beacon in beacons
        {
            let currentBeacon = beacon 
            let uuid = currentBeacon.proximityUUID.UUIDString
            let major = currentBeacon.major.integerValue
            let minor = currentBeacon.minor.integerValue
            //比對beacon資料陣列以更新狀態
            for (arrayIndex,device) in iBeaconDevices.enumerate()
            {
                let deviceMajor = device["major"]!
                let deviceMinor = device["minor"]!
                if device["uuid"] == uuid && Int(device["major"]!)! == major && Int(device["minor"]!)! == minor
                {
                    print("beacon:\(uuid),range:\(deviceMajor)~\(deviceMinor)")
                    var arrayStatus = device["status"]!
                    switch currentBeacon.proximity
                    {
                    case CLProximity.Unknown:
                        print("距離未知,array:\(arrayStatus)")
                        iBeaconDevices[arrayIndex]["status"] = "距離未知"
                        arrayStatus = "距離未知"
                        let notification = UILocalNotification()
                        notification.soundName = "Default"
                        UIApplication.sharedApplication().presentLocalNotificationNow(notification)
                    case CLProximity.Immediate:
                        print("就在旁邊,array:\(arrayStatus)")
                        iBeaconDevices[arrayIndex]["status"] = "就在旁邊"
                        arrayStatus = "就在旁邊"
                    case CLProximity.Near:
                        print("就在附近,array:\(arrayStatus)")
                        iBeaconDevices[arrayIndex]["status"] = "就在附近"
                        arrayStatus = "就在附近"
                    case CLProximity.Far:
                        print("距離有點遠,array:\(arrayStatus)")
                        iBeaconDevices[arrayIndex]["status"] = "距離有點遠"
                        arrayStatus = "距離有點遠"
                    }
                }
            }
        }
        self.tableView.reloadData()
    }
    
    // 2號 method
    func locationManager(manager: CLLocationManager, didEnterRegion region: CLRegion)
    {
        print("進入 \(region.identifier) 區域")
    }
    
    // 3號 method
    func locationManager(manager: CLLocationManager, didExitRegion region: CLRegion)
    {
        print("離開 \(region.identifier) 區域")
        let notification = UILocalNotification()
        notification.userInfo = ["區域": region.identifier]
        notification.alertBody = "離開 \(region.identifier) 區域！"
        notification.soundName = "Default"
        UIApplication.sharedApplication().presentLocalNotificationNow(notification)
    }
}
