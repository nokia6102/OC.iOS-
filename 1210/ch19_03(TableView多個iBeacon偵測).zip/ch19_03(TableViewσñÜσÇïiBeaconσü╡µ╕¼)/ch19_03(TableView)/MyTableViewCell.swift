import UIKit

class MyTableViewCell: UITableViewCell
{
    @IBOutlet weak var lblUUID: UILabel!
    @IBOutlet weak var lblMajor: UILabel!
    @IBOutlet weak var lblMinor: UILabel!
    @IBOutlet weak var lblIdentifier: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()

    }

    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
