//https://developer.apple.com/library/prerelease/ios/documentation/Swift/Conceptual/Swift_Programming_Language/GuidedTour.html#//apple_ref/doc/uid/TP40014097-CH2-ID1

import UIKit

var str = "Hello, playground"
//=====================Simple Values=====================
//由給定值來推測型別
let implicitInteger = 70
let implicitDouble = 70.0
let explicitDouble: Double = 70     //明確指定型別

//---------EXPERIMENT 01---------
let aFloat:Float = 4
//-------------------------------

//沒有隱性型別轉換，不同型別須自行轉型
let label = "The width is "
let width = 94
let widthLabel = label + String(width)  //數字轉型文字

//---------EXPERIMENT 02---------
//去除String()的錯誤訊息
//-------------------------------

//更簡易的方法在字串中插入數值
let apples = 3
let oranges = 5
let appleSummary = "I have \(apples) apples."
let fruitSummary = "I have \(apples + oranges) pieces of fruit."

//---------EXPERIMENT 03---------
let bodyWeight = 60.5
let bodyHeight = 1.7
let name = "Perkin"
print("早安，\(name)！您的BMI值是：\(bodyWeight/(bodyHeight*bodyHeight))")
//-------------------------------
//建立陣列或詞典都是用[]
var shoppingList = ["catfish", "water", "tulips", "blue paint"]
shoppingList[1] = "bottle of water"

var occupations = [
    "Malcolm": "Captain",
    "Kaylee": "Mechanic",       //最後一個元素有逗號也沒關係！
]
occupations["Jayne"] = "Public Relations"  //更改詞典的值

occupations

//陣列與詞典的初始化（指定型別）
let emptyArray = [String]()
let emptyDictionary = [String: Float]()

//當型別可以被推測出來時（譬如：設定第二次設定新值或傳遞參數給某一個函式時），可以不指定型別
shoppingList = []
occupations = [:]

//=====================Control Flow=====================
//判斷式和迴圈的()可以省略，{}部分不可省略！
let individualScores = [75, 43, 103, 87, 12]
var teamScore = 0
for score in individualScores {     //注意：score直接使用不需事先宣告！
    if score > 50 {                 //if判斷是必須是Boolean敘述，不可以寫成 if score { }
        teamScore += 3
    } else {
        teamScore += 1
    }
}
print(teamScore)

//可以組合if與let來檢測optional變數是否有值
var optionalString: String? = "Hello"
print(optionalString == nil)

var optionalName: String? = "John Appleseed"   //測試：var optionalName: String?
var greeting = "Hello!"
//如果optionalName沒有值，就不會執行if內的敘述;如果optionalName有值，會將值拆封(unwrap)後設定給name
//---------EXPERIMENT 04---------
optionalName = nil
//-------------------------------
if let name = optionalName {
    greeting = "Hello, \(name)"     //此處name已經拆封
}
//---------EXPERIMENT 04---------
else {
    greeting
}
//-------------------------------

//使用??來讓nil值的optional變數使用預設值
let nickName: String? = nil
let fullName: String = "John Appleseed"
let informalGreeting = "Hi \(nickName ?? fullName)"  //注意??前後必需空白

//switch支援所有資料型別和各種比對運算（不只限於數字和相等運算），每段也不需使用break結束
let vegetable = "red pepper"
switch vegetable {
case "celery":
    print("Add some raisins and make ants on a log.")
case "cucumber", "watercress":
    print("That would make a good tea sandwich.")
case let x where x.hasSuffix("pepper"):     //hasSuffix檢測字串結尾
    print("Is it a spicy \(x)?")
default:                         //---EXPERIMENT 05---一定要有default
    print("Everything tastes good in soup.")
}

//for-in迴圈可以同時取出詞典中的key與value
let interestingNumbers = [
    "Prime": [2, 3, 5, 7, 11, 13],
    "Fibonacci": [1, 1, 2, 3, 5, 8],
    "Square": [1, 4, 9, 16, 25],
]
var largest = 0
//---------EXPERIMENT 06---------
var largestKind = ""
//-------------------------------
for (kind, numbers) in interestingNumbers {
    print("詞典內容：[\(kind),\(numbers)]")
    //列示value的陣列內容
    for number in numbers {
        if number > largest {
            largest = number
            //---------EXPERIMENT 06---------
            largestKind = kind
            //-------------------------------
        }
    }
}
print(largest)
//---------EXPERIMENT 06---------
print(largestKind)
//-------------------------------

//while迴圈
var n = 2
while n < 100 {
    n = n * 2
}
print(n)
//至少先做一次的do while迴圈，改成repeat while語法
var m = 2
repeat {
    m = m * 2
} while m < 100
print(m)

//使用..<（不含上標）或...（包含上標）來標示for迴圈的執行計數
var firstForLoop = 0
for i in 0..<4 {
    firstForLoop += i
}
print(firstForLoop)
//以下迴圈同上
var secondForLoop = 0
for var i = 0; i < 4; ++i {
    secondForLoop += i
}
print(secondForLoop)

//==================Functions and Closures==================
//**********函式的回傳值標示在後方**********
func greet(name: String, day: String) -> String {
    return "Hello \(name), today is \(day)."
}
greet("Bob", day: "Tuesday")

//---------EXPERIMENT 07---------
func greet1(name: String, lunch: String) -> String {
    return "\(name)你好！今日特餐是\(lunch)."
}
greet1("perkin", lunch: "金牌排骨飯")
//-------------------------------

//**********使用tuple回傳一組資料**********（tuple可以使用名稱或索引值存取）
//此函式接收一個陣列，要找出陣列中最大值與小值，並且計算總和後，以tuple當作函式的回傳值
func calculateStatistics(scores: [Int]) -> (min: Int, max: Int, sum: Int) {
    var min = scores[0]
    var max = scores[0]
    var sum = 0
    
    for score in scores {
        if score > max {
            max = score
        } else if score < min {
            min = score
        }
        sum += score
    }
    //回傳tuple
    return (min, max, sum)
}
let statistics = calculateStatistics([5, 3, 100, 3, 9])
print(statistics.sum)   //使用名稱存取tuple
print(statistics.2)     //使用索引值存取tuple

//**********函式可以接收不定個數的參數**********（該參數實際會存放於陣列中）
func sumOf(numbers: Int...) -> Int {
    var sum = 0
    //迴圈逐一列出參數中的陣列值
    for number in numbers {
        sum += number
    }
    return sum
}
sumOf()             //沒有傳入參數
sumOf(42, 597, 12)  //傳入三個參數後合成一個陣列

//---------EXPERIMENT 08---------
func averageOf(numbers: Int...) -> Float
{
    var sum = 0
    //迴圈逐一列出參數中的陣列值
    for number in numbers {
        sum += number
    }
    return Float(sum) / Float(numbers.count)
}
averageOf(3,5,7,11)
//-------------------------------

//**********可以使用巢狀函式**********
func returnFifteen() -> Int {
    var y = 10
    //定義一個函式內的函式
    func add() {
        y += 5
    }
    add()
    return y
}
returnFifteen()

//**********函式可以當做另一個函式的回傳值**********（注意架構及呼叫方法！）
func makeIncrementer() -> ((Int) -> Int) {
    //定義一個函式內的函式
    func addOne(number: Int) -> Int {
        return 1 + number
    }
    return addOne  //回傳函式
}
//宣告函式變數（這時還不需要參數！）
var increment = makeIncrementer()
increment(7)    //注意：實際使用時，參數會往下傳遞給內部函式！

//------------------以下有助於對上段的理解------------------
func makeIncrementer_1(aNumber:Int) -> ((Int) -> Int) {
    //定義一個函式內的函式
    func addOne(number: Int) -> Int {
        return 1 + number
    }
    return addOne  //回傳函式
}
//宣告函式變數
var increment_1 = makeIncrementer_1(0)
increment_1(7)

//**********函式可以當做另一個函式的參數**********
/*
    函式中的第二個參數，要求必須傳入一個參數（其型別為Int），且回傳值為Bool的函式
    此函式在找出陣列中是否有任何一個元素，可以符合第二個參數的運作邏輯！
*/
//注意：此函式其實只是單純地將『第一個參數』的陣列值，一一傳入『第二個參數』的函式當中，並且依據第二個參數回傳的Bool值再回傳相同的Bool值
func hasAnyMatches(list: [Int], condition: (Int) -> Bool) -> Bool {
    //迴圈列出第一個參數的每一個陣列元素
    for item in list {
        //把每一個陣列元素item代入第二個參數中函式中作為參數
        if condition(item) {  //此處在呼叫參數二的函式！
            return true
        }
    }
    return false
}
//參數2.定義一個lessThanTen函式，其中一個參數的型別為Int，且回傳值是Bool（要當做hasAnyMatches第二個參數）
func lessThanTen(number: Int) -> Bool {
    return number < 10      //作為參數的函式，運作邏輯定義在這裡
}
//參數1.定義一個陣列（要當做hasAnyMatches第一個參數）
var numbers = [20, 19, 7, 12]
//呼叫函式，傳入一個陣列與一個lessThanTen函式
hasAnyMatches(numbers, condition: lessThanTen)

//**********函式就是 Closure **********
//將陣列元素逐一對應到Closure的參數中（注意：numbers.map會回傳一個Closure處理過後的陣列實體）
let newArray = numbers.map({   //『 let newArray = 』是自行加入的！
    (number: Int) -> Int in
    let result = 3 * number
    return result
})
newArray  //顯示對應後由closure計算後的陣列

//---------EXPERIMENT 09---------
//改寫上面的closure，將偶數改成0
let newArray1 = numbers.map({
    (number: Int) -> Int in
    if number%2==0
    {
        return 0
    }
    else
    {
        return number
    }
})
newArray1  //顯示對應後由closure計算後的陣列
//-------------------------------

//-----------以下兩行效果同上段程式-----------
let mappedNumbers = numbers.map({ number in 3 * number })
print(mappedNumbers)

//-----------以Closure來排序陣列-----------
let sortedNumbers = numbers.sort { $0 > $1 }
print(sortedNumbers)

//===============Objects and Classes================
//『屬性』宣告在類別之內與『常數』和『變數』的宣告方式相同；『方法』與『函式』的撰寫方式也相同
class Shape {
    var numberOfSides = 0
    func simpleDescription() -> String {
        return "A shape with \(numberOfSides) sides."
    }
    //---------EXPERIMENT 10---------
    let dimension = "3D"
    func whatKindOfModel() -> String {
        return "這是\(dimension)模型！"
    }
    //-------------------------------
}
var shape = Shape()
shape.numberOfSides = 7
var shapeDescription = shape.simpleDescription()
//---------EXPERIMENT 10---------
shape.whatKindOfModel()
//-------------------------------

//類別的初始化函式（屬性的初始化可以在宣告之時或初始化方法中進行）
class NamedShape {
    var numberOfSides: Int = 0
    var name: String
    
    init(name: String) {
        self.name = name
    }
    
    func simpleDescription() -> String {
        return "A shape with \(numberOfSides) sides."
    }
}

//類別的繼承以冒號分隔（但類別也可以不繼承自任何類別）
class Square: NamedShape {
    var sideLength: Double
    
    init(sideLength: Double, name: String) {
        self.sideLength = sideLength  //要加上self，以區隔與參數相同名稱的內部變數
        super.init(name: name)
        numberOfSides = 4   //父類別屬性
    }
    
    func area() ->  Double {
        return sideLength * sideLength
    }
    //覆寫覆類別的方法時，需標明關鍵字override
    override func simpleDescription() -> String {
        return "A square with sides of length \(sideLength)."
    }
}
let test = Square(sideLength: 5.2, name: "my test square")
test.area()
test.simpleDescription()

//---------EXPERIMENT 11---------
class Circle:NamedShape
{
    var radius:Double
    init(radius:Double,name: String)
    {
        self.radius = radius
        super.init(name: name) //呼叫父類別的初始化方法，將自己收到的name值傳遞給父類別
    }
    func area() -> Double
    {
        return M_PI * radius * radius
    }
    override func simpleDescription() -> String {
        return "\(name)的半徑：\(radius)，面積：\(self.area())"  //說明文字同時呼叫計算圓面積的方法
    }
}
let aCircle = Circle(radius: 5, name: "自訂圓形")
aCircle.simpleDescription()
//-----------------------------

//替『存儲屬性』設定get與set
class EquilateralTriangle: NamedShape {
    var sideLength: Double = 0.0
    
    init(sideLength: Double, name: String) {
        self.sideLength = sideLength   //1.設定屬性
        super.init(name: name)         //2.呼叫父類別的初始化方法
        numberOfSides = 3              //3.變更父類別的屬性值
    }
    //存儲屬性（周邊總長度）
    var perimeter: Double {
        get {
            return 3.0 * sideLength
        }
        set {
            sideLength = newValue / 3.0  //newValue是隱含名稱，set後可以另外明確指定名稱?
        }
    }
    
    override func simpleDescription() -> String {
        return "An equilateral triangle with sides of length \(sideLength)."
    }
}
var triangle = EquilateralTriangle(sideLength: 3.1, name: "a triangle")
print(triangle.perimeter)       //存儲屬性取值
triangle.perimeter = 9.9        //存儲屬性設值
print(triangle.sideLength)

//*******************『計算屬性』用於設定了屬性值之時*******************
//『三角形與正方形類別』內含一個三角形的類別實體與正方形的類別時體，此類別可以確保所設定的三角形之單邊長度和正方形的單邊長度相等
class TriangleAndSquare {
    var triangle: EquilateralTriangle {  //宣告一個繼承自等邊三角形的類別時體（有sideLength『存儲屬性』）
        willSet {       //此處由三角形的初始化函式觸發
            square.sideLength = newValue.sideLength      //三角形的單邊長度，設定給正方形的單邊長度
        }
    }
    var square: Square {                 //宣告一個繼承自等邊正方形的類別時體（有sideLength『一般屬性』）
        willSet {      //此處由正方形的初始化函式觸發
            triangle.sideLength = newValue.sideLength    //正方形的單邊長度，設定給三角形的單邊長度
        }
    }
    init(size: Double, name: String) {   //『三角形與正方形類別』的初始化函式（參數一：size會同時設定給正方形和三角形的單邊長度）
        square = Square(sideLength: size, name: name)                 //初始化正方形的類別實體（觸發square屬性的willSet）
        triangle = EquilateralTriangle(sideLength: size, name: name)  //初始化三角形的類別實體（觸發triangle屬性的willSet）
    }
}
var triangleAndSquare = TriangleAndSquare(size: 10, name: "another test shape")
print(triangleAndSquare.square.sideLength)
print(triangleAndSquare.triangle.sideLength)
triangleAndSquare.square = Square(sideLength: 50, name: "larger square")
print(triangleAndSquare.triangle.sideLength)

//Optional Value的兩種宣告方法（注意?出現的位置）
let optionalSquare: Square? = Square(sideLength: 2.5, name: "optional square")
let sideLength = optionalSquare?.sideLength
//使用Optional Value
optionalSquare!.simpleDescription()
optionalSquare?.simpleDescription()
sideLength!

//======================Enumerations and Structures======================
//**********1.列舉**********
//列舉跟類別和其他型別一樣都可以定義方法
enum Rank: Int {            //列舉撲克牌數字
    case Ace = 1            //指定初始化值，才可以使用.rawValue
    case Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten // 2-10
    case Jack, Queen, King                                    //11-13
    func simpleDescription() -> String {
        switch self {
        case .Ace:
            return "ace"
        case .Jack:
            return "jack"
        case .Queen:
            return "queen"
        case .King:
            return "king"
        default:
            return String(self.rawValue)  //回傳列舉型別所對應的數字
        }
    }
}
let ace = Rank.Ace
let aceRawValue = ace.rawValue

//---------EXPERIMENT 12---------
func compare(rank1: Rank, rank2: Rank) -> String {
    var higher: Rank = rank1
    if rank2.rawValue > rank1.rawValue {
        higher = rank2
    }
    return "兩個列舉型別中比較大的是：\(higher.simpleDescription())"
}
compare(Rank.Nine, rank2: Rank.Queen)
//-------------------------------

//使用列舉型別的初始化函式init?(rawValue:)，利用原始值來產生對應的列舉型別
if let convertedRank = Rank(rawValue: 3) {
    let threeDescription = convertedRank.simpleDescription()
}

//列舉型別可以不用提供原始值(注意：這樣會造成沒有初始化函式init?(rawValue:)，.rawValue屬性也不可使用)
enum Suit:Int {                 //列舉撲克牌花色(此行改寫~加上:Int)
//    case Spades, Hearts, Diamonds, Clubs      (此行改寫成以下兩行)
    case Spades = 0
    case Hearts, Diamonds, Clubs
    func simpleDescription() -> String {
        switch self {
        case .Spades:       //當型別已知時，可以使用點語法存取
//            return "spades"
            return "♠︎"
        case .Hearts:
//            return "hearts"
            return "♥︎"
        case .Diamonds:
//            return "diamonds"
            return "♦︎"
        case .Clubs:
//            return "clubs"  //梅花
            return "♣︎"
        }
    }
    //---------EXPERIMENT 13---------
    func color() -> String {
        switch self {
        case .Spades, .Clubs:
            return "黑"
        case .Hearts, .Diamonds:
            return "紅"
        }
    }
    //-------------------------------
}
let hearts = Suit.Hearts
let heartsDescription = hearts.simpleDescription()
let heartsColor = Suit.Hearts.color() //---EXPERIMENT 13----

//**********2.結構**********
struct Card {  //撲克牌結構
    var rank: Rank  //撲克牌數字列舉型別
    var suit: Suit  //撲克牌花色列舉型別
    func simpleDescription() -> String {  //回傳撲克牌數字和花色
        return "\(suit.simpleDescription())\(rank.simpleDescription())"  //此行調整過
    }
    //--------------EXPERIMENT 14--------------
    //定義型別方法，產生每一張牌的實體，組合成陣列後回傳
    static func fullDeckOfCards () -> [Card]
    {
        var cards = [Card]()
        for i in Suit.Spades.rawValue...Suit.Clubs.rawValue
        {
            if let covertedSuit = Suit(rawValue: i)
            {
                let suit = covertedSuit
                for j in Rank.Ace.rawValue...Rank.King.rawValue
                {
                    if let covertedRank = Rank(rawValue: j)
                    {
                        let rank = covertedRank
                        let card = Card(rank: rank, suit: suit)
                        card.simpleDescription()
                        cards.append(card)
                    }
                }
            }
        }
        return cards
    }
    //------------------------------------------
}
let threeOfSpades = Card(rank: .Three, suit: .Spades)  //傳入參數型別已知，可以使用點語法
let threeOfSpadesDescription = threeOfSpades.simpleDescription()
//--------------EXPERIMENT 14--------------
let fullDeck = Card.fullDeckOfCards()
for card in fullDeck
{
    //叫出所有牌的列印方法
    let someCard = card.simpleDescription()
}
//------------------------------------------

//列舉可以有多個關聯值（但使用同一個rawValue）
enum ServerResponse {
    case Result(String, String)
    case Error(String)
    //--------------EXPERIMENT 15--------------
    case CachedResult(String, String)
    //-----------------------------------------
}

let success = ServerResponse.Result("6:00 am", "8:09 pm")
let failure = ServerResponse.Error("Out of cheese.")
//--------------EXPERIMENT 15--------------
let cached = ServerResponse.CachedResult("一個暫存檔案", "查看暫存資料夾")
//-----------------------------------------

switch success {
    case let .Result(sunrise, sunset):  //替關聯值命名
        print("Sunrise is at \(sunrise) and sunset is at \(sunset).")
    case let .Error(error):
        print("Failure...  \(error)")
    //--------------EXPERIMENT 15--------------
    case let .CachedResult(noIdea, whatImDoing):
        print("從網路下載了\(noIdea)，您現在可以\(whatImDoing).")
    //-----------------------------------------
}

switch cached {
    case let .Result(sunrise, sunset):  //替關聯值命名
        print("Sunrise is at \(sunrise) and sunset is at \(sunset).")
    case let .Error(error):
        print("Failure...  \(error)")
    //--------------EXPERIMENT 15--------------
    case let .CachedResult(noIdea, whatImDoing):
        print("從網路下載了\(noIdea)，您現在可以\(whatImDoing).")
    //-----------------------------------------
}

//===================Protocols and Extensions===================
//定義protocol
protocol ExampleProtocol {
    var simpleDescription: String { get }  //唯讀屬性
    mutating func adjust()                 //可以異動內部屬性的方法（mutating）
}

//類別、列舉、結構都可以引用protocol
class SimpleClass: ExampleProtocol {
    var simpleDescription: String = "A very simple class."  //protocol屬性
    var anotherProperty: Int = 69105
    func adjust() {                //protocol方法（注意：類別中不可加mutating）
        simpleDescription += "  Now 100% adjusted."
    }
}
var a = SimpleClass()
a.adjust()
let aDescription = a.simpleDescription

struct SimpleStructure: ExampleProtocol {
    var simpleDescription: String = "A simple structure"
    mutating func adjust() {
        simpleDescription += " (adjusted)"
    }
}
var b = SimpleStructure()
b.adjust()
let bDescription = b.simpleDescription

//--------------EXPERIMENT 16--------------
enum SimpleEnum: ExampleProtocol {
    case One, Two, Three
    case OneAdjusted, TwoAdjusted, ThreeAdjusted
    
    var simpleDescription: String {
        get {
            var desc = "簡單的列舉型別："
            switch self {
            case .One:
                desc += "<一>"
            case .Two:
                desc += "<二>"
            case .Three:
                desc += "<三>"
            case .OneAdjusted:
                desc += "<一>已調整"
            case .TwoAdjusted:
                desc += "<二>已調整"
            case .ThreeAdjusted:
                desc += "<三>已調整"
            }
            return desc
        }
    }
    
    mutating func adjust() {
        switch self {
        case .One:
            self = OneAdjusted
        case .Two:
            self = TwoAdjusted
        case .Three:
            self = ThreeAdjusted
        default:
            print("已經調整！")
        }
    }
}
var c = SimpleEnum.Three
c.adjust()
c.simpleDescription
//-----------------------------------------

//擴展（等同於OBJC的category）
extension Int: ExampleProtocol {
    var simpleDescription: String {
        return "The number \(self)"
    }
    mutating func adjust() {
        self += 42
    }
}
print(7.simpleDescription)
//以下三行是自行測試的
var i = 58
i.adjust()
print("調整過後是：\(i)")

//--------------EXPERIMENT 17--------------
extension Double {
    var absoluteValue: Double {
        get {
            return fabs(self)
        }
    }
}
let j = -17.0  //let宣告即可！
print(j.absoluteValue)      //有效！
print(-17.0.absoluteValue)  //無效！
//-----------------------------------------

//宣告一個遵循protocol的物件實體，並將物件實體a設定給它
let protocolValue: ExampleProtocol = a
print(protocolValue.simpleDescription)
// print(protocolValue.anotherProperty)  // Uncomment to see the error
// error是因為anotherProperty不是protocol的方法

//===================Generics===================
//使用第二個參數來製成第一個參數的陣列
func repeatItem<Item>(item: Item, numberOfTimes: Int) -> [Item] {
    var result = [Item]()         //宣告泛型陣列
    for _ in 0..<numberOfTimes {
        result.append(item)       //加入泛型陣列
    }
    return result
}
repeatItem("knock", numberOfTimes:4)

//方法、類別、列舉、結構都可以使用泛型
// Reimplement the Swift standard library's optional type
enum OptionalValue<Wrapped> {
    case None
    case Some(Wrapped)
}
var possibleInteger: OptionalValue<Int> = .None
possibleInteger = .Some(100)

/*
泛型名稱之後使用where來指定其需求條件，例如：
要求該型別必需實作protocol
要求兩個型別必需一致
要求一個類別必須繼承自特定的父類別
*/
/*
SequenceType是一種協定，普遍用於Array
遵循此協定的型別T，可以使用T.Generator.Element來檢測其內含物的型別
*/
func anyCommonElements <T: SequenceType, U: SequenceType where T.Generator.Element: Equatable, T.Generator.Element == U.Generator.Element> (lhs: T, _ rhs: U) -> Bool {
    for lhsItem in lhs {
        for rhsItem in rhs {
            if lhsItem == rhsItem {
                return true
            }
        }
    }
    return false
}
anyCommonElements([1, 2, 3], [3])

//--------------EXPERIMENT 18--------------
func anyCommonElements2 <T: SequenceType, U: SequenceType where T.Generator.Element: Equatable, T.Generator.Element == U.Generator.Element> (lhs: T, rhs: U) -> Array<T.Generator.Element> {
    var myArray = Array<T.Generator.Element>()
    for lhsItem in lhs {
        for rhsItem in rhs {
            if lhsItem == rhsItem {
                myArray.append(lhsItem)
            }
        }
    }
    return myArray
}
anyCommonElements2([1, 2, 3], rhs: [3])
//-----------------------------------------
