import UIKit
//import CoreBluetooth
import CoreLocation

class ViewController: UIViewController,CLLocationManagerDelegate
{
    @IBOutlet weak var lblBeacon: UILabel!
    @IBOutlet weak var lblBeaconData: UILabel!
    @IBOutlet weak var lblRegionStatus: UILabel!
    var locationManager:CLLocationManager!   //注意：定位物件必須為全域變數
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //從AppDelegate取得位置管理員，並且指定在此實作相關的代理方法
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        locationManager = appDelegate.locationManager as CLLocationManager
        locationManager.delegate = self
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // 1號 method
    func locationManager(manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], inRegion region: CLBeaconRegion)
    {
        if beacons.count > 0
        {
            // 陣列的第一個 beacon 為最靠近裝置的 beacon
            let beacon = beacons[0] 
            let major = beacon.major.integerValue
            let minor = beacon.minor.integerValue
            let accuracy = beacon.accuracy
            let rssi:Int = beacon.rssi
            switch beacon.proximity
            {
            case CLProximity.Unknown:
                lblBeacon.text = "\(major)~\(minor) 距離未知"
                lblBeaconData.text = "iBeacon設備：\(accuracy)-\(rssi)"
                self.view.backgroundColor = UIColor.grayColor()
                let notification = UILocalNotification()
                notification.alertBody = "離開區域！"
                notification.soundName = "Default"
                UIApplication.sharedApplication().presentLocalNotificationNow(notification)
            case CLProximity.Immediate:
                lblBeacon.text = "\(major)~\(minor) 就在旁邊：\(accuracy)-\(rssi)"
                lblBeaconData.text = "iBeacon設備：\(accuracy)-\(rssi)"
                self.view.backgroundColor = UIColor.greenColor()
            case CLProximity.Near:
                lblBeacon.text = "\(major)~\(minor) 就在附近：\(accuracy)-\(rssi)"
                lblBeaconData.text = "iBeacon設備：\(accuracy)-\(rssi)"
                self.view.backgroundColor = UIColor.cyanColor()
            case CLProximity.Far:
                lblBeacon.text = "\(major)~\(minor) 距離遠：\(accuracy)-\(rssi)"
                lblBeaconData.text = "iBeacon設備：\(accuracy)-\(rssi)"
                self.view.backgroundColor = UIColor.redColor()
            }
        }
    }
    // 2號 method
    func locationManager(manager: CLLocationManager, didEnterRegion region: CLRegion)
    {
        lblRegionStatus.text = "進入 \(region.identifier) 區域"
    }
    // 3號 method
    func locationManager(manager: CLLocationManager, didExitRegion region: CLRegion)
    {
        lblRegionStatus.text = "離開 \(region.identifier) 區域"
        let notification = UILocalNotification()
        notification.userInfo = ["區域": region.identifier]
        notification.alertBody = "離開 \(region.identifier) 區域！"
        notification.soundName = "Default"
        UIApplication.sharedApplication().presentLocalNotificationNow(notification)
    }
    
}

