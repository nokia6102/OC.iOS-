import UIKit

class SearchViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate
{
    @IBOutlet weak var txtQuery: UITextField!
    @IBOutlet weak var dtpStartDate: UIDatePicker!
    @IBOutlet weak var dtpEndDate: UIDatePicker!
    @IBOutlet weak var pkvMaxResults: UIPickerView!
    //網路傳輸物件
    let session = NSURLSession.sharedSession()
    var dataTask:NSURLSessionDataTask!
    //網址字串
    var strURL:String!
    //網址物件
    var url:NSURL!
    //Youtube的API Key
    let apiKey = "AIzaSyD5L9PMlaQNt2iEPu_WiVnq02EZirqWGaU"
    //從Youtube查詢拿到的詞典資料
    var dicSearchResult = Dictionary<NSObject,AnyObject>()
//    var dicSearchResult = [String:AnyObject]()
    //下一頁的畫面
    var listTableViewController:ListTableViewController!
    //查詢資料筆數的陣列
    var arrMaxResults = [String]()
    
    //MARK: View Life Cycle
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //指定pickerView的代理人
        pkvMaxResults.delegate = self
        pkvMaxResults.dataSource = self
        //初始化資料筆數的陣列
        for var i=5;i<=50;i++
        {
            arrMaxResults.append(String(format: "%i", i))
        }
        //加上點按手勢
        let tapGesture = UITapGestureRecognizer(target: self, action: "CloseKeyBoard")
        self.view.addGestureRecognizer(tapGesture)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //正準備轉換頁面
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        //取得下一頁的畫面
        listTableViewController = segue.destinationViewController as! ListTableViewController
        //傳遞查詢結果到下一頁
        listTableViewController.passSearchResult(dicSearchResult)
    }
    
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool
    {
        return false    //不要自動轉頁
    }
    
    //MARK: 自訂函式
    func CloseKeyBoard()
    {
        txtQuery.resignFirstResponder()
    }
    
    //MARK: Target Action
    //查詢按鈕
    @IBAction func btnQuery(sender: UIButton)
    {
        //宣告日期格式化工具並指定格式
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        //取得開始日期
        let strStartDate = dateFormatter.stringFromDate(dtpStartDate.date)
        //製作開始日期擷取範圍
        var range = strStartDate.startIndex ..< strStartDate.startIndex.advancedBy(10)
        //擷取開始日期
        let startDate = strStartDate.substringWithRange(range)
        
        //取得結束日期
        let strEndDate = dateFormatter.stringFromDate(dtpEndDate.date)
        //製作結束日期擷取範圍
        range = strEndDate.startIndex ..< strEndDate.startIndex.advancedBy(10)
        //擷取結束日期
        let endDate = strEndDate.substringWithRange(range)
        //1.處理網址參數
        let strOriginalURL = String(format: "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&order=videoCount&q=%@&maxResults=%i&publishedAfter=%@T00:00:00Z&publishedBefore=%@T00:00:00Z&key=%@", txtQuery.text!,Int(arrMaxResults[pkvMaxResults.selectedRowInComponent(0)])!,startDate,endDate,apiKey)
        print("\(strOriginalURL)")
        //2.處理網址編碼（避免中文亂碼）
        strURL = strOriginalURL.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLFragmentAllowedCharacterSet())
        //3.製作NSURL物件
        url = NSURL(string: strURL)
        //4.制定網路任務
        dataTask = session.dataTaskWithURL(url, completionHandler: { (youtubeData, response, error) -> Void in
            do
            {
                //解出Json格式到詞典
                self.dicSearchResult = try NSJSONSerialization.JSONObjectWithData(youtubeData!, options: []) as! Dictionary<NSObject, AnyObject>
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    //轉到下一頁
                    self.performSegueWithIdentifier("ShowList", sender: nil)
                })
            }
            catch
            {
                print("error!")
            }
        })
        //5.執行網路任務
        dataTask.resume()
    }
    
    //MARK: UIPickerViewDataSource and UIPickerViewDelegate
    //滾輪數量
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 1
    }
    //可以滾動的資料行數
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return arrMaxResults.count
    }
    //準備每一個滾輪上顯示的資料
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView
    {
        
        let myView = UILabel(frame: CGRect(x: 0, y: 0, width: pickerView.frame.size.width, height: pickerView.frame.size.height))
        myView.text = arrMaxResults[row]
        myView.textAlignment = NSTextAlignment.Right
        myView.font = UIFont.systemFontOfSize(18)
        return myView
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}
