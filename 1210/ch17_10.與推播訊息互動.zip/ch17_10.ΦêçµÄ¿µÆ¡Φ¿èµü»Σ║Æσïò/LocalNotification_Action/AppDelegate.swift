import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate
{
    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool
    {
        //建立四個顯示於通播通知上的互動按鈕（這些按鈕必須封裝於UIMutableUserNotificationCategory類別中）
        let action1 = UIMutableUserNotificationAction()
        action1.identifier = "ACTION_1"     //識別使用者點選了哪一個按鈕
        action1.title = "Title1"            //按鈕文字
        action1.activationMode = UIUserNotificationActivationMode.Foreground    //按下按鈕後，是否要將App轉到前景
        action1.authenticationRequired = true   //當在鎖定狀態時，是否要先解鎖
        action1.destructive = false             //是否以紅色來提醒使用者，當按下此按鈕會有比較重大的影響
        
        let action2 = UIMutableUserNotificationAction()
        action2.identifier = "ACTION_2"
        action2.title = "Title2"
        action2.activationMode = UIUserNotificationActivationMode.Background
        action2.authenticationRequired = false
        action2.destructive = true
        
        let action3 = UIMutableUserNotificationAction()
        action3.identifier = "ACTION_3"
        action3.title = "Title3"
        action3.activationMode = UIUserNotificationActivationMode.Background
        action3.authenticationRequired = false
        action3.destructive = false
        
        let action4 = UIMutableUserNotificationAction()
        action4.identifier = "ACTION_4"
        action4.title = "Title4"
        action4.activationMode = UIUserNotificationActivationMode.Background
        action4.authenticationRequired = false
        action4.destructive = false
        
        // UIUserNotificationActionContextDefault 最多可指定4個action，
        //     並且可在「解鎖後的提示樣式」的「提示」中顯示，參考「設定」->「通知」->此App
        // UIUserNotificationActionContextMinimal 最多可指定2個action，
        //     無法顯示於「解鎖後的提示樣式」的「提示」
        
        //宣告用來封裝四個互動按鈕的分類（Category）
        let category = UIMutableUserNotificationCategory()
        category.identifier = "CATEGORY"    //封裝分類的識別ID  PS.一個App可以有多組分類（Category）供推播時選擇（此例只使用一個）
        category.setActions([action1, action2, action3, action4], forContext: UIUserNotificationActionContext.Default)
        let categories = NSSet(objects: category)   //可以將多個封裝類別利用NSSet包裝，之後加入到UIUserNotificationSettings當中
        //注意最後一個參數要填入NSSet封裝後的categories
        let types: UIUserNotificationType = [UIUserNotificationType.Badge, UIUserNotificationType.Alert, UIUserNotificationType.Sound]
        let setting = UIUserNotificationSettings(forTypes: types, categories: categories as? Set<UIUserNotificationCategory>)
        application.registerUserNotificationSettings(setting)
        return true
    }
    //實作互動按鈕按下後所觸發的方法
    func application(application: UIApplication, handleActionWithIdentifier identifier: String?, forLocalNotification notification: UILocalNotification, completionHandler: () -> Void)
    {
        if (notification.category == "CATEGORY")
        {
            if (identifier == "ACTION_1")
            {
                NSLog("點選了Category1, Action1")
            }
            
            if (identifier == "ACTION_2")
            {
                //清除小紅圈
                UIApplication.sharedApplication().applicationIconBadgeNumber = 0
                NSLog("點選了Category1, Action2")
            }
            
            if (identifier == "ACTION_3")
            {
                NSLog("點選了Category1, Action3")
            }
            
            if (identifier == "ACTION_4")
            {
                NSLog("點選了Category1, Action4")
            }
        }
        //此行一定要呼叫
        completionHandler();
    }

    func applicationWillResignActive(application: UIApplication)
    {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication)
    {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication)
    {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication)
    {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication)
    {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
}

