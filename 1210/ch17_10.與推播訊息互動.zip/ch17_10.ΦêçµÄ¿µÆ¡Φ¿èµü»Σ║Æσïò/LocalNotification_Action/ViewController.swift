import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //設定本地通知
        let note = UILocalNotification()
        note.alertBody = "自訂Action通知"
        note.applicationIconBadgeNumber = 1
        note.category = "CATEGORY"  //指定推播使用的封裝分類
        note.soundName = UILocalNotificationDefaultSoundName
        
        //設定10秒後發送
        note.fireDate = NSDate(timeIntervalSinceNow: 10)
        
        UIApplication.sharedApplication().scheduleLocalNotification(note)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

