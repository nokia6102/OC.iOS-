import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate
{
    var window: UIWindow?
    var db:COpaquePointer = nil  //注意：這裏只能設為nil，不可使用！或？
    //回傳資料庫指標
    func getDB() -> COpaquePointer
    {
        return db
    }

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool
    {
        //宣告檔案管理員
        let fm = NSFileManager()
        //取得資料庫在專案中的路徑
        let src = NSBundle.mainBundle().pathForResource("mydb", ofType: "sqlite")
        //取得要複製過去的目的地路徑
        let dst = NSString(format: "%@/Documents/mydb.sqlite", NSHomeDirectory())
        //檢查目的地檔案是否存在，如果不存在則複製檔案
        if !fm.fileExistsAtPath(dst as String)
        {
            do {
                try fm.copyItemAtPath(src!, toPath: dst as String)
            } catch _ {
            }
        }
        //與資料庫連線，並將結果存入db變數中
        if sqlite3_open(dst.UTF8String, &db) != SQLITE_OK
        {
            db = nil
            print("資料庫連線失敗")
        }
        else
        {
            print("資料庫連線成功")
        }
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication)
    {
        //關閉資料庫連線
        sqlite3_close(db)
    }


}

