import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate
{
    @IBOutlet weak var txtIid: UITextField!
    @IBOutlet weak var txtCname: UITextField!
    @IBOutlet weak var imgPicture: UIImageView!

    //圖片挑選器
    var imgPicker:UIImagePickerController!
    //資料庫指標
    var db:COpaquePointer = nil
    //記錄單一資料行
    var dicRow = [String:String]()
    //記錄資料表資料（不含圖片）
    var arrTable = [[String:String]]()
    //記錄圖片
    var arrPicture = [NSData]()
    //記錄目前資料列
    var currentRow = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //從AppDelegate中取得資料庫連線
        let delegate = UIApplication.sharedApplication().delegate as! AppDelegate
        db = delegate.getDB()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //查詢按鈕
    @IBAction func btnQuery(sender: UIButton)
    {
        //陣列先清空
        arrTable = [[String:String]]()
        arrPicture = [NSData]()
        
        if db != nil
        {
            //準備查詢用的SQL
            let sql = "select * from UserData"
            //將查詢指令轉成C語言的字串
            let cSql = sql.cStringUsingEncoding(NSUTF8StringEncoding)
            //宣告儲存查詢結果的變數
            var statement:COpaquePointer = nil
            //準備查詢(第三個參數若為正數，則指cSql可用的最大長度;若為負數，則不限定長度)
            sqlite3_prepare(db, cSql!, -1, &statement, nil)
            //利用迴圈取出查詢結果
            var i = 0
            while sqlite3_step(statement) == SQLITE_ROW
            {
                //讀取第一個欄位
                let iid = sqlite3_column_text(statement, 0)
                //將第一個欄位從C語言的字串轉回String
                let strIid = String.fromCString(UnsafePointer<CChar>(iid))!
                //將第一個欄位存入字典
                dicRow["iid"] = strIid
                
                //讀取第二個欄位
                let cname = sqlite3_column_text(statement, 1)
                //將第二個欄位從C語言的字串轉回String
                let strCname = String.fromCString(UnsafePointer<CChar>(cname))!
                //將第二個欄位存入字典
                dicRow["cname"] = strCname
                //將字典存入陣列
                arrTable.append(dicRow)
                
                //讀取第三個欄位
                let length = sqlite3_column_bytes(statement, 2)
                let totalBytes = sqlite3_column_blob(statement, 2)
                let imgData = NSData(bytes: totalBytes, length: Int(length))
                //將第三個欄位存入圖片陣列
                arrPicture.append(imgData)
                
                //第一筆資料直接顯示
                if i == 0
                {
                    txtIid.text = strIid
                    txtCname.text = strCname
                    //將圖片放到image元件中
                    imgPicture.image = UIImage(data: imgData)
                }
                //資料庫指標加一
                i++
            }
            print("\(arrTable)")
            //使用完畢，釋放statement
            sqlite3_finalize(statement)
        }
    }
    //新增按鈕
    @IBAction func btnInsert(sender: UIButton)
    {
        //不允許空白
        if txtIid.text == "" || txtCname.text == ""
        {
            return
        }
        if db != nil
        {
            //準備要存入的照片
            let imgData = UIImageJPEGRepresentation(imgPicture.image!, 1)
            //準備Insert SQL
            let sql = String(NSString(format: "insert into UserData values('%@','%@',?)", txtIid.text!,txtCname.text!))
            //將Insert指令轉成C語言的字串
            let cSql = sql.cStringUsingEncoding(NSUTF8StringEncoding)
            //宣告儲存執行結果的變數
            var statement:COpaquePointer = nil
            //準備執行(第三個參數若為正數，則指cSql可用的最大長度;若為負數，則不限定長度)
            sqlite3_prepare(db, cSql!, -1, &statement, nil)
            //將照片存入資料庫（將NSData綁定到insert語法中?的地方）注意：？位置是從1起算
            sqlite3_bind_blob(statement, CInt(1), imgData!.bytes, CInt(imgData!.length), nil)
            //如果執行Insert指令成功
            if sqlite3_step(statement) == SQLITE_DONE
            {
                let alert = UIAlertController(title: "資料庫訊息", message: "資料新增成功！", preferredStyle: UIAlertControllerStyle.Alert)
                alert.addAction(UIAlertAction(title: "確定", style: UIAlertActionStyle.Default, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)
            }
            else
            {
                let alert = UIAlertController(title: "資料庫訊息", message: "資料新增失敗！", preferredStyle: UIAlertControllerStyle.Alert)
                alert.addAction(UIAlertAction(title: "確定", style: UIAlertActionStyle.Default, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)
            }
            //使用完畢，釋放statement
            sqlite3_finalize(statement)
        }
    }
    //更換圖片
    @IBAction func btnChangePicture(sender: UIButton)
    {
        //初始化imgPicker
        imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        //指定使用相簿
        imgPicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        //        imgPicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum
        //允許裁切照片
        imgPicker.allowsEditing = true
        //開啟相簿
        self.presentViewController(imgPicker, animated: true, completion: nil)
    }
    
    //MARK: UIImagePickerControllerDelegate
    //選定圖片之後
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!)
    {
        //顯示圖片
        imgPicture.image = image
        //退掉圖片挑選畫面
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            //清除imgPicker
            self.imgPicker = nil
        })
    }
    //上一筆
    @IBAction func btnPrevious(sender: UIButton)
    {
        if currentRow - 1 >= 0
        {
            currentRow--
            txtIid.text = arrTable[currentRow]["iid"]
            txtCname.text = arrTable[currentRow]["cname"]
            imgPicture.image = UIImage(data: arrPicture[currentRow])
        }
    }
    //下一筆
    @IBAction func bntNext(sender: UIButton)
    {
        if currentRow + 1 < arrTable.count
        {
            currentRow++
            txtIid.text = arrTable[currentRow]["iid"]
            txtCname.text = arrTable[currentRow]["cname"]
            imgPicture.image = UIImage(data: arrPicture[currentRow])
        }
    }
}

