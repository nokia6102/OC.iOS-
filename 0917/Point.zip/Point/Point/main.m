#import <Foundation/Foundation.h>
#import "Coordinate.h"
#import "Circle.h"
#import "Retangle.h"
//13.3範例
//================Main================
int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        Coordinate *obj = [Coordinate new];     //[[Coordinate alloc] init]
        //利用getter列印
        NSLog(@"(%i,%i)",[obj x],[obj y]);
        //利用類別的列印方法
        [obj print];
        Coordinate *obj1 = [Coordinate new];
        Coordinate *obj2 = [[Coordinate alloc] initWithX:50 andY:50];
        [obj1 setX:150];
        [obj1 setY:250];
        //『點語法』在設定完setter和getter之後就生效
        NSLog(@"********%i",obj1.x);
        obj1.x = 999;
        //列印
        [obj1 print];
        
        //初始化帶值
        [obj2 print];
        [obj2 setX:100];
        [obj2 setY:200];
        //設值之後
        [obj2 print];
        
        NSLog(@"****************************************************");
        
        Circle *objCir = [[Circle alloc] init];
        objCir.radius = 10;
        NSLog(@"圓心：(%i,%i),半徑：%i,圓面積：%f",objCir.x,objCir.y,objCir.radius,[objCir area]);
        
        Circle *objCir1 = [[Circle alloc] initWithX:30 andY:30 andRadius:5];
        NSLog(@"圓心：(%i,%i),半徑：%i,圓面積：%f",objCir1.x,objCir1.y,objCir1.radius,[objCir1 area]);
        
        NSLog(@"****************************************************");
        Rectangle *objRec = [Rectangle new];
        [objRec setX:20 andY:20];
        [objRec setM:50 andN:60];
        
        NSLog(@"在(%i,%i)與(%i,%i)之間的矩形面積：%i,寬：%i,高：%i",objRec.x,objRec.y,objRec.m,objRec.n,[objRec area],objRec.width,objRec.height);
        
        Rectangle *objRec1 = [[Rectangle alloc] initWithM:35 andN:59 andX:3 andY:7];
        NSLog(@"在(%i,%i)與(%i,%i)之間的矩形面積：%i,寬：%i,高：%i",objRec1.x,objRec1.y,objRec1.m,objRec1.n,[objRec1 area],objRec1.width,objRec1.height);
    }
    return 0;
}
