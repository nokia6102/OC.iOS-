#import "Retangle.h"

@implementation Rectangle

@synthesize m,n,width,height;

//類別的基本初始化方法
-(Rectangle *)init
{
    self = [super init];
    if (self)
    {
        m = 1;
        n = 1;
        width = 1;
        height = 1;
    }
    return self;
}
//類別帶參數的初始化方法
-(Rectangle *)initWithM:(int)a andN:(int)b andX:(int)c andY:(int)d
{
    self = [super init];
    if (self)
    {
        m = a;
        n = b;
        x = c;
        y = d;
        width = 1;
        height = 1;
    }
    return self;
}

//設定斜對角的點(x,y)的方法
-(void)setX:(int)p andY:(int)q
{
    x = p;
    y = q;
}
//設定斜對角的點(m,n)的方法
-(void)setM:(int)a andN:(int)b
{
    m = a;
    n = b;
}

//計算矩形面積的方法
-(int)area
{
    //先利用兩個斜對角的點，來計算出矩形的寬和高
    width = abs(x-m);
    height = abs(y-n);
    return width*height;
}

@end
