#import <Foundation/Foundation.h>
#import "Circle.h"
#import "Coordinate.h"
#import "Retangle.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        Rectangle *objRec = [[Rectangle alloc] initWithM:50 andN:60 andX:20 andY:20];
        Circle *objCir = [[Circle alloc] initWithX:5 andY:10 andRadius:8];
        Coordinate *objCoord = [Coordinate new];
        
        NSLog(@"方形面積：%i",[objRec area]);
        NSLog(@"圓形面積：%f",[objCir area]);
        
        id shape;
        shape = objCir;
        
        if ([shape isMemberOfClass:[Circle class]])
        {
            NSLog(@"我是圓形類別");
        }
        else
        {
            NSLog(@"我不是圓形類別");
        }
        if ([shape isMemberOfClass:[Coordinate class]])
        {
            NSLog(@"我是座標類別");
        }
        else
        {
            NSLog(@"我不是座標類別");
        }
        if ([shape isKindOfClass:[Coordinate class]])
        {
            NSLog(@"我是座標的衍生類別");
        }
        else
        {
            NSLog(@"我不是座標的衍生類別");
        }
        if ([Circle isSubclassOfClass:[Rectangle class]])
        {
            NSLog(@"圓形類別是方形的子類別");
        }
        else
        {
            NSLog(@"圓形類別不是方形的子類別");
        }
        if ([Circle isSubclassOfClass:[Coordinate class]])
        {
            NSLog(@"圓形類別是座標的子類別");
        }
        else
        {
            NSLog(@"圓形類別不是座標的子類別");
        }
        
        
        NSLog(@"************************************************");
        shape = objRec;
        if ([shape isMemberOfClass:[Rectangle class]])
        {
            NSLog(@"我是方形類別");
        }
        else
        {
            NSLog(@"我不是方形類別");
        }
        if ([shape isMemberOfClass:[Coordinate class]])
        {
            NSLog(@"我是座標類別");
        }
        else
        {
            NSLog(@"我不是座標類別");
        }
        if ([shape isKindOfClass:[Coordinate class]])
        {
            NSLog(@"我是座標的衍生類別");
        }
        else
        {
            NSLog(@"我不是座標的衍生類別");
        }
        //Selector = Method
        if ([Rectangle instancesRespondToSelector:@selector(area)])
        {
            NSLog(@"方形類別的實體能夠回應area方法");
        }
        else
        {
            NSLog(@"方形類別的實體不能回應area方法");
        }
        if ([Rectangle instancesRespondToSelector:@selector(printWho)])
        {
            NSLog(@"方形類別的實體能夠回應xyz方法");
        }
        else
        {
            NSLog(@"方形類別的實體不能回應xyz方法");
        }
        
        if ([shape respondsToSelector:@selector(setM:andN:)])
        {
            NSLog(@"方形能夠回應setMSetN");
            [shape setM:30 andN:10];
        }
        else
        {
            NSLog(@"方形不能回應setMSetN");
        }
        NSLog(@"************************************************");
        
        if ([shape respondsToSelector:@selector(printWho)])
        {
//            [shape performSelector:@selector(printWho)];
            [shape printWho];
        }
        
    }
    return 0;
}
