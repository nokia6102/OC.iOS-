#import "Circle.h"
@implementation Circle

@synthesize radius;  //此處可省略！

//類別的初始化方法
-(Circle *)init
{
    //(x,y) = (1,1)
    self = [super init];
    if (self)
    {
        radius = 1;
    }
    return self;
}

//類別的初始化方法(含圓心與半徑)
-(Circle *)initWithX:(int)a andY:(int)b andRadius:(int)r
{
    self = [super init];
    if (self)
    {
        x = a;
        y = b;
        radius = r;
    }
    return self;
}

//計算圓面積
-(double)area
{
    return (M_PI*self.radius*self.radius);
}

//自訂radius的setter
-(void)setRadius:(int)r
{
    radius = r;
}

//自訂radius的getter
-(int)radius
{
    return radius;
}
//類別方法
-(void)printWho
{
    NSLog(@"這是圓形類別");
}

@end
