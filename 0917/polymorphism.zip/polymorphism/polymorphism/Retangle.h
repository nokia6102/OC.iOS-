#import "Coordinate.h"

@interface Rectangle : Coordinate
{
    //矩形斜對角的點(x,y)及(m,n)
    int m,n;
    //矩形的寬和高
    int width,height;
}
@property int m,n;
@property int width,height;
//設定斜對角點(x,y)的方法
-(void)setX:(int)p andY:(int)q;
//設定斜對角點(m,n)的方法
-(void)setM:(int)a andN:(int)b;
//計算矩形面積的方法
-(int)area;
//類別的初始化方法
-(Rectangle *)init;
-(Rectangle *)initWithM:(int)a andN:(int)b andX:(int)c andY:(int)d;
//類別方法
-(void)printWho;
@end
