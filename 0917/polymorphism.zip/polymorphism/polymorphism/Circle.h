#import "Coordinate.h"
//圓形類別直接繼承自座標類別（含x,y當作圓心）
@interface Circle : Coordinate
//此處可省略！
{
    int radius;     //圓半徑屬性
}
@property int radius;
//計算圓面積
-(double)area;
//自訂radius的setter
-(void)setRadius:(int)r;
//自訂radius的getter
-(int)radius;
//類別的初始化方法
-(Circle *)init;
//類別的初始化方法(含圓心與半徑)
-(Circle *)initWithX:(int)a andY:(int)b andRadius:(int)r;
//類別方法
-(void)printWho;

@end
