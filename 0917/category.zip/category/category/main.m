#import <Foundation/Foundation.h>
#import "Coordinate.h"
#import "MathOperation.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //座標：(1,1)
        Coordinate *obj1 = [[Coordinate alloc] init];
        //座標：(2,3)
        Coordinate *obj2 = [[Coordinate alloc] initWithX:2 andY:3];
        NSLog(@"第一次設定後");
        NSLog(@"obj1:(%i,%i)",obj1.x,obj1.y);
        NSLog(@"obj2:(%i,%i)",obj2.x,obj2.y);
        
        //呼叫類別的擴充方法(類目)
        [obj1 add:obj2];
        NSLog(@"加法運算後");
        NSLog(@"obj1:(%i,%i)",obj1.x,obj1.y);
        NSLog(@"obj2:(%i,%i)",obj2.x,obj2.y);
        
        //呼叫類別的擴充方法(類目)
        [obj2 substract:obj1];
        NSLog(@"減法運算後");
        NSLog(@"obj1:(%i,%i)",obj1.x,obj1.y);
        NSLog(@"obj2:(%i,%i)",obj2.x,obj2.y);
    }
    return 0;
}
