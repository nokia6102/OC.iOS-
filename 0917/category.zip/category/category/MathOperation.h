#import "Coordinate.h"

//===============類目宣告區===============
@interface Coordinate (MathOperation)
//點與點的加法
-(void)add:(Coordinate *)c;
//點與點的減法
-(void)substract:(Coordinate *)d;
@end
