#import "MathOperation.h"

//===============類目實作區===============
@implementation Coordinate (MathOperation)
//點與點的加法
-(void)add:(Coordinate *)c
{
    x = x + c.x;
    y = y + c.y;
}
//點與點的減法
-(void)substract:(Coordinate *)d
{
    x = x - d.x;
    y = y - d.y;
}

@end
