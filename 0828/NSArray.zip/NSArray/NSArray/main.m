#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //##############不可變更的陣列物件(19.3.1)##############
        //Part1.製作不可變更陣列
        NSString *str1,*str2,*str3;
        str1 = @"How";
        str2 = @"are";
        str3 = @"you";
        //宣告NSArray並使用類別方法填入陣列值
        NSArray *arr;
//        arr = [NSArray arrayWithObjects:str1,str2,str3, nil];
        arr = @[str1,str2,str3];    //陣列初始化的簡化方法
        //印出NSArray的陣列元素
        for (int i=0; i<arr.count; i++)
        {
            NSLog(@"[%i]:%@",i,arr[i]);
        }
        //Part2.搜尋陣列中的字串
        NSString *find = @"You!";
        NSUInteger index;
        index = [arr indexOfObject:find];
        if (index != NSNotFound)
        {
            NSLog(@"陣列中儲存\"%@\"的位置%li",arr[index],index);
        }
        else
        {
            NSLog(@"陣列中找不到字串：%@",find);
        }
        NSLog(@"********************************************");
        //##############可變更的陣列物件(19.3.2)##############
        //Part1.製作可變更陣列
        NSMutableArray *mArr;
//        mArr = [[NSMutableArray alloc] init];
        mArr = [NSMutableArray new];    //簡化寫法
        [mArr addObject:[NSNumber numberWithInt:5]];
        [mArr addObject:[NSNumber numberWithInt:7]];
        [mArr addObject:[NSNumber numberWithInt:1]];
        for (int i=0; i<mArr.count; i++)
        {
            NSLog(@"<排序前>[%i]:%@",i,mArr[i]);
        }
        NSLog(@"********************************************");
        //進行陣列排序
        NSArray *sortedArr = [mArr sortedArrayUsingSelector:@selector(compare:)];
        //列印排序後陣列
        for (int i=0; i<sortedArr.count; i++)
        {
            NSLog(@"<排序後>[%i]:%@",i,sortedArr[i]);
        }
    }
    return 0;
}
