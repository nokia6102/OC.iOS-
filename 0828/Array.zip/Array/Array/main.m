#import <Foundation/Foundation.h>
//<宣告>外部函式計算陣列總和
int sumOfArray(int a[],int n);

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //===================一維陣列(8.1)===================
        int arr[] = {10,20,30,40,50};
//        NSLog(@"%i",arr[0]);
//        NSLog(@"%i",arr[1]);
//        NSLog(@"%i",arr[2]);
//        NSLog(@"%i",arr[3]);
//        NSLog(@"%i",arr[4]);
        
        int num,sum;
        sum = 0;
//        sum = sum + arr[0];
//        NSLog(@"第一次加總的值：%i",sum);
//        sum = sum + arr[1];
//        NSLog(@"第二次加總的值：%i",sum);
//        sum = sum + arr[2];
//        NSLog(@"第三次加總的值：%i",sum);
//        sum = sum + arr[3];
//        NSLog(@"第四次加總的值：%i",sum);
//        sum = sum + arr[4];
//        NSLog(@"第五次加總的值：%i",sum);
        
        //計算陣列的個數
        num = sizeof(arr)/sizeof(arr[0]);
        NSLog(@"陣列個數：%i",num);
        for (int i=0; i<num; i++)
        {
            NSLog(@"%i",arr[i]);
            //加總陣列總和
//            sum = sum + arr[i];
            sum += arr[i];      //簡化寫法
            NSLog(@"第%i次加總的值：%i",i+1,sum);
        }
        
        //呼叫外部函式以計算陣列總和
        sum = sumOfArray(arr,num);
        
        //宣告第二個陣列
        int arr2[]={200,300,400};
        //計算第二個陣列的總和
        sum = sumOfArray(arr2, sizeof(arr2)/sizeof(arr2[0]));
        
        NSLog(@"********************************************");
        
        //==========改變陣列大小（複製陣列）==========
        //宣告一個比較大的陣列
        int newArr[10];
        //以迴圈將原來以存在的陣列元素，抄錄到新陣列(注意：num為舊的陣列大小)
        for (int i=0; i<10; i++)
        {
            if (i<num)
            {
                //還在舊陣列的個數之內時，抄錄舊陣列元素過來
                newArr[i] = arr[i];
            }
            else
            {
                //超出舊陣列個數時，填上預設值
                newArr[i] = 0;
            }
            NSLog(@"新陣列[%i]:%i",i,newArr[i]);
        }
        sum = sumOfArray(newArr, sizeof(newArr)/sizeof(newArr[0]));
        NSLog(@"********************************************");
        
        //===================二維陣列[列數][行數](8.2)===================
        int arr3[][3]={{10,20,30},{40,50,60}};
//        int arr4[][3]={10,20,30,40,50,60};
        //外迴圈為列數
        for (int i=0; i<2; i++)
        {
            //內迴圈為行數
            for (int j=0; j<3; j++)
            {
                NSLog(@"<二維>[%i][%i]:%i",i,j,arr3[i][j]);
            }
        }
        NSLog(@"********************************************");
        //===================字元陣列（字串）<補充>===================
        char singleChar = 'a';
        NSLog(@"我是字元：%c",singleChar);
        char string[] = "我是字串";
        NSLog(@"%@",[NSString stringWithUTF8String:string]);
//        NSLog(@"%@",[NSString stringWithCString:string encoding:NSUTF8StringEncoding]);
        
    }
    return 0;
}

//<實作>外部函式計算陣列總和（傳入參數1:陣列，傳入參數2:陣列個數，回傳值為陣列的總和）
int sumOfArray(int a[],int n)
{
    int tot = 0;
    for (int i=0; i<n; i++)
    {
        NSLog(@"%i",a[i]);
        //加總陣列總和
        //            tot = tot + a[i];
        tot += a[i];      //簡化寫法
        NSLog(@"<函式>第%i次加總的值：%i",i+1,tot);
    }
    return tot;
}
