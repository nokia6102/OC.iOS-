#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //==================數字物件(19.1)==================
        //建立整數數值物件
        NSNumber *intNumber;
        //<方法一>使用類別方法配置記憶體，使用物件方法做初始化
        intNumber = [[NSNumber alloc] initWithInt:1000];
        //<方法二>直接使用類別方法做記憶體配置及初始化
        intNumber = [NSNumber numberWithInt:1001];
        
        //建立字元物件
        NSNumber *charNumber = [NSNumber numberWithChar:'a'];
        //建立浮點數數值物件
        NSNumber *doubleNumber = [NSNumber numberWithDouble:100.11];
        
        //列印數字物件
        NSLog(@"intNumber=%@",intNumber);
        NSLog(@"charNumber=%@",charNumber);
        NSLog(@"doubleNumber=%@",doubleNumber);
        
        //列印數字物件(使用屬性)
        NSLog(@"intNumber=%i",intNumber.intValue);
        NSLog(@"charNumber=%c",charNumber.charValue);  //以字元顯示
        NSLog(@"charNumber=%i",charNumber.charValue);  //以Ascii Code顯示
        NSLog(@"doubleNumber=%f",doubleNumber.doubleValue);
        //設定為double的最大值
        doubleNumber = [NSNumber numberWithDouble:FLT_MAX];
        //%g依情況自動選擇%f或%e(%g可能會去掉小數後的補零)
        NSLog(@"<最大>doubleNumber=%g",doubleNumber.doubleValue);
        NSLog(@"*************************************************");
        //NSNumber相等比較<方法一>使用物件方法比對
        if ([intNumber isEqualToNumber:doubleNumber])
        {
            NSLog(@"intNumber與doubleNumber相等");
        }
        else
        {
            NSLog(@"intNumber與doubleNumber不相等");
        }
        //NSNumber相等比較<方法二>使用物件屬性比對
        if (intNumber.integerValue == (NSInteger)doubleNumber.doubleValue)
        {
            NSLog(@"intNumber與doubleNumber的屬性值相等");
        }
        else
        {
            NSLog(@"intNumber與doubleNumber的屬性值不相等");
        }
        //NSNumber大小比較<方法一>使用物件方法比對
        if ([intNumber isGreaterThan:doubleNumber])  //>
        {
            NSLog(@"intNumber大於doubleNumber");
        }
        else if ([intNumber isLessThan:doubleNumber]) //<
        {
            NSLog(@"intNumber小於doubleNumber");
        }
        else    //=
        {
            NSLog(@"intNumber等於doubleNumber");
        }
        //NSNumber大小比較<方法二>使用物件屬性比對
        if (intNumber.intValue > doubleNumber.doubleValue)
        {
            NSLog(@"intNumber的屬性值大於doubleNumber");
        }
        else if (intNumber.intValue < doubleNumber.doubleValue)
        {
            NSLog(@"intNumber的屬性值小於doubleNumber");
        }
        else
        {
            NSLog(@"intNumber的屬性值與doubleNumber的屬性值相等");
        }
        NSLog(@"*************************************************");
        
        //NSNumber的順序比對
        if ([intNumber compare:doubleNumber]==NSOrderedAscending)
        {
            NSLog(@"%i->%f為遞增",intNumber.intValue,doubleNumber.doubleValue);
        }
        else if ([intNumber compare:doubleNumber]==NSOrderedDescending)
        {
            NSLog(@"%i->%f為遞減",intNumber.intValue,doubleNumber.doubleValue);
        }
        else
        {
            NSLog(@"%i與%f順序相同",intNumber.intValue,doubleNumber.doubleValue);
        }
        //型別定義typedef不需宣告成指標
        NSInteger integerValue;
        integerValue = 600;
        NSLog(@"NSInteger=%li",integerValue);
        //列舉也不需宣告成指標
        NSComparisonResult result;
        result = NSOrderedAscending;
        NSLog(@"順序是：%li",result);
    }
    return 0;
}
