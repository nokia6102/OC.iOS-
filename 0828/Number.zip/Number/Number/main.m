#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //顯示資料型態的大小
        NSLog(@"test....");
        NSLog(@"int:%lu...",sizeof(int));
        NSLog(@"float:%lu...",sizeof(float));
        NSLog(@"double:%lu...",sizeof(double));
        NSLog(@"unsigned int:%lu...",sizeof(unsigned int));
        NSLog(@"unsigned:%lu...",sizeof(unsigned));
        //整數變數
        int intNumber=888;
        NSLog(@"(before)intNumber=%i",intNumber);
        intNumber=999;
        NSLog(@"(after)intNumber=%i",intNumber);
        //整數常數
        const int constIntNumber=111;
        NSLog(@"(before)constIntNumber=%i",constIntNumber);
//        constIntNumber = 2222;    //常數不能變更值
        
        //浮點數
        double doubleNumber=999.01;
        
        //=====================數字比較<補充>======================
        //相等判斷
        if ((double)intNumber == doubleNumber)
        {
            NSLog(@"intNumber與doubleNumber相等");
        }
        else
        {
            NSLog(@"intNumber與doubleNumber不相等");
        }
        
        //大小比較
        if (intNumber > doubleNumber)
        {
            NSLog(@"intNumber:%i大於doubleNumber:%f",intNumber,doubleNumber);
        }
        else if (intNumber < doubleNumber)
        {
            NSLog(@"intNumber:%i小於doubleNumber:%f",intNumber,doubleNumber);
        }
        else  //=
        {
            NSLog(@"intNumber:%i等於doubleNumber:%f",intNumber,doubleNumber);
        }
        
    }
    return 0;
}
