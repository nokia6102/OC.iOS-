#import "ViewController.h"

@interface ViewController ()
{
    //利用詞典來記錄資料表中的單一資料行
    NSMutableDictionary *dicRow;
    //利用陣列來記錄一個完整的資料表
    NSMutableArray *arrTable;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    //初始化陣列
    arrTable = [NSMutableArray new];
    //=========模擬從資料庫中抄錄第一筆資料=========
    //建立第一本詞典，對應資料庫中的第一筆資料
    dicRow = [NSMutableDictionary dictionaryWithDictionary:@{@"no":@"101",@"name":@"陳大智",@"gender":@"男",@"picture":@"101.jpg",@"phone":@"0912889124",@"address":@"宜蘭縣礁溪鄉健康路77號",@"email":@"xyz@abc.com",@"class":@"手機程式設計"}];
    //將第一本詞典加入陣列
    [arrTable addObject:dicRow];
    
    //=========模擬從資料庫中抄錄第二筆資料=========
    //建立第二本詞典，對應資料庫中的第二筆資料
    dicRow = [NSMutableDictionary dictionaryWithDictionary:@{@"no":@"102",@"name":@"聶小倩",@"gender":@"女",@"picture":@"102.jpg",@"phone":@"0937112889",@"address":@"台北市中山北路二段98號",@"email":@"mn@xx.yy.com",@"class":@"網頁程式設計"}];
    //將第二本詞典加入陣列
    [arrTable addObject:dicRow];
    
    //列出陣列中的每一筆資料
//    for (int i = 0; i < arrTable.count; i++)
//    {
//        NSLog(@"學號：%@姓名：%@住址：%@",dicRow[@"no"],dicRow[@"name"],dicRow[@"address"]);
//    }
    for (dicRow in arrTable)
    {
        NSLog(@"學號：%@姓名：%@住址：%@",dicRow[@"no"],dicRow[@"name"],dicRow[@"address"]);
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
