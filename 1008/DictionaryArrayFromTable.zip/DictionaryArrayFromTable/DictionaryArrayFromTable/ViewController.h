//
//  ViewController.h
//  DictionaryArrayFromTable
//
//  Created by perkin on 2015/10/8.
//  Copyright © 2015年 perkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

