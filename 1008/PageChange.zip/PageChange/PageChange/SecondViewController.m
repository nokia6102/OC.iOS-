#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController
//返回1＆返回2
- (IBAction)Button1Pressed:(UIButton *)sender
{
    //移除第二個畫面
//    [self dismissViewControllerAnimated:YES completion:nil];
    [self dismissViewControllerAnimated:YES completion:^{
        
        NSLog(@"view2從記憶體中移除！");
        
        NSLog(@"『%@』按鈕被按了",sender.titleLabel.text);
        
    }];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"view2載入完成");
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSLog(@"view2即將被加入");
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSLog(@"view2已被加入");
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    NSLog(@"view2即將被移除");
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    NSLog(@"view2已被移除");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
