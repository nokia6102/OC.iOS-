#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NSLog(@"載入App");
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    NSLog(@"App即將進入背景");
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    NSLog(@"App已經進入背景");
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    NSLog(@"App即將進入前景");
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    NSLog(@"App已經進入前景");
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    NSLog(@"App終止");
}

@end
