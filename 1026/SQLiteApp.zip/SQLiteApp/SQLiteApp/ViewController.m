#import "ViewController.h"
#import "AppDelegate.h"
#import <sqlite3.h>
#import <MobileCoreServices/MobileCoreServices.h>   //使用相簿的Framework

@interface ViewController ()
{
    //資料庫的指標
    sqlite3 *db;
    //利用詞典來記錄資料表中的單一資料行（不含圖片） {NSString:NSString}
    NSMutableDictionary *dicRow;
    //利用陣列來記錄一個完整的資料表（不含圖片）
    NSMutableArray *arrTable;
    //記錄圖片的陣列
    NSMutableArray *arrPicture;
    //存放PickerView的資料來源陣列
    NSArray *arrGender;
    NSArray *arrClass;
    //記錄目前資料列
    int currentRow;
    //記錄目前輸入元件的Y軸底部位置
    CGFloat currentObjectBottomYPosition;
}

@property (weak, nonatomic) IBOutlet UITextField *txtNo;
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UIImageView *imgPicture;
@property (weak, nonatomic) IBOutlet UITextField *txtPhone;
@property (weak, nonatomic) IBOutlet UITextField *txtAddress;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UIPickerView *pkvGender;
@property (weak, nonatomic) IBOutlet UIPickerView *pkvClass;
@property UIImagePickerController *imgPicker;
@property (weak, nonatomic) IBOutlet UILabel *lblNo;
@property (weak, nonatomic) IBOutlet UIButton *btnChangePicture;

@end

@implementation ViewController
@synthesize txtNo,txtName,imgPicture,txtPhone,txtAddress,txtEmail,pkvClass,pkvGender,imgPicker,lblNo,btnChangePicture;
#pragma mark - 自訂函式
//收起鍵盤
-(void)CloseKeyboard
{
    for (UIView *view in self.view.subviews)
    {
        if ([view isKindOfClass:[UITextField class]])
        {
            //如果是UITextField的類別實體，則收起鍵盤
            [view resignFirstResponder];
        }
    }
}

//監聽鍵盤所呼叫的事件-鍵盤彈出
-(void)keyboadrdWillShow:(NSNotification*)sender
{
    NSLog(@"鍵盤彈出");
    //================把畫面往上移================
    //取得通知中心的資料
    NSDictionary *userInfo = sender.userInfo;
    if (userInfo)
    {
        //從通知中心的資料中取得鍵盤高度
        CGFloat keyboardHeight = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
        if (keyboardHeight > 0)
        {
            //計算可視高度
            CGFloat visibleHeight = self.view.frame.size.height - keyboardHeight;
            NSLog(@"鍵盤彈出後的可視高度：%f",visibleHeight);
            //計算可視高度與特定元件的Y軸底緣之間的差值(正值表示元件被遮住了)
            CGFloat diffHeight = currentObjectBottomYPosition - visibleHeight;
            if (diffHeight > 0)     //如果有遮住才移動
            {
                //整個View往上移動其差值
                [UIView animateWithDuration:0.25 animations:^{
                    self.view.frame = CGRectMake(0, -(diffHeight+20), self.view.frame.size.width, self.view.frame.size.height);
                }];
            }
        }
    }
}

//監聽鍵盤所呼叫的事件-鍵盤收合
-(void)keyboadrdWillHide:(NSNotification*)sender
{
    NSLog(@"鍵盤收合");
    //把View移回原來的位置
    [UIView animateWithDuration:0.25 animations:^{
        self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    }];
}

//一旦開始編輯，就取得該元件的Y軸底部位置
- (IBAction)FieldTouched:(UITextField*)sender
{
    //計算目前元件的Y軸底端位置
    currentObjectBottomYPosition = sender.frame.origin.y + sender.frame.size.height;
    NSLog(@"Y軸底端位置：%f",currentObjectBottomYPosition);
}

#pragma mark - View Lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    //加入點按手勢收回鍵盤
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(CloseKeyboard)];
    [self.view addGestureRecognizer:tapGesture];
    //從AppDelegate取得資料庫連線，並儲存於db變數中
    AppDelegate *delegate = [UIApplication sharedApplication].delegate;
    db = [delegate getDB];
    //初始化PickerView的資料來源陣列
    arrGender = @[@"女",@"男"];
    arrClass = @[@"手機程式開發",@"網頁程式設計"];
    //指派代理人
    pkvGender.delegate = self;
    pkvGender.dataSource = self;
    pkvClass.delegate = self;
    pkvClass.dataSource = self;
    //初始化Y軸底部位置
    currentObjectBottomYPosition = 0;
    //註冊鍵盤的監聽事件
    //1.鍵盤彈出
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboadrdWillShow:) name:UIKeyboardWillShowNotification object:nil];
    //2.鍵盤收合
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboadrdWillHide:) name:UIKeyboardWillHideNotification object:nil];
    //本地化顯示文字
    lblNo.text = NSLocalizedStringFromTable(@"no", @"InfoPlist", nil);
    [btnChangePicture setTitle:NSLocalizedStringFromTable(@"btnChangePicture", @"InfoPlist", nil) forState:UIControlStateNormal];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Target Action
//收起鍵盤的Did End On Exit觸發事件
- (IBAction)didEndOnExit:(id)sender
{
    [sender resignFirstResponder];
}

//查詢按鈕
- (IBAction)btnQuery:(UIButton *)sender
{
    //目前資料表的指標在第0行
    currentRow = 0;
    //初始化陣列
    arrTable = [NSMutableArray new];
    arrPicture = [NSMutableArray new];
    //先確認資料連線成功
    if (db)
    {
        //準備查詢用的SQL
        const char *sql = "select * from student order by no";
        //宣告儲存查詢結果的變數(也就是資料集recordset)
        sqlite3_stmt *statement;
        //準備查詢(第三個參數若為正數，指的是sql可用的最大長度;若為負數，則不限sql的長度)
        sqlite3_prepare(db, sql, -1, &statement, nil);
        //利用迴圈取出查詢結果
        while (sqlite3_step(statement) == SQLITE_ROW)
        {
            //利用詞典來記錄資料表中的單一資料行（不含圖片）
            dicRow = [NSMutableDictionary new];
            //讀取第0欄
            char *cNo = (char *)sqlite3_column_text(statement, 0);  //注意轉型！
            //將第0欄從C語言的字串轉成NSString
            NSString *strNo = [NSString stringWithUTF8String:cNo];
            //將第0欄存入詞典
            dicRow[@"no"] = strNo;
            
            //讀取第1欄
            char *cName = (char *)sqlite3_column_text(statement, 1);  //注意轉型！
            //將第1欄從C語言的字串轉成NSString
            NSString *strName = [NSString stringWithUTF8String:cName];
            //將第1欄存入詞典
            dicRow[@"name"] = strName;
            
            //讀取第2欄
            int intGender = sqlite3_column_int(statement, 2);
            //將第2欄存入詞典
            dicRow[@"gender"] = [NSString stringWithFormat:@"%i",intGender];
            
            //讀取第4欄
            char *cPhone = (char *)sqlite3_column_text(statement, 4);  //注意轉型！
            //將第4欄從C語言的字串轉成NSString
            NSString *strPhone = [NSString stringWithUTF8String:cPhone];
            //將第4欄存入詞典
            dicRow[@"phone"] = strPhone;
            
            //讀取第5欄
            char *cAddress = (char *)sqlite3_column_text(statement, 5);  //注意轉型！
            //將第5欄從C語言的字串轉成NSString
            NSString *strAddress = [NSString stringWithUTF8String:cAddress];
            //將第5欄存入詞典
            dicRow[@"address"] = strAddress;
            
            //讀取第6欄
            char *cEmail = (char *)sqlite3_column_text(statement, 6);  //注意轉型！
            //將第6欄從C語言的字串轉成NSString
            NSString *strEmail = [NSString stringWithUTF8String:cEmail];
            //將第6欄存入詞典
            dicRow[@"email"] = strEmail;
            
            //讀取第7欄
            char *cClass = (char *)sqlite3_column_text(statement, 7);  //注意轉型！
            //將第7欄從C語言的字串轉成NSString
            NSString *strClass = [NSString stringWithUTF8String:cClass];
            //將第7欄存入詞典
            dicRow[@"class"] = strClass;
            
            //讀取第8欄
            char *cDate = (char *)sqlite3_column_text(statement, 8);  //注意轉型！
            //將第8欄從C語言的字串轉成NSString
            NSString *strDate = [NSString stringWithUTF8String:cDate];
            //將第8欄存入詞典
            dicRow[@"create_date"] = strDate;
            
            //將字典存入陣列
            [arrTable addObject:dicRow];
            
            //讀取第3欄
            int length = sqlite3_column_bytes(statement, 3);  //回傳值為檔案長度
            const void *totalBytes = sqlite3_column_blob(statement, 3);   //回傳值為檔案的Bytes
            NSData *imgData = [NSData dataWithBytes:totalBytes length:length];
            
            //將圖片存入陣列
            [arrPicture addObject:imgData];
            
        }
        NSLog(@"Table在陣列的內容%@",arrTable);
        NSLog(@"圖片在陣列的內容%@",arrPicture);
        //釋放資料庫查詢
        sqlite3_finalize(statement);
        //=================直接顯示第一筆資料=================
        txtNo.text = arrTable[0][@"no"];
        txtName.text = arrTable[0][@"name"];
        txtPhone.text = arrTable[0][@"phone"];
        txtAddress.text = arrTable[0][@"address"];
        txtEmail.text = arrTable[0][@"email"];
        imgPicture.image = [UIImage imageWithData:arrPicture[0]];
        //選定資料欄位中的對應性別
        [pkvGender selectRow:[arrTable[0][@"gender"] integerValue] inComponent:0 animated:YES];
        //取得班別資料
        NSString *myClass = arrTable[0][@"class"];
        //迴圈跑arrClass陣列的內容
        for (int i=0; i<arrClass.count; i++)
        {
            //進行陣列內容與班別資料欄位的比對
            if ([arrClass[i] isEqualToString:myClass])
            {
                //比對arrClass陣列當筆的內容，如果與當筆資料欄位相同，則選定該筆
                [pkvClass selectRow:i inComponent:0 animated:YES];
            }
        }
    }
}

//上一筆按鈕
- (IBAction)btnPrevious:(UIButton *)sender
{
    //若資料指標-1之後，沒有超過總資料筆數
    if (currentRow - 1 >= 0)
    {
        //資料指標-1
        currentRow--;
        //顯示當筆資料
        txtNo.text = arrTable[currentRow][@"no"];
        txtName.text = arrTable[currentRow][@"name"];
        txtPhone.text = arrTable[currentRow][@"phone"];
        txtAddress.text = arrTable[currentRow][@"address"];
        txtEmail.text = arrTable[currentRow][@"email"];
        imgPicture.image = [UIImage imageWithData:arrPicture[currentRow]];
        //選定資料欄位中的對應性別
        [pkvGender selectRow:[arrTable[currentRow][@"gender"] integerValue] inComponent:0 animated:YES];
        //取得班別資料
        NSString *myClass = arrTable[currentRow][@"class"];
        //迴圈跑arrClass陣列的內容
        for (int i=0; i<arrClass.count; i++)
        {
            //進行陣列內容與班別資料欄位的比對
            if ([arrClass[i] isEqualToString:myClass])
            {
                //比對arrClass陣列當筆的內容，如果與當筆資料欄位相同，則選定該筆
                [pkvClass selectRow:i inComponent:0 animated:YES];
            }
        }
    }
}

//下一筆按鈕
- (IBAction)btnNext:(UIButton *)sender
{
    //若資料指標＋1之後，沒有超過總資料筆數
    if (currentRow + 1 < arrTable.count)
    {
        //資料指標＋1
        currentRow++;
        //顯示當筆資料
        txtNo.text = arrTable[currentRow][@"no"];
        txtName.text = arrTable[currentRow][@"name"];
        txtPhone.text = arrTable[currentRow][@"phone"];
        txtAddress.text = arrTable[currentRow][@"address"];
        txtEmail.text = arrTable[currentRow][@"email"];
        imgPicture.image = [UIImage imageWithData:arrPicture[currentRow]];
        //選定資料欄位中的對應性別
        [pkvGender selectRow:[arrTable[currentRow][@"gender"] integerValue] inComponent:0 animated:YES];
        //取得班別資料
        NSString *myClass = arrTable[currentRow][@"class"];
        //迴圈跑arrClass陣列的內容
        for (int i=0; i<arrClass.count; i++)
        {
            //進行陣列內容與班別資料欄位的比對
            if ([arrClass[i] isEqualToString:myClass])
            {
                //比對arrClass陣列當筆的內容，如果與當筆資料欄位相同，則選定該筆
                [pkvClass selectRow:i inComponent:0 animated:YES];
            }
        }
    }
}

//拍照按鈕
- (IBAction)btnTakePicture:(UIButton *)sender
{

    //檢查裝置是否支援相機
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])  //不支援相機時（注意驚嘆號）
    {
        //準備訊息視窗
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"找不到相機" message:@"無法使用相機" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
        //顯示訊息視窗
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }

    //初始化挑選照片的畫面
    imgPicker = [UIImagePickerController new];
    //指派代理人
    imgPicker.delegate = self;
    //指定使用的媒體為相機
    imgPicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    //指定取用相機的功能
    imgPicker.mediaTypes = @[(NSString *)kUTTypeImage];  //影片 @[kUTTypeMovie]
    //允許對照片進行編輯  注意：需配合挑選完成的代理事件中的info[UIImagePickerControllerEditedImage]
    imgPicker.allowsEditing = YES;
    //開啟相簿
    [self presentViewController:imgPicker animated:YES completion:nil];
}

//更換照片按鈕
- (IBAction)btnChangePicture:(UIButton *)sender
{
    //初始化挑選照片的畫面
    imgPicker = [UIImagePickerController new];
    //指派代理人
    imgPicker.delegate = self;
    //指定使用的媒體為相簿
    imgPicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    //允許對照片進行編輯  注意：需配合挑選完成的代理事件中的info[UIImagePickerControllerEditedImage]
    imgPicker.allowsEditing = YES;
    //開啟相簿
    [self presentViewController:imgPicker animated:YES completion:nil];
}

//新增按鈕
- (IBAction)btnAdd:(UIButton *)sender
{
    //不允許空白
    if ([txtNo.text isEqualToString: @""] || [txtName.text isEqualToString:@""] || [txtPhone.text isEqualToString:@""] || [txtAddress.text isEqualToString:@""] || [txtEmail.text isEqualToString:@""])
    {
        //準備訊息視窗
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"無法新增資料" message:@"欄位資料不可空白" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
        //顯示訊息視窗
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    //一定要挑選照片
//    if (imgPicture.image == nil)
    if (!imgPicture.image)
    {
        //如果沒有照片使用預設照片
        imgPicture.image = [UIImage imageNamed:@"DefaultPhoto.jpg"];
    }
    //開始新增資料
    if (db) //檢查資料庫連線
    {
        //準備要存入的照片（第二個參數是壓縮比）
        NSData *imgData = UIImageJPEGRepresentation(imgPicture.image, 0.8);
        //準備Insert SQL
        NSString *sql = [NSString stringWithFormat:@"insert into student(no,name,gender,picture,phone,address,email,class,create_date) values('%@','%@',%li,?,'%@','%@','%@','%@',date('now'))",txtNo.text,txtName.text,[pkvGender selectedRowInComponent:0],txtPhone.text,txtAddress.text,txtEmail.text,arrClass[[pkvClass selectedRowInComponent:0]]];
        NSLog(@"SQL：%@",sql);
        //將Insert SQL轉換成C語言字串
        const char *cSql = [sql cStringUsingEncoding:NSUTF8StringEncoding];
        //宣告儲存執行結果的變數
        sqlite3_stmt *statement;
        //準備執行SQL指令
        sqlite3_prepare(db, cSql, -1, &statement, nil);
        //將照片綁定到sql語法中?所在的位置 注意：參數二綁定的位置是從1起算
        sqlite3_bind_blob(statement, 1, [imgData bytes], (int)[imgData length], nil);
        //執行sql指令
        if (sqlite3_step(statement)==SQLITE_DONE)  //如果指令執行成功
        {
            //準備訊息視窗
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"資料庫訊息" message:@"資料新增成功！" preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
            //顯示訊息視窗
            [self presentViewController:alert animated:YES completion:nil];
        }
        else
        {
            //準備訊息視窗
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"資料庫訊息" message:@"資料新增失敗！" preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
            //顯示訊息視窗
            [self presentViewController:alert animated:YES completion:nil];
        }
        //使用完畢，釋放statement
        sqlite3_finalize(statement);
        //重整陣列資料（1.呼叫查詢按鈕 2.直接將當筆資料寫入陣列）
        [self btnQuery:nil];
    }
}

//修改按鈕
- (IBAction)btnUpdate:(UIButton *)sender
{
    //不允許空白
    if ([txtNo.text isEqualToString: @""] || [txtName.text isEqualToString:@""] || [txtPhone.text isEqualToString:@""] || [txtAddress.text isEqualToString:@""] || [txtEmail.text isEqualToString:@""])
    {
        //準備訊息視窗
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"無法新增資料" message:@"欄位資料不可空白" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
        //顯示訊息視窗
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    //一定要挑選照片
    //    if (imgPicture.image == nil)
    if (!imgPicture.image)
    {
        //如果沒有照片使用預設照片
        imgPicture.image = [UIImage imageNamed:@"DefaultPhoto.jpg"];
    }
    //開始新增資料
    if (db) //檢查資料庫連線
    {
        //準備要存入的照片（第二個參數是壓縮比）
        NSData *imgData = UIImageJPEGRepresentation(imgPicture.image, 0.8);
        //準備update SQL
        NSString *sql = [NSString stringWithFormat:@"update student set name='%@',gender=%li,picture=?,phone='%@',address='%@',email='%@',class='%@' where no='%@'",txtName.text,[pkvGender selectedRowInComponent:0],txtPhone.text,txtAddress.text,txtEmail.text,arrClass[[pkvClass selectedRowInComponent:0]],txtNo.text];
        NSLog(@"SQL：%@",sql);
        //將Insert SQL轉換成C語言字串
        const char *cSql = [sql cStringUsingEncoding:NSUTF8StringEncoding];
        //宣告儲存執行結果的變數
        sqlite3_stmt *statement;
        //準備執行SQL指令
        sqlite3_prepare(db, cSql, -1, &statement, nil);
        //將照片綁定到sql語法中?所在的位置 注意：參數二綁定的位置是從1起算
        sqlite3_bind_blob(statement, 1, [imgData bytes], (int)[imgData length], nil);
        //執行sql指令
        if (sqlite3_step(statement)==SQLITE_DONE)  //如果指令執行成功
        {
            //準備訊息視窗
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"資料庫訊息" message:@"資料修改成功！" preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
            //顯示訊息視窗
            [self presentViewController:alert animated:YES completion:nil];
        }
        else
        {
            //準備訊息視窗
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"資料庫訊息" message:@"資料修改失敗！" preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
            //顯示訊息視窗
            [self presentViewController:alert animated:YES completion:nil];
        }
        //使用完畢，釋放statement
        sqlite3_finalize(statement);
        //重整陣列資料（1.呼叫查詢按鈕 2.直接將當筆資料寫入陣列）
        [self btnQuery:nil];
    }
}

//刪除按鈕
- (IBAction)btnDelete:(UIButton *)sender
{
    //不允許空白
    if ([txtNo.text isEqualToString: @""] || [txtName.text isEqualToString:@""] || [txtPhone.text isEqualToString:@""] || [txtAddress.text isEqualToString:@""] || [txtEmail.text isEqualToString:@""])
    {
        //準備訊息視窗
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"無法新增資料" message:@"欄位資料不可空白" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
        //顯示訊息視窗
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    //一定要挑選照片
    //    if (imgPicture.image == nil)
    if (!imgPicture.image)
    {
        //如果沒有照片使用預設照片
        imgPicture.image = [UIImage imageNamed:@"DefaultPhoto.jpg"];
    }
    //開始新增資料
    if (db) //檢查資料庫連線
    {
        //準備要存入的照片（第二個參數是壓縮比）
        NSData *imgData = UIImageJPEGRepresentation(imgPicture.image, 0.8);
        //準備Insert SQL
        NSString *sql = [NSString stringWithFormat:@"insert into student(no,name,gender,picture,phone,address,email,class,create_date) values('%@','%@',%li,?,'%@','%@','%@','%@',date('now'))",txtNo.text,txtName.text,[pkvGender selectedRowInComponent:0],txtPhone.text,txtAddress.text,txtEmail.text,arrClass[[pkvClass selectedRowInComponent:0]]];
        NSLog(@"SQL：%@",sql);
        //將Insert SQL轉換成C語言字串
        const char *cSql = [sql cStringUsingEncoding:NSUTF8StringEncoding];
        //宣告儲存執行結果的變數
        sqlite3_stmt *statement;
        //準備執行SQL指令
        sqlite3_prepare(db, cSql, -1, &statement, nil);
        //將照片綁定到sql語法中?所在的位置 注意：參數二綁定的位置是從1起算
        sqlite3_bind_blob(statement, 1, [imgData bytes], (int)[imgData length], nil);
        //執行sql指令
        if (sqlite3_step(statement)==SQLITE_DONE)  //如果指令執行成功
        {
            //準備訊息視窗
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"資料庫訊息" message:@"資料新增成功！" preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
            //顯示訊息視窗
            [self presentViewController:alert animated:YES completion:nil];
        }
        else
        {
            //準備訊息視窗
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"資料庫訊息" message:@"資料新增失敗！" preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
            //顯示訊息視窗
            [self presentViewController:alert animated:YES completion:nil];
        }
        //使用完畢，釋放statement
        sqlite3_finalize(statement);
        //重整陣列資料（1.呼叫查詢按鈕 2.直接將當筆資料寫入陣列）
        [self btnQuery:nil];
    }
}

#pragma mark - UIPickerViewDelegate
//<方法一>回傳『每一列』中用來顯示的文字（使用預設文字格式）
//-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
//{
//    if (pickerView.tag == 0)
//    {
//        return arrGender[row];
//    }
//    else
//    {
//        return arrClass[row];
//    }
//}

//<方法二>回傳『每一列』中用來顯示的文字（使用自訂文字格式）
-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    //初始化一個UILabel
    UILabel *myView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, pickerView.frame.size.width, pickerView.frame.size.height)];
    //準備顯在myView的文字
    if (pickerView.tag == 0)
    {
        myView.text = arrGender[row];
    }
    else
    {
        myView.text = arrClass[row];
    }
    //調整myView文字屬性
    myView.textAlignment = NSTextAlignmentLeft;
    myView.font = [UIFont systemFontOfSize:16];
    return myView;
}

#pragma mark - UIPickerViewDataSource
//一個PickerView有幾個滾輪
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    //只要一個滾輪
    return 1;
}
//每個滾輪有幾筆資料
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    //<方法一>利用tag判斷不同的pickerView
    if (pickerView.tag == 0)
    {
        return arrGender.count;
    }
    else
    {
        return arrClass.count;
    }
    //<方法二>利用property判斷不同的pickerView
//    if (pkvGender == pickerView)
//    {
//        return arrGender.count;
//    }
//    else
//    {
//        return arrClass.count;
//    }
}

#pragma mark - UIImagePickerControllerDelegate
//從相簿挑選好照片或影片之後
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    //將挑選好的照片顯示出來
//    imgPicture.image = info[UIImagePickerControllerOriginalImage];  //原圖
    imgPicture.image = info[UIImagePickerControllerEditedImage];      //編輯過後的圖
    //退掉挑選照片的畫面
    [picker dismissViewControllerAnimated:YES completion:^{
        //清空挑選圖片的物件
        imgPicker = nil;
    }];
}

@end
