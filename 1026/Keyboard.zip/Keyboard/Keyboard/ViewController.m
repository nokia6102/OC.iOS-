#import "ViewController.h"

@interface ViewController ()
{
    //記錄目前輸入元件的Y軸底部位置
    CGFloat currentObjectBottomYPosition;
}
@property (weak, nonatomic) IBOutlet UITextField *txtInput1;
@property (weak, nonatomic) IBOutlet UITextField *txtInput2;
@property (weak, nonatomic) IBOutlet UITextField *txtInput3;

@end

@implementation ViewController

#pragma mark - 自訂函式
//收起鍵盤
-(void)CloseKeyboard
{
    for (UIView *view in self.view.subviews)
    {
        if ([view isKindOfClass:[UITextField class]])
        {
            //如果是UITextField的類別實體，則收起鍵盤
            [view resignFirstResponder];
        }
    }
}

//監聽鍵盤所呼叫的事件-鍵盤彈出
-(void)keyboadrdWillShow:(NSNotification*)sender
{
    NSLog(@"鍵盤彈出");
    //================把畫面往上移================
    //取得通知中心的資料
    NSDictionary *userInfo = sender.userInfo;
    if (userInfo)
    {
        //從通知中心的資料中取得鍵盤高度
        CGFloat keyboardHeight = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
        if (keyboardHeight > 0)
        {
            //計算可視高度
            CGFloat visibleHeight = self.view.frame.size.height - keyboardHeight;
            NSLog(@"鍵盤彈出後的可視高度：%f",visibleHeight);
            //計算可視高度與特定元件的Y軸底緣之間的差值(正值表示元件被遮住了)
            CGFloat diffHeight = currentObjectBottomYPosition - visibleHeight;
            if (diffHeight > 0)     //如果有遮住才移動
            {
                //整個View往上移動其差值
                [UIView animateWithDuration:0.25 animations:^{
                    self.view.frame = CGRectMake(0, -(diffHeight+20), self.view.frame.size.width, self.view.frame.size.height);
                }];
            }
        }
    }
}

//監聽鍵盤所呼叫的事件-鍵盤收合
-(void)keyboadrdWillHide:(NSNotification*)sender
{
    NSLog(@"鍵盤收合");
    //把View移回原來的位置
    [UIView animateWithDuration:0.25 animations:^{
        self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    }];
}

//一旦開始編輯，就取得該元件的Y軸底部位置
- (IBAction)FieldTouched:(UITextField*)sender
{
    //計算目前元件的Y軸底端位置
    currentObjectBottomYPosition = sender.frame.origin.y + sender.frame.size.height;
    NSLog(@"Y軸底端位置：%f",currentObjectBottomYPosition);
}

#pragma mark - View Lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    //加入點按手勢收回鍵盤
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(CloseKeyboard)];
    [self.view addGestureRecognizer:tapGesture];
    //初始化Y軸底部位置
    currentObjectBottomYPosition = 0;
    //註冊鍵盤的監聽事件
    //1.鍵盤彈出
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboadrdWillShow:) name:UIKeyboardWillShowNotification object:nil];
    //2.鍵盤收合
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboadrdWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
