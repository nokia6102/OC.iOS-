//
//  AppDelegate.h
//  Keyboard
//
//  Created by perkin on 2015/10/23.
//  Copyright © 2015年 perkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

