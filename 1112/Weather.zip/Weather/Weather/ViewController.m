#import "ViewController.h"
//利用類目來擴充NSMutableDictionay的排序方法
@interface NSMutableDictionary (SortMethod)
-(NSComparisonResult)MyCompare:(NSMutableDictionary *)anotherDictionay;
@end

@implementation NSMutableDictionary (SortMethod)

-(NSComparisonResult)MyCompare:(NSMutableDictionary *)anotherDictionay
{
    if ([self[@"TEMP"] doubleValue] > [anotherDictionay[@"TEMP"] doubleValue])
    {
        //由大到小
        return NSOrderedAscending;
    }
    else if ([self[@"TEMP"] doubleValue] < [anotherDictionay[@"TEMP"] doubleValue])
    {
        //由大到小
        return NSOrderedDescending;
    }
    else
    {
        return NSOrderedSame;
    }
}
@end

@interface ViewController ()
{
    //宣告定位管理員
    CLLocationManager *locationManager;
    //宣告地理資訊編碼器
    CLGeocoder *geocoder;
    //目前的開始標籤
    NSString *tagName;
    //目前的標籤內容（要當詞典key的部份）
    NSString *strKey;
    //記錄單筆氣象資訊的詞典
    NSMutableDictionary *dicWeather;
    //記錄所有氣象資訊的陣列
    NSMutableArray *arrWeather;
}

@property (weak, nonatomic) IBOutlet UILabel *lblCity;
@property (weak, nonatomic) IBOutlet UILabel *lblTown;
@property (weak, nonatomic) IBOutlet UILabel *lblAltitude;
@property (weak, nonatomic) IBOutlet UILabel *lblTemp;

@end

@implementation ViewController
@synthesize lblCity,lblTown,lblAltitude,lblTemp;

- (void)viewDidLoad
{
    [super viewDidLoad];
    //初始化氣象資訊的詞典與陣列
    dicWeather = [NSMutableDictionary new];
    arrWeather = [NSMutableArray new];
    //初始化定位管理員，並且指定代理人
    locationManager = [CLLocationManager new];
    locationManager.delegate = self;
    //詢問使用者是否要給App定位權限
    [locationManager requestWhenInUseAuthorization];
    //初始化地理資訊編碼器
    geocoder = [CLGeocoder new];
}
//view即將出現
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //開始定位
    [locationManager startUpdatingLocation];
}
//view即將消失
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    //停止定位
    [locationManager stopUpdatingLocation];
    //清空已經拿到的陣列資料
    arrWeather = [NSMutableArray new];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - CLLocationManagerDelegate
//定位管理員開始更新定位資訊
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    NSLog(@"定位中");
    //取得記錄定位資訊的陣列中第一筆的位置資訊
    CLLocation *myLocation = locations[0];
    //顯示高度
    lblAltitude.text = [NSString stringWithFormat:@"%.6f",myLocation.altitude];
    //利用地理編碼器反查出地址，以取得所在縣市鄉鎮（從Block參數中的placemarks裡面取得）
    [geocoder reverseGeocodeLocation:myLocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (error)
        {
            lblCity.text = @"未知";
            lblTown.text = @"未知";
            return;
        }
        //取得所在行政區的第一筆資料
        CLPlacemark *currentPlacemark = placemarks[0];
        NSDictionary *dicAddress = currentPlacemark.addressDictionary;
        //調整五都合併資料
        NSString *strCity = dicAddress[@"SubAdministrativeArea"];
        if ([strCity isEqualToString:@"台北縣"])
        {
            strCity = @"新北市";
        }
        else if ([strCity isEqualToString:@"桃園縣"])
        {
            strCity = @"桃園市";
        }
        else if ([strCity isEqualToString:@"台中縣"])
        {
            strCity = @"台中市";
        }
        else if ([strCity isEqualToString:@"台南縣"])
        {
            strCity = @"台南市";
        }
        else if ([strCity isEqualToString:@"高雄縣"])
        {
            strCity = @"高雄市";
        }
        //顯示縣市鄉鎮
        lblCity.text = strCity;
        lblTown.text = dicAddress[@"City"];
        //如果陣列沒有資料，就去氣象局網站解析xml
        if (arrWeather.count <= 0)
        {
            //中央氣象局的URL
            NSString *strURL = @"http://opendata.cwb.gov.tw/opendataapi?dataid=O-A0001-001&authorizationkey=CWB-72F89C13-3FBB-44A0-A9A5-A6E8B78950E1";
            //將網址製成NSURL物件
            NSURL *url = [NSURL URLWithString:strURL];
            //初始化網路存取物件
            NSURLSession *session = [NSURLSession sharedSession];
            //製作用來執行網路資料傳輸任務的物件
            NSURLSessionDataTask *dataTask =
            [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable xmlData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                //        NSLog(@"%@",xmlData);
                //初始化xml解析器
                NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithData:xmlData];
                //指派xml解析器的代理人
                xmlParser.delegate = self;
                //啟動xml解析
                [xmlParser parse];
            }];
            //執行網路資料傳輸任務
            [dataTask resume];
        }
    }];
}

#pragma mark - NSXMLParserDelegate
//讀到開始標籤
-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict
{
    //抓取可能需要的開始標籤
    if ([elementName isEqualToString:@"elementName"] || [elementName isEqualToString:@"value"] || [elementName isEqualToString:@"parameterName"] || [elementName isEqualToString:@"parameterValue"])
    {
//        NSLog(@"開始標籤：%@",elementName);
        tagName = elementName;
    }
}
//讀到標籤內容
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)strContent
{
    //=================讀到標籤內容為key時=================
    if ([strContent isEqualToString:@"TEMP"] || [strContent isEqualToString:@"CITY"] || [strContent isEqualToString:@"TOWN"])
    {
//        NSLog(@"標籤內容：%@",strContent);
        strKey = strContent;
    }
    //=================讀到標籤內容為value時=================
    //<版本一>if判斷式組合前
//    //如果上一次讀到的key是TEMP，而且最接近的開始標籤是value
//    if ([strKey isEqualToString:@"TEMP"] && [tagName isEqualToString:@"value"])
//    {
//        //將氣溫的key-value配對後加入詞典
//        dicWeather[strKey] = strContent;
//        //用過的key就立刻清空
//        strKey = @"";
//    }
//    //如果上一次讀到的key是CITY，而且最接近的開始標籤是parameterValue
//    if ([strKey isEqualToString:@"CITY"] && [tagName isEqualToString:@"parameterValue"])
//    {
//        //將縣市的key-value配對後加入詞典
//        dicWeather[strKey] = strContent;
//        //用過的key就立刻清空
//        strKey = @"";
//    }
//    //如果上一次讀到的key是TOWN，而且最接近的開始標籤是parameterValue
//    if ([strKey isEqualToString:@"TOWN"] && [tagName isEqualToString:@"parameterValue"])
//    {
//        //將縣市的key-value配對後加入詞典
//        dicWeather[strKey] = strContent;
//        //用過的key就立刻清空
//        strKey = @"";
//    }
    //<版本二>if判斷式組合後
    if (([strKey isEqualToString:@"TEMP"] && [tagName isEqualToString:@"value"]) || ([strKey isEqualToString:@"CITY"] && [tagName isEqualToString:@"parameterValue"])|| ([strKey isEqualToString:@"TOWN"] && [tagName isEqualToString:@"parameterValue"]))
    {
        //將key-value配對後加入詞典
        dicWeather[strKey] = strContent;
        //用過的key就立刻清空
        strKey = @"";
    }
}
//讀到結束標籤
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
//    NSLog(@"結束標籤：%@",elementName);
    //location結束標籤是一整筆資料結束的位置
    if ([elementName isEqualToString:@"location"])
    {
        //將整本詞典存入陣列
        [arrWeather addObject:dicWeather];
        //清空詞典
        dicWeather = [NSMutableDictionary new];
    }
}
//讀完整份xml文件
-(void)parserDidEndDocument:(NSXMLParser *)parser
{
//    NSLog(@"讀完了！");
    NSLog(@"陣列筆數：%lu",arrWeather.count);
    for (int i=0; i<arrWeather.count; i++)
    {
        NSLog(@"%@/%@/%@",arrWeather[i][@"CITY"],arrWeather[i][@"TOWN"],arrWeather[i][@"TEMP"]);
    }
    //逐筆比對現在所在縣市鄉鎮的氣溫
    BOOL TEMP_not_Found = YES;  //記錄是否比對到氣溫
    for (int i=0; i<arrWeather.count; i++)
    {
        //如果可以找到所屬縣市鄉鎮時，直接使用當地氣溫
        if ([lblCity.text isEqualToString:arrWeather[i][@"CITY"]] && [lblTown.text isEqualToString:arrWeather[i][@"TOWN"]])
        {
            //轉回主要執行緒才能更動UI
            dispatch_async(dispatch_get_main_queue(), ^{
                //顯示對應氣溫
                lblTemp.text = [NSString stringWithFormat:@"%.1f°C",[arrWeather[i][@"TEMP"] floatValue]];
            });
            //記錄有比對到氣溫
            TEMP_not_Found = NO;
            //找到對應氣溫就跳出迴圈
            break;
        }
    }
    if (TEMP_not_Found)
    {
        //先做陣列排序，氣溫由高溫到低溫
        [arrWeather sortUsingSelector:@selector(MyCompare:)];
        //再跑第二次迴圈，只取得最先一筆的縣市氣溫
        for (int i=0; i<arrWeather.count; i++)
        {
            NSLog(@"比對：%@=%@：%@",lblCity.text,arrWeather[i][@"CITY"],arrWeather[i][@"TEMP"]);
            //使用縣市『最高氣溫』當做當地氣溫
            if ([lblCity.text isEqualToString:arrWeather[i][@"CITY"]])
            {
                NSLog(@"比對到的氣溫：%@",arrWeather[i][@"TEMP"]);
                //===============計算從平地到目前高度的氣溫===============
                //計算從海平面100公尺與目前所在位置的高度差
                int diffAlititude = floorf(([lblAltitude.text floatValue] - 100)/100);
                //以『現在最高氣溫-(高度差＊0.6度)』當做目前所在地的氣溫
                float currentTemp = [arrWeather[i][@"TEMP"] floatValue] - (diffAlititude*0.6);
                //轉回主要執行緒才能更動UI
                dispatch_async(dispatch_get_main_queue(), ^{
                    //顯示對應氣溫(減掉上升高度後的氣溫)
                    lblTemp.text = [NSString stringWithFormat:@"%.1f°C",currentTemp];
                });
                //記錄有比對到氣溫
                TEMP_not_Found = NO;
                //找到對應氣溫就跳出迴圈
                break;
            }
        }
    }
}

@end
