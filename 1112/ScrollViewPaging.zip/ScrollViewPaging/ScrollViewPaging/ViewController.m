#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;

@end

@implementation ViewController
@synthesize scrollView,pageControl;

- (void)viewDidLoad
{
    [super viewDidLoad];
    //==========設定UIPageControll元件==========
    pageControl.numberOfPages = 5;  //換頁的頁數
    pageControl.currentPage = 0;    //起始頁
    //===========設定UIScrollView元件===========
    scrollView.pagingEnabled = YES; //可以換頁
    //不要顯示捲軸
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    //不要往上捲動
    scrollView.scrollsToTop = NO;
    //指定scrollView的代理人
    scrollView.delegate = self;
    //取得scrollView的大小
    CGFloat width = scrollView.frame.size.width;
    CGFloat height = scrollView.frame.size.height;
    //指定可以捲動的區域大小
    scrollView.contentSize = CGSizeMake(width * 5, height);
    //-------------製作scrollView的顯示內容-------------
    for (int i=0; i<pageControl.numberOfPages; i++)
    {
        //錯開x軸的位置
        CGRect imgFrame = CGRectMake(width*(CGFloat)i, 0, width, height);
        //準備圖片
        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"%i.gif",i+1]]];
        //設定imageView位置（即錯開的x軸位置）
        imageView.frame = imgFrame;
        //將錯開位置的圖片加入到scrollView
        [scrollView addSubview:imageView];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

//點擊換頁元件
- (IBAction)btnPageChange:(UIPageControl *)sender
{
    //取得scrollView的大小
    CGFloat width = scrollView.frame.size.width;
    CGFloat height = scrollView.frame.size.height;
    CGRect imgFrame = CGRectMake(width*sender.currentPage, 0, width, height);
    //捲動到frame的位置
    [scrollView scrollRectToVisible:imgFrame animated:YES];
}

#pragma mark - UIScrollViewDelegate
//scrollView發生捲動時
-(void)scrollViewDidScroll:(UIScrollView *)aScrollView
{
    //取得scrollView的大小
    CGFloat width = aScrollView.frame.size.width;
    int currentPage = scrollView.contentOffset.x - width / 2;
    pageControl.currentPage = currentPage;
}


@end
