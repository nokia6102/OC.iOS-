import UIKit

class ViewController: UIViewController,UIScrollViewDelegate
{
    @IBOutlet weak var scrollView: UIScrollView!
    //宣告imageView物件
    var imageView:UIImageView!
    //記錄設備目前寬與高
    var DeviceWidth:CGFloat = 0
    var DeviceHeight:CGFloat = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //取得預設的寬與高
        DeviceWidth = UIScreen.mainScreen().bounds.size.width
        DeviceHeight = UIScreen.mainScreen().bounds.size.height
        //初始化imageView
        imageView = UIImageView(image: UIImage(named: "tree.jpg"))
        print("寬：\(DeviceWidth)，高：\(DeviceHeight)")
        //將imageView加入scrollView
        scrollView.addSubview(imageView)
        //指派scrollView的代理人
        scrollView.delegate = self
        //設定可視範圍
        scrollView.contentSize = imageView.frame.size;
        //設定縮放倍率
        scrollView.minimumZoomScale = 0.1
        scrollView.maximumZoomScale = 2
        //設定scrollView的回彈位置
        scrollView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0)
    }
    
    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews()
        print("配置改變！")
        //調整scrollView的大小，使其與螢幕的寬高一致
        scrollView.frame = CGRectMake(0, 0, DeviceWidth, DeviceHeight)
//        //取得設備方向
//        let orientation = UIDevice.currentDevice().orientation
//        switch orientation
//        {
//            case .LandscapeLeft,.LandscapeRight:
//                print("橫向～寬：\(DeviceWidth)，高：\(DeviceHeight)")
//            default:
//                //重新設定scrollView的寬與高
//                print("直向～寬：\(DeviceWidth)，高：\(DeviceHeight)")
//        }
        //調整放大倍率
        if DeviceWidth <= imageView.frame.size.width
        {
            scrollView.zoomScale = DeviceWidth / imageView.frame.size.width
        }
        else
        {
            scrollView.zoomScale = imageView.frame.size.width / DeviceWidth
        }
        print("倍率：\(scrollView.zoomScale)")
    }

    //支援的旋轉方向
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask
    {
        return UIInterfaceOrientationMask.All
    }
    
    //當寬高有所變化時（注意：此事件觸發之後，接著會觸發viewDidLayoutSubviews）
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator)
    {
        //記錄目前寬高(必須從參數size才能取得即將轉換過去的寬與高)
        DeviceWidth = size.width
        DeviceHeight = size.height
        print("寬：\(DeviceWidth)，高：\(DeviceHeight)")
        //先復原縮放比例（等viewDidLayoutSubviews發生時，再調整成適當比例！）
        scrollView.zoomScale = 1
    }
    
    //MARK: UIScrollViewDelegate
    //指定可以拖動與縮放的元件
    func viewForZoomingInScrollView(scrollView: UIScrollView) -> UIView?
    {
        return imageView
    }
}

