#import "ViewController.h"

@interface ViewController ()
{
    //宣告imageView物件
    UIImageView *imageView;
    //記錄設備目前寬與高
    CGFloat DeviceWidth;
    CGFloat DeviceHeight;
}
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@end

@implementation ViewController
@synthesize scrollView;

- (void)viewDidLoad
{
    [super viewDidLoad];
    //取得預設的寬與高
    DeviceWidth = [UIScreen mainScreen].bounds.size.width;
    DeviceHeight = [UIScreen mainScreen].bounds.size.height;
    NSLog(@"(寬,高)=(%f,%f)",DeviceWidth,DeviceHeight);
    //初始化image
    imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"trees.jpg"]];
    //調整imageView的frame跟scrollView一樣大
//    imageView.frame = scrollView.frame;
    
    NSLog(@"imageView的大小：(%f,%f)",imageView.frame.size.width,imageView.frame.size.height);
    //將imageView加入scrollView
    [scrollView addSubview:imageView];
    //指派scrollView的代理人
    scrollView.delegate = self;
    //設定可視範圍
    scrollView.contentSize = imageView.frame.size;
    //調整scrollView的大小，使其與螢幕的寬高一致
    scrollView.frame = CGRectMake(0, 0, DeviceWidth, DeviceHeight);
    //設定scrollView的回彈位置
    scrollView.contentInset = UIEdgeInsetsMake(-100, -100, 0, -20);
    //設定縮放倍率
    scrollView.minimumZoomScale = 0.1;
    scrollView.maximumZoomScale = 2;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

//支援的旋轉方向
-(UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    //支援所有方向
    return UIInterfaceOrientationMaskAll;
}

//當寬高有所變化時<設備旋轉iOS8以後>
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    //記錄目前寬高
    DeviceWidth = size.width;
    DeviceHeight = size.height;
    //重新設定scrollView的寬與高
    scrollView.frame = CGRectMake(0, 0, DeviceWidth, DeviceHeight);
}

#pragma mark - UIScrollViewDelegate
//指定可以拖動與縮放的元件
-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return imageView;
}

@end
