//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//宣告販賣機會拋出的錯誤形態
enum VendingMachineError: ErrorType
{
    case InvalidSelection       //無此商品
    case InsufficientFunds(coinsNeeded: Int)    //投入金額不足
    case OutOfStock             //商品庫存量不足
}

throw VendingMachineError.InsufficientFunds(coinsNeeded: 5)
throw VendingMachineError.OutOfStock

func canThrowErrors() throws -> String
{
    throw VendingMachineError.InsufficientFunds(coinsNeeded: 5)
}

//販賣的商品
struct Item
{
    var price: Int  //商品價格
    var count: Int  //商品數量
}

//自動販賣機類別
class VendingMachine
{
    //商品庫存的詞典
    var inventory = [
        "Candy Bar": Item(price: 12, count: 7),
        "Chips": Item(price: 10, count: 4),
        "Pretzels": Item(price: 7, count: 11)   //棒狀椒鹽脆餅
    ]
    var coinsDeposited = 0      //投入硬幣的數量
    func dispenseSnack(snack: String)   //顯示販賣機配發購買商品的訊息
    {
        print("Dispensing \(snack)")
    }
    //販賣機實際販賣商品的方法
    func vend(itemNamed name: String) throws
    {
        guard var item = inventory[name]    //檢查要購買的商品是否存在
        else
        {
            throw VendingMachineError.InvalidSelection  //拋出商品不存在的錯誤
        }
        
        guard item.count > 0                //檢查商品是否有庫存量
        else
        {
            throw VendingMachineError.OutOfStock    //拋出沒有庫存量的錯誤
        }
        
        guard item.price <= coinsDeposited      //檢查投入金額是否充足
        else
        {
            throw VendingMachineError.InsufficientFunds(coinsNeeded: item.price - coinsDeposited)
        }
        //售出後扣除商品價格
        coinsDeposited -= item.price  //coinsDeposited = coinsDeposited-item.price
        --item.count            //扣除商品的數量
        inventory[name] = item  //將扣除數量後的商品結構，回寫入商品庫存詞典
        dispenseSnack(name)     //顯示販賣機配發購買商品的訊息
    }
}
//使用販賣機類別
var aVendingMachine = VendingMachine()
//投入硬幣
aVendingMachine.coinsDeposited = 15
//購買Chips
do
{
    try aVendingMachine.vend(itemNamed: "Chips")
}
catch VendingMachineError.InvalidSelection  //接住錯誤
{
    print("沒有這個商品")                 //顯示對應訊息給使用者
}
catch VendingMachineError.OutOfStock
{
    print("庫存不足")
}
catch VendingMachineError.InsufficientFunds(let coinsNeeded)
{
    print("金額不足：\(coinsNeeded)")
}

//不處理錯誤
let _ = try! aVendingMachine.vend(itemNamed: "aaa")
let _ = try? aVendingMachine.vend(itemNamed: "aaa")











