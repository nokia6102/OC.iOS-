import UIKit

class MoveableImageView: UIImageView
{
//    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?)
//    {
//        super.touchesMoved(touches, withEvent: event)
//        
//        if let touch = touches.first
//        {
//            //計算x軸和y軸移動前後的差值
//            let deltaX:CGFloat = touch.locationInView(self).x - touch.preciseLocationInView(self).x
//            let deltaY:CGFloat = touch.locationInView(self).y - touch.preciseLocationInView(self).y
//            //指定以中心點為軸心的矩陣轉換（執行仿射轉換運算）
//            self.transform = CGAffineTransformTranslate(self.transform, deltaX, deltaY)
//        }
//    }
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?)
    {
        super.touchesMoved(touches, withEvent: event)
        if let touch = touches.first
        {
            //計算x軸與y軸移動前後的差值
            let deltaX:CGFloat = touch.locationInView(self).x - touch.previousLocationInView(self).x
            let deltaY:CGFloat = touch.locationInView(self).y - touch.previousLocationInView(self).y
            //指定以中心點為軸心的矩陣轉換（執行仿射轉換運算）
            self.transform = CGAffineTransformTranslate(self.transform, deltaX, deltaY)
        }
    }
}
