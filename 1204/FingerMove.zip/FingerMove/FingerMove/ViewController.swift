import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var toolBar: UIToolbar!
    @IBOutlet weak var imgStar: UIImageView!
    //記錄觸碰的起點與終點
    var touchStartPosition:CGPoint!
    var touchEndPosition:CGPoint!
    //MARK: View Life Cycle
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //開啟多指觸碰功能
        self.view.multipleTouchEnabled = true
    }
    //介面已經佈置完成時
    override func viewDidLayoutSubviews()
    {
        //工具列先上推
        toolBar.frame = CGRect(x: 0, y: -toolBar.frame.size.height, width: UIScreen.mainScreen().bounds.size.width, height: toolBar.frame.size.height)
        //隱藏星星
        imgStar.alpha = 0
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Touch Event
    //觸碰開始
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?)
    {
        super.touchesBegan(touches, withEvent: event)
//        print("觸碰開始")
//        print("觸碰開始：共\(touches.count)隻手指觸碰")
        //將記錄的觸碰起點和終點位置歸零
        touchStartPosition = CGPoint(x: 0, y: 0)
        touchEndPosition = CGPoint(x: 0, y: 0)
        //先拿到第一隻手指
        if let touch = touches.first
        {
//            if touch.tapCount == 1
//            {
            //拿到觸碰的開始位置
            touchStartPosition = touch.locationInView(self.view)
            print("觸碰位置：\(touchStartPosition)")
//            }
        }
    }
    //觸碰中移動
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?)
    {
        super.touchesMoved(touches, withEvent: event)
//        print("觸碰中移動")
//        print("移動中：共\(touches.count)隻手指")
        //先拿到第一隻手指
        if let touch = touches.first
        {
//            if touch.tapCount == 1
//            {
            //拿到觸碰中移動的位置
            touchEndPosition = touch.locationInView(self.view)
            print("移動位置：\(touchEndPosition)")
            
            //toolbar下拉或上移    // -3 <= x <= 3
            if touchEndPosition.y >= touchStartPosition.y+2 && touchEndPosition.x <= touchStartPosition.x + 3 && touchEndPosition.x >= touchStartPosition.x-3
            {
                //拉下toolbar
                UIView.animateWithDuration(0.5, animations: { () -> Void in
                    self.toolBar.frame = CGRect(x: 0, y: 0, width: UIScreen.mainScreen().bounds.size.width, height: self.toolBar.frame.size.height)
                })
            }
            else if touchEndPosition.y <= touchStartPosition.y-2 && touchEndPosition.x <= touchStartPosition.x + 3 && touchEndPosition.x >= touchStartPosition.x-3
            {
                //推回toolbar
                UIView.animateWithDuration(0.5, animations: { () -> Void in
                    self.toolBar.frame = CGRect(x: 0, y: -self.toolBar.frame.size.height, width: UIScreen.mainScreen().bounds.size.width, height: self.toolBar.frame.size.height)
                })
//            }
            }
        }
    }
    //觸碰結束
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?)
    {
        super.touchesMoved(touches, withEvent: event)
        print("觸碰結束")
        //先拿到第一隻手指
        if let touch = touches.first
        {
//            if touch.tapCount == 1
//            {
            //拿到觸碰結束的位置
            touchEndPosition = touch.locationInView(self.view)
            //先把星星移到點擊位置
            imgStar.center = touchEndPosition
            //顯現及隱藏星星
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.imgStar.alpha = 1
                }, completion: { (finished) -> Void in
                    UIView.animateWithDuration(0.3, animations: { () -> Void in
                        self.imgStar.alpha = 0
                    })
            })
//            }
        }
    }
}

