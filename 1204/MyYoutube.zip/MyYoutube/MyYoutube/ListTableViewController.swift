import UIKit

class ListTableViewController: UITableViewController
{
    //網路傳輸物件
    let session = NSURLSession.sharedSession()  //初始化
    var dataTask:NSURLSessionDataTask!
    //網址字串
    var strURL:String!
    //網址物件
    var url:NSURL!
    //Youtube傳來的整本詞典
    var theDicSearchResult:Dictionary<NSObject, AnyObject>!
    //Youtube詞典中Items關鍵詞內所列出的項目列表
    var arrItem = Array<Dictionary<NSObject, AnyObject>>()
    
    //MARK: View Life Cycle
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(animated: Bool)
    {
        print("viewDidAppear:\(theDicSearchResult)")
        //注意：theDicSearchResult從函式接收後，要一直等到此事件才會有資料
        //取得所有的搜尋結果項目
        arrItem = theDicSearchResult["items"] as! Array<Dictionary<NSObject, AnyObject>>
        //重整TableView（因為ViewDidLoad時，theDicSearchResult還沒有資料                                                                         ）
        self.tableView.reloadData()
    }
    
    //MARK: - Table view data source
    //資料筆數
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrItem.count
    }
    //準備每一個儲存格
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("MyCell", forIndexPath: indexPath) as! YoutubeTableViewCell
        let dicSnippet = arrItem[indexPath.row]["snippet"] as! Dictionary<NSObject, AnyObject>
        cell.lblTitle.text = dicSnippet["title"] as? String
        cell.txtDescription.text = dicSnippet["description"] as! String
        cell.lblVedioID.text = arrItem[indexPath.row]["id"]!["videoId"] as? String
        //------------------------------影片縮圖------------------------------------
        //        print("圖：\(dicSnippet["thumbnails"]!["default"]!!["url"] as! String)")
        strURL = dicSnippet["thumbnails"]!["default"]!!["url"] as! String
        url = NSURL(string: strURL)
        dataTask = session.dataTaskWithURL(url, completionHandler: { (imageData, response, error) -> Void in
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                cell.imgPicture.image = UIImage(data: imageData!)
            })
        })
        //執行下載
        dataTask.resume()
        //------------------------------------------------------------------------
        return cell
    }
    //儲存格被點選
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        //取得選定儲存格中的vedioID
        let vedioID = (self.tableView.cellForRowAtIndexPath(indexPath) as! YoutubeTableViewCell).lblVedioID.text!
        //開啟Youtube
        let strURL = "https://youtu.be/" + vedioID
        let url = NSURL(string: strURL)
        UIApplication.sharedApplication().openURL(url!)
    }
    
    //MARK: 自訂函式
    //接收上一頁的搜尋結果
    func passSearchResult(aDicSearchResult:Dictionary<NSObject, AnyObject>)
    {
        print("pass:\(theDicSearchResult)")
        theDicSearchResult = aDicSearchResult
    }
    
}
