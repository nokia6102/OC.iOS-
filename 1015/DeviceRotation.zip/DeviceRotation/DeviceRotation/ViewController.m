#import "ViewController.h"

@interface ViewController ()
{
    //記錄設備目前寬與高
    CGFloat DeviceWidth;
    CGFloat DeviceHeight;
}
@property (weak, nonatomic) IBOutlet UIImageView *imgSignal;

@end

@implementation ViewController
@synthesize imgSignal;
- (void)viewDidLoad
{
    [super viewDidLoad];
    //取得預設的寬與高
    DeviceWidth = [UIScreen mainScreen].bounds.size.width;
    DeviceHeight = [UIScreen mainScreen].bounds.size.height;
    //依據設備方向換圖
    [self Change_imgSignal];
}

-(void)viewWillAppear:(BOOL)animated
{
    
}

-(void)viewDidAppear:(BOOL)animated
{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//支援的旋轉方向
- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    //支援所有方向
    return UIInterfaceOrientationMaskAll;
//    return UIInterfaceOrientationMaskLandscape;
//    return (UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight);
//    return (UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskPortraitUpsideDown);
}

////即將旋轉(iOS7以前)
//-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
//{
//    
//}
////已經旋轉(iOS7以前)
//-(void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
//{
//    
//}

//當寬高有所變化時<設備旋轉iOS8以後>
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    NSLog(@"寬：%.0f高：%.0f",size.width,size.height);
    //記錄目前寬高
    DeviceWidth = size.width;
    DeviceHeight = size.height;
    //依據設備方向換圖
    [self Change_imgSignal];
    
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
        //伴隨著旋轉而執行的動畫寫在此！
        
    } completion:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
        //旋轉完成後執行的動畫！
//        [UIView animateWithDuration:1.5 animations:^{
//            imgSignal.frame = CGRectMake(DeviceWidth-imgSignal.frame.size.width, 10, imgSignal.frame.size.width, imgSignal.frame.size.height);
//            imgSignal.alpha = 0.5;
//        }];
        [UIView animateWithDuration:1.5 animations:^{
            //第一段動畫
            imgSignal.frame = CGRectMake(DeviceWidth-imgSignal.frame.size.width, 10, imgSignal.frame.size.width, imgSignal.frame.size.height);
            imgSignal.alpha = 0.5;
        } completion:^(BOOL finished) {
            //第二段動畫
            [UIView animateWithDuration:1.5 animations:^{
                imgSignal.frame = CGRectMake(imgSignal.frame.origin.x, DeviceHeight-imgSignal.frame.size.height, imgSignal.frame.size.width, imgSignal.frame.size.height);
                imgSignal.alpha = 1;
            } completion:^(BOOL finished) {
                //第三段動畫
                [UIView animateWithDuration:1.5 animations:^{
                    imgSignal.frame = CGRectMake(10, imgSignal.frame.origin.y, imgSignal.frame.size.width, imgSignal.frame.size.height);
                    imgSignal.alpha = 0.5;
                } completion:^(BOOL finished) {
                    //第四段動畫
                    [UIView animateWithDuration:1.5 animations:^{
                        imgSignal.frame = CGRectMake(imgSignal.frame.origin.x, 10, imgSignal.frame.size.width, imgSignal.frame.size.height);
                        imgSignal.alpha = 1;
                    }];
                }];
            }];
        }];
    }];
}
//依據設備方向換圖
-(void)Change_imgSignal
{
    //取得目前設備的方向
    UIDeviceOrientation orientation = [UIDevice currentDevice].orientation;
    if (orientation == UIDeviceOrientationLandscapeLeft || orientation == UIDeviceOrientationLandscapeRight)
    {
        NSLog(@"現在是橫向");
        //        imgSignal.image = [UIImage imageNamed:@"landscape.png"];
        //設備是iPad
        if (self.traitCollection.userInterfaceIdiom == UIUserInterfaceIdiomPad)
        {
            NSLog(@"現在是iPad");
            imgSignal.image = [UIImage imageNamed:@"landscape_iPad.png"];
        }
        else    //設備是iPhone
        {
            NSLog(@"現在是iPhone");
            imgSignal.image = [UIImage imageNamed:@"landscape_iPhone.png"];
        }
    }
    else    //設備直向時
    {
        NSLog(@"現在直向");
        //        imgSignal.image = [UIImage imageNamed:@"portrait.png"];
        //設備是iPad
        if (self.traitCollection.userInterfaceIdiom == UIUserInterfaceIdiomPad)
        {
            NSLog(@"現在是iPad");
            imgSignal.image = [UIImage imageNamed:@"portrait_iPad.png"];
        }
        else    //設備是iPhone
        {
            NSLog(@"現在是iPhone");
            imgSignal.image = [UIImage imageNamed:@"portrait_iPhone.png"];
        }
    }
}

//移動按鈕
- (IBAction)btnMove:(UIButton *)sender
{
    NSLog(@"移動按鈕被按下");
    
    //運行動畫
    [UIView animateWithDuration:1.5 animations:^{
        //第一段動畫
        imgSignal.frame = CGRectMake(DeviceWidth-imgSignal.frame.size.width, 10, imgSignal.frame.size.width, imgSignal.frame.size.height);
        imgSignal.alpha = 0.5;
    } completion:^(BOOL finished) {
        //第二段動畫
        [UIView animateWithDuration:1.5 animations:^{
            imgSignal.frame = CGRectMake(imgSignal.frame.origin.x, DeviceHeight-imgSignal.frame.size.height, imgSignal.frame.size.width, imgSignal.frame.size.height);
            imgSignal.alpha = 1;
        } completion:^(BOOL finished) {
            //第三段動畫
            [UIView animateWithDuration:1.5 animations:^{
                imgSignal.frame = CGRectMake(10, imgSignal.frame.origin.y, imgSignal.frame.size.width, imgSignal.frame.size.height);
                imgSignal.alpha = 0.5;
            } completion:^(BOOL finished) {
                //第四段動畫
                [UIView animateWithDuration:1.5 animations:^{
                    imgSignal.frame = CGRectMake(imgSignal.frame.origin.x, 10, imgSignal.frame.size.width, imgSignal.frame.size.height);
                    imgSignal.alpha = 1;
                }];
            }];
        }];
    }];
}

@end
