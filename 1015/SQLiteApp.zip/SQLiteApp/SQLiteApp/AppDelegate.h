#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    //資料庫指標
    sqlite3 *db;
}
@property (strong, nonatomic) UIWindow *window;

//回傳資料庫指標的getter
-(sqlite3*)getDB;

@end

