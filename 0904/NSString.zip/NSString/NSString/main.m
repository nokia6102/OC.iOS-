#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //=============不可變更的字串物件(19.2.1)=============
        //c語言字串可用指標或陣列的方式宣告
        char *str = "我是iPhone";
        char strx[] = "我是iPhone";
        //將c語言字串轉成NSString
        NSString *str1 = [[NSString alloc] initWithUTF8String:str];
//        NSString *str1 = [NSString stringWithUTF8String:str];
        NSLog(@"%@",str1);
        
        NSString *str2 = @"我是Macbook Pro";
        
        NSLog(@"%@ and %@",str1,str2);
        NSLog(@"字串大小~str1:%lu,str2:%lu",str1.length,str2.length);
        
        //=======字串的格式化=========
        //建立兩個數字
        int intNumber = 10;
        double doubleNumber;
        str1 = [NSString stringWithFormat:@"[%i]",intNumber];
        NSLog(@"格式化字串：%@",str1);
        
        str1 = [NSString stringWithFormat:@"%i",intNumber];
        NSLog(@"格式化數字：%@",str1);
        NSLog(@"從文字轉回數字：%i",str1.intValue);
        ;
        
        doubleNumber = str1.doubleValue;
        NSLog(@"從文字整數轉成浮點數：%.1f",doubleNumber);
        
        NSLog(@"*************************************");
        
        //=======字串串接=======
        str1 = @"Apple's ";
        str1 = [str1 stringByAppendingString:@"iPhone 4"];
        NSLog(@"字串串接:%@",str1);
        //回傳的字元位置從零起算
        NSLog(@"特定位置的字元：%c",[str1 characterAtIndex:4]);
        //回傳區間字串
        NSLog(@"區間字串：%@",[str1 substringWithRange:NSMakeRange(8, 6)]);
        NSLog(@"*************************************");
        //=======字串分割=======
        str1 = @" iMac , iPod , iPad ";
        NSLog(@"切開前~%@",str1);
        NSArray *strArray = [str1 componentsSeparatedByString:@","];
        for (int i=0; i<strArray.count; i++)
        {
            NSLog(@"切開後~[%i]:%@",i,strArray[i]);
        }
        //去除NSString物件的前後空白
        int i = 0;
        for (NSString *temp in strArray)
        {
            NSLog(@"切開後~[%i]:%@",i,[temp stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]);
            i++;
        }
        NSLog(@"*************************************");
        
        //建立特殊字元的字元集(想要去除的字元)
        NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@" *-\n"]; //換行字元：\r\n（windows） \n(Mac)
        //重新設定包含特殊字元的字串
        str1 = @"*iMac-, iPod*,-iPad ";
        NSLog(@"自訂字元集切開前~%@",str1);
        strArray = [str1 componentsSeparatedByString:@","];
        int j = 0;
        for (NSString *temp in strArray)
        {
            NSLog(@"切開後~[%i]:%@",j,temp);
            NSLog(@"切開後~[%i]:%@",j,[temp stringByTrimmingCharactersInSet:set]);
            j++;
        }
        NSLog(@"*************************************");
        //字串相等比較
        str1 = @"Hello World!!";
        str2 = @"Hello World!!";
//        if ([str1 isEqualToString:@"Hello World!"])
//        if ([str1 isEqualToString:str2])
        if (str1 == str2)
        {
            NSLog(@"str1:%@與str2:%@字串內容相同！",str1,str2);
        }
        else
        {
            NSLog(@"str1:%@與str2:%@字串內容不同！",str1,str2);
        }
        //字串的順序
        str1 = @"Hello Today!!";
        NSComparisonResult result = [str1 compare:@"Hello World!!"];
        if (result == NSOrderedAscending)
        {
            NSLog(@"字串遞增");
        }
        else if (result == NSOrderedDescending)
        {
            NSLog(@"字串遞減");
        }
        else
        {
            NSLog(@"字串順序相同！");
        }
        //字串大小寫轉換
        NSString *upperCase = [str1 uppercaseString];
        NSString *lowerCase = [str1 lowercaseString];
        NSLog(@"轉大寫：%@",upperCase);
        NSLog(@"轉小寫：%@",lowerCase);
        NSLog(@"*************************************");
        
        //=============可變更的字串物件(19.2.2)=============
        str1 = @"str1";
        //可變更字串的容量大小不限於給定的大小
        NSMutableString *mStr2 = [NSMutableString stringWithCapacity:10];
        NSLog(@"str1的記憶體位址為：%x,內容為：%@",(unsigned)&str1,str1);
        NSLog(@"mStr2的記憶體位址為：%x,內容為：%@",(unsigned)&mStr2,mStr2);
        NSLog(@"*************************************");
        //===============加入字串內容===============
        //不可變更字串的串接
        str1 = [str1 stringByAppendingString:@" strOne."];
        //可變更字串的串接
        [mStr2 appendString:@"strTwo."];
        
        NSLog(@"str1的記憶體位址為：%x,串接後內容為：%@",(unsigned)&str1,str1);
        NSLog(@"mStr2的記憶體位址為：%x,串接後內容為：%@",(unsigned)&mStr2,mStr2);
        NSLog(@"*************************************");
        //刪除字串
        [mStr2 deleteCharactersInRange:NSMakeRange(3, 3)];
        NSLog(@"mStr2的記憶體位址為：%x,刪除後內容：%@",(unsigned)&mStr2,mStr2);
        //插入字串
        [mStr2 insertString:@"TWOTWOTWO" atIndex:3];
        NSLog(@"mStr2的記憶體位址為：%x,插入後內容：%@",(unsigned)&mStr2,mStr2);
    }
    return 0;
}
