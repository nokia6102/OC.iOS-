#import <Foundation/Foundation.h>

//p與q的值互換(參數使用傳址)，r設定新值
void ChangeByAddress(int *p,int *q,int *r);
//p與q的值互換(參數使用傳值)，r設定新值
void ChangeByValue(int p,int q,int r);
//計算陣列總和(傳入陣列指標及陣列大小)
int sumOfArray(int parr[],int n);

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //============指標的定義(9.1)============
        int a = 100;
        int *ptr;
        //把a變數的記憶體位置，抄錄到ptr指標變數
        ptr = &a;
        NSLog(@"ptr=%x,&a=%x",(unsigned)ptr,(unsigned)&a);
        //只針對a變數變更
        a = 101;
        //ptr所指的位置也會跟著變更
        NSLog(@"a=%i,*ptr=%i",a,*ptr);
        //只針對ptr變數變更
        *ptr = 102;
        NSLog(@"a=%i,*ptr=%i",a,*ptr);
        
        NSLog(@"***************************************");
        //============指標與函式(9.2)============
        int x = 666, y = 888, z = 999;
        NSLog(@"傳址呼叫～");
        NSLog(@"<變更前>x=%i,y=%i,z=%i",x,y,z);
        ChangeByAddress(&x, &y, &z);  //call by address
        NSLog(@"<變更後>x=%i,y=%i,z=%i",x,y,z);
        NSLog(@"***************************************");
        NSLog(@"傳值呼叫～");
        NSLog(@"<變更前>x=%i,y=%i,z=%i",x,y,z);
        ChangeByValue(x, y, z);  //call by value
        NSLog(@"<變更後>x=%i,y=%i,z=%i",x,y,z);
        NSLog(@"***************************************");
        //============指標與陣列(9.3)============
        int arr[] = {10,20,30,40,50};
        int *parr = arr;
        //紀錄陣列大小
        int num;
        num = sizeof(arr)/sizeof(arr[0]);
        
        //以陣列方式列印陣列元素
        for (int i=0; i<num; i++)
        {
            NSLog(@"<陣列>陣列的第%i個元素為：%i",i,arr[i]);
        }
        
        //以指標的方式列印陣列元素
        for (int i=0; i<num; i++)
        {
            NSLog(@"<指標>陣列的第%i個元素為：%i",i,*(arr+i));
        }
        
        //以指標的方式列印陣列元素
        for (int i=0; i<num; i++)
        {
            NSLog(@"<新指標>陣列的第%i個元素為：%i",i,*(parr+i));
        }
        //呼叫外部函式計算陣列總和
        NSLog(@"陣列元素的總和：%i",sumOfArray(arr, num));
        //呼叫外部函式計算陣列總和
        NSLog(@"陣列元素的總和：%i",sumOfArray(parr, num));
    }
    return 0;
}
//p與q的值互換(參數使用傳址)，r設定新值
void ChangeByAddress(int *p,int *q,int *r)
{
    NSLog(@"<交換前>p=%i,q=%i,r=%i",*p,*q,*r);
    //暫存其中一個更換前的值
    int temp;
    //執行數值交換
    temp = *p;
    *p = *q;
    *q = temp;
    *r = 1000;
    NSLog(@"<交換後>p=%i,q=%i,r=%i",*p,*q,*r);
}
//p與q的值互換(參數使用傳值)，r設定新值
void ChangeByValue(int p,int q,int r)
{
    NSLog(@"<交換前>p=%i,q=%i,r=%i",p,q,r);
    //暫存其中一個更換前的值
    int temp;
    //執行數值交換
    temp = p;
    p = q;
    q = temp;
    r = 2000;
    NSLog(@"<交換後>p=%i,q=%i,r=%i",p,q,r);
}

//計算陣列總和(傳入陣列指標及陣列大小)
int sumOfArray(int parr[],int n)
//int sumOfArray(int *parr,int n)
{
    //儲存陣列總和
    int tot = 0;
    //加總陣列總和
    for (int i=0; i<n; i++)
    {
        tot = tot + parr[i];
    }
    //回傳陣列總和
    return tot;
}
