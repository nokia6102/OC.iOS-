#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    //===============可變更的資料集物件===============
    NSMutableSet *set1 = [NSMutableSet new];
    NSMutableSet *set2 = [NSMutableSet setWithObjects:@1,@4,@6, nil];
    //在資料集中加入新的物件
    [set1 addObject:@3];
    [set1 addObject:@4];
    [set1 addObject:@8];
    [set1 addObject:@8];  //重複的部分只會存在一次
    
//    for (NSNumber *i in set1)
//    {
//        NSLog(@"%d",i.intValue);
//    }
    NSLog(@"set1:");
    [self showIntegerSet:set1];
    
//    for (NSNumber *i in set2)
//    {
//        NSLog(@"%d",i.intValue);
//    }
    NSLog(@"set2:");
    [self showIntegerSet:set2];
    
    //連集運算
    [set1 unionSet:set2];
    NSLog(@"連集後");
    [self showIntegerSet:set1];
    
    //先將set1的元素重置
    set1 = [NSMutableSet setWithObjects:@3,@4,@8, nil];
    //差集運算
    [set1 minusSet:set2];
    NSLog(@"差集後");
    [self showIntegerSet:set1];
    
    //先將set1的元素重置
    set1 = [NSMutableSet setWithObjects:@3,@4,@8, nil];
    //交集運算
    [set1 intersectSet:set2];
    NSLog(@"交集後");
    [self showIntegerSet:set1];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//- (void)viewDidDisappear:(BOOL)animated

- (void)showIntegerSet:(NSMutableSet*)aSet
{
    for (NSNumber *i in aSet)
    {
        NSLog(@"%d",i.intValue);
    }
}

@end
