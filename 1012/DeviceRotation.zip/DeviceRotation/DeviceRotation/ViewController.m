#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imgSignal;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//支援的旋轉方向
- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    //支援所有方向
    return UIInterfaceOrientationMaskAll;
//    return UIInterfaceOrientationMaskLandscape;
//    return (UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight);
}
//當寬高有所變化時
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    NSLog(@"寬：%.0f高：%.0f",size.width,size.height);
}

@end
