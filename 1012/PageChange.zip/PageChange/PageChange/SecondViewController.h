#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
//接收上一頁傳來的輸入內容
- (void)passData:(NSString*)strInput;
@end
