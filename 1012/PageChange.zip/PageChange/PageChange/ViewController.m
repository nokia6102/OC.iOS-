#import "ViewController.h"
#import "SecondViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *txtNo;
@property (weak, nonatomic) IBOutlet UITextField *txtName;

@end

@implementation ViewController
#pragma mark - ViewLifeCycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"view1載入完成");
    self.txtNo.delegate = self;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSLog(@"view1即將被加入");
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSLog(@"view1已被加入");
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    NSLog(@"view1即將被移除");
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    NSLog(@"view1已被移除");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NSLog(@"正準備切換到下一頁");
    //    segue.sourceViewController  //==self
    SecondViewController *vc;
    vc = (SecondViewController*)segue.destinationViewController;
    //傳遞參數到下一頁
    [vc passData:self.txtNo.text];
}

#pragma mark - TargetAction
//下一頁2按鈕
- (IBAction)btnNextPage2_Pressed:(UIButton *)sender
{
    [self performSegueWithIdentifier:@"NextPageAction" sender:nil];
}
//下一頁3按鈕
- (IBAction)btnNextPage3_Pressed:(UIButton*)sender
{
    //從storyboard上取得下一個畫面的物件
    SecondViewController *vc;
    vc = [self.storyboard instantiateViewControllerWithIdentifier:@"secondViewController"];
    
    //傳遞參數到下一頁
    [vc passData:self.txtNo.text];
    
    //顯示下一頁
    [self presentViewController:vc animated:YES completion:nil];
//    //3-9顯示下一頁的方法
//    [self showDetailViewController:vc sender:nil];
}

- (IBAction)didEndOnExit:(UITextField *)sender
{
//    [sender resignFirstResponder];
}

#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)handleTap:(UITapGestureRecognizer *)sender
{
    [self.txtNo resignFirstResponder];
    [self.txtName resignFirstResponder];
}

- (IBAction)handleSwipe:(UISwipeGestureRecognizer *)sender
{
    [self performSegueWithIdentifier:@"NextPageAction" sender:nil];
}


@end
