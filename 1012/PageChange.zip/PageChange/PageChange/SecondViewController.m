#import "SecondViewController.h"

@interface SecondViewController ()
{
    //記錄上一頁透過『- (void)passData:(NSString*)strInput』方法傳來的strInput
    NSString *strUserInput;
}

@property (weak, nonatomic) IBOutlet UILabel *lblNo;

@end

@implementation SecondViewController
//返回1＆返回2
- (IBAction)Button1Pressed:(UIButton *)sender
{
    //移除第二個畫面
//    [self dismissViewControllerAnimated:YES completion:nil];
    [self dismissViewControllerAnimated:YES completion:^{
        
        NSLog(@"view2從記憶體中移除！");
        
        NSLog(@"『%@』按鈕被按了",sender.titleLabel.text);
        
    }];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"view2載入完成");
    //從全域變數取得上一頁要顯示的資料
    self.lblNo.text = strUserInput;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSLog(@"view2即將被加入");
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSLog(@"view2已被加入");
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    NSLog(@"view2即將被移除");
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    NSLog(@"view2已被移除");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 自訂函式
//接收上一頁傳來的輸入內容
- (void)passData:(NSString*)strInput
{
    NSLog(@"上一頁傳來：%@",strInput);
    //無法顯示訊息！因為viewDidLoad還沒發生，lblNo物件還沒有出現在畫面上！
//    self.lblNo.text = strInput;
    //將傳入的參數，用類別的全域變數記錄下來，以等待ViewDidLoad發生時顯示
    strUserInput = strInput;
    
}

- (IBAction)handleSwipe:(UISwipeGestureRecognizer *)sender
{
    //移除第二個畫面
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
