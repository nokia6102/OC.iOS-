#import "MyTableViewController.h"
#import "MyTableViewCell.h"             //自訂儲存格的類別
#import "DetailViewController.h"        //下一頁的類別

@interface MyTableViewController ()
{
    //網路傳輸物件
    NSURLSession *session;
    NSURLSessionDataTask *dataTask;
    //網址字串
    NSString *strURL;
    //網址物件
    NSURL *url;
    //記錄xml開始標籤的名稱
    NSString *tagName;
    //記錄xml的標籤內容
    NSString *tagContent;
    //記錄從xml解析出來的單一資料行
    NSMutableDictionary *dicRow;
    //下一頁的畫面
    DetailViewController *detailVC;
}

@end

@implementation MyTableViewController
@synthesize arrTable,selectedRow;
#pragma mark - View Life Cycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    //變數初始化
    session = [NSURLSession sharedSession];
    selectedRow = -1;
    dicRow = [NSMutableDictionary new];
    arrTable = [NSMutableArray new];
    
    //取得網站上的xml，並且進行解析
    strURL = @"http://perkinsung.2fh.co/select_data.php";
    //製作NSURL物件
    url = [NSURL URLWithString:strURL];
    //製作網路任務
    dataTask = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable xmlData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        //啟動xml解析
        NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithData:xmlData];
        xmlParser.delegate = self;
        [xmlParser parse];
    }];
    //執行網路任務
    [dataTask resume];
    
    //在導覽列上加上左右按鈕
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"編輯" style:UIBarButtonItemStylePlain target:self action:@selector(btnEditPressed:)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"新增" style:UIBarButtonItemStylePlain target:self action:@selector(btnAddPressed:)];
    //加上navigationItem的標題<方法一>
    self.navigationItem.title = @"PHP App";
    //更改titleView<方法二>
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"paging.jpg"]];
//    imageView.frame = self.navigationItem.titleView.frame;
    imageView.frame = CGRectMake(0, 0, 400, 30);
    self.navigationItem.titleView = imageView;
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//準備轉換到下一頁
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    //從導覽箭頭取得下一頁的畫面
    detailVC = segue.destinationViewController;
    //呼叫下一頁『接收上一頁參數』的方法
    [detailVC passData:self];
}

#pragma mark - Target Action
//編輯按鈕
-(void)btnEditPressed:(UIBarButtonItem*)sender
{
    if (self.tableView.editing)
    {
        self.tableView.editing = NO;
        sender.title = @"編輯";
    }
    else
    {
        self.tableView.editing = YES;
        sender.title = @"完成";
    }
}

//新增按鈕
-(void)btnAddPressed:(UIBarButtonItem*)sender
{
    //加入一個新增資料的畫面
    
}

#pragma mark - Table view data source
//TableView有幾個區段(預設值是一個區段)
//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
//{
//    return 1;
//}

//每一段有幾筆資料
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"有幾筆資料：%lu",(unsigned long)arrTable.count);
    return arrTable.count;
}

//準備每一筆的TableView儲存格資料
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyCell" forIndexPath:indexPath];
//    cell.textLabel.text = [NSString stringWithFormat:@"%li",indexPath.row];
    cell.lblNo.text = arrTable[indexPath.row][@"no"];
    cell.lblName.text = arrTable[indexPath.row][@"name"];
    
//    if ([arrTable[indexPath.row][@"gender"] isEqualToString:@"0"])
    if ([arrTable[indexPath.row][@"gender"] intValue] == 0)
    {
        cell.lblGender.text = @"女";
    }
    else
    {
        cell.lblGender.text = @"男";
    }
    //準備圖片網址（譬如：http://perkinsung.2fh.co/images/101.jpg）
    strURL = [NSString stringWithFormat:@"http://perkinsung.2fh.co/%@",arrTable[indexPath.row][@"picture"]];
//    NSLog(@"圖片路徑：%@",strURL);
    //將圖片網址製成NSURL
    url = [NSURL URLWithString:strURL];
    //製作網路任務
    dataTask = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable imageData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //顯示圖片
            cell.imgPicture.image = [UIImage imageWithData:imageData];
        });
        
    }];
    //執行網路任務
    [dataTask resume];
    
    return cell;
}

#pragma mark - Table view delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    NSLog(@"點選了：%lu",indexPath.row);

    //記錄目前點選的儲存格是哪一行
    selectedRow = indexPath.row;
    
    NSLog(@"點選了：%lu",selectedRow);
}

#pragma mark - NSXMLParserDelegate
//找到開始標籤
-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict
{
    NSLog(@"開始標籤：%@",elementName);
    //記下開始標籤
    tagName = elementName;
}
//找到標籤內容
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)strContent
{
    NSLog(@"標籤內容：%@",strContent);
    //記下標籤內容
    tagContent = strContent;
}
//找到結束標籤
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    NSLog(@"結束標籤：%@",elementName);
    if ([elementName isEqualToString:@"student"])  //整筆資料的結束標籤
    {
        //將一整本詞典寫入陣列
        [arrTable addObject:dicRow];
        //清除整本詞典(Swift可以不寫這行！)
        dicRow = [NSMutableDictionary new];
    }
    else if ([elementName isEqualToString:@"xmlTable"])  //不關心的結束標籤
    {
        //不處理
    }
    else  //欄位的結束標籤
    {
        //逐一將欄位寫入詞典
        dicRow[tagName] = tagContent;
    }
}
//讀完整份xml文件
-(void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"讀完了!");
    NSLog(@"陣列內容：%@",arrTable);
    //轉回主執行才能更動UI的資料
    dispatch_async(dispatch_get_main_queue(), ^{
        //更新tableView的資料
        [self.tableView reloadData];
    });
}

@end
