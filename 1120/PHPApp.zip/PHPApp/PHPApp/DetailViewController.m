#import "DetailViewController.h"

@interface DetailViewController ()
{
    //網路傳輸物件
    NSURLSession *session;
    NSURLSessionDataTask *dataTask;
    //網址字串
    NSString *strURL;
    //網址物件
    NSURL *url;
    //記錄上一頁的類別實體
    MyTableViewController *theSourceVC;
    //存放PickerView的資料來源陣列
    NSArray *arrGender;
    NSArray *arrClass;
    //記錄目前輸入元件的Y軸底部位置
    CGFloat currentObjectBottomYPosition;
}
@property (weak, nonatomic) IBOutlet UILabel *lblNo;
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UIImageView *imgPicture;
@property (weak, nonatomic) IBOutlet UIPickerView *pkvGender;
@property (weak, nonatomic) IBOutlet UITextField *txtPhone;
@property (weak, nonatomic) IBOutlet UITextField *txtAddress;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UIPickerView *pkvClass;
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;
@property UIImagePickerController *imgPicker;
@end

@implementation DetailViewController
@synthesize lblNo,txtName,imgPicture,pkvGender,txtPhone,txtAddress,txtEmail,pkvClass,progressView,imgPicker;
#pragma mark - View Life Cycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    //加入點按手勢收回鍵盤
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(CloseKeyboard)];
    [self.view addGestureRecognizer:tapGesture];
    //初始化Y軸底部位置
    currentObjectBottomYPosition = 0;
    //註冊鍵盤的監聽事件
    //1.鍵盤彈出
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboadrdWillShow:) name:UIKeyboardWillShowNotification object:nil];
    //2.鍵盤收合
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboadrdWillHide:) name:UIKeyboardWillHideNotification object:nil];
    //變數初始化
    session = [NSURLSession sharedSession];
    //初始化PickerView的資料來源陣列
    arrGender = @[@"女",@"男"];
    arrClass = @[@"手機程式開發",@"網頁程式設計"];
    //指派代理人
    pkvGender.delegate = self;
    pkvGender.dataSource = self;
    pkvClass.delegate = self;
    pkvClass.dataSource = self;
    NSLog(@"上一頁點選了:%lu",theSourceVC.selectedRow);
    //顯示對應筆數的資料
    lblNo.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"no"];
    txtName.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"name"];
    txtPhone.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"phone"];
    txtAddress.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"address"];
    txtEmail.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"email"];
    //選定資料欄位中的對應性別
    [pkvGender selectRow:[theSourceVC.arrTable[theSourceVC.selectedRow][@"gender"] integerValue] inComponent:0 animated:YES];
    //取得班別資料
    NSString *myClass = theSourceVC.arrTable[theSourceVC.selectedRow][@"class"];
    //迴圈跑arrClass陣列的內容
    for (int i=0; i<arrClass.count; i++)
    {
        //進行陣列內容與班別資料欄位的比對
        if ([arrClass[i] isEqualToString:myClass])
        {
            //比對arrClass陣列當筆的內容，如果與當筆資料欄位相同，則選定該筆
            [pkvClass selectRow:i inComponent:0 animated:YES];
        }
    }
    //======================顯示照片======================
    //準備圖片網址（譬如：http://perkinsung.2fh.co/images/101.jpg）
    strURL = [NSString stringWithFormat:@"http://perkinsung.2fh.co/%@",theSourceVC.arrTable[theSourceVC.selectedRow][@"picture"]];
    //    NSLog(@"圖片路徑：%@",strURL);
    //將圖片網址製成NSURL
    url = [NSURL URLWithString:strURL];
    //製作網路任務
    dataTask = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable imageData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //顯示圖片
            imgPicture.image = [UIImage imageWithData:imageData];
        });
        
    }];
    //執行網路任務
    [dataTask resume];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Target Action
//收起鍵盤的Did End On Exit觸發事件
- (IBAction)didEndOnExit:(id)sender
{
    [sender resignFirstResponder];
}

//更換照片
- (IBAction)btnChangePhoto:(UIButton *)sender
{

}
//拍照
- (IBAction)btnCamera:(UIButton *)sender
{

}
//檔案上傳
- (IBAction)btnUploadPhoto:(UIButton *)sender
{

}
//更新資料
- (IBAction)btnUpdateData:(UIButton *)sender
{

}

#pragma mark - 自訂方法
//接收上一頁傳來的參數(接收參數為上一頁的類別實體)
-(void)passData:(MyTableViewController*)sourceVC
{
    //記錄上ㄧ頁的實體到全域變數（供viewDidLoad顯示資料時使用）
    theSourceVC = sourceVC;
    NSLog(@"上一頁的陣列：%@",sourceVC.arrTable);
}

//收起鍵盤
-(void)CloseKeyboard
{
    for (UIView *view in self.view.subviews)
    {
        if ([view isKindOfClass:[UITextField class]])
        {
            //如果是UITextField的類別實體，則收起鍵盤
            [view resignFirstResponder];
        }
    }
}

//監聽鍵盤所呼叫的事件-鍵盤彈出
-(void)keyboadrdWillShow:(NSNotification*)sender
{
    NSLog(@"鍵盤彈出");
    //================把畫面往上移================
    //取得通知中心的資料
    NSDictionary *userInfo = sender.userInfo;
    if (userInfo)
    {
        //從通知中心的資料中取得鍵盤高度
        CGFloat keyboardHeight = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
        if (keyboardHeight > 0)
        {
            //計算可視高度
            CGFloat visibleHeight = self.view.frame.size.height - keyboardHeight;
            NSLog(@"鍵盤彈出後的可視高度：%f",visibleHeight);
            //計算可視高度與特定元件的Y軸底緣之間的差值(正值表示元件被遮住了)
            CGFloat diffHeight = currentObjectBottomYPosition - visibleHeight;
            if (diffHeight > 0)     //如果有遮住才移動
            {
                //整個View往上移動其差值
                [UIView animateWithDuration:0.25 animations:^{
                    self.view.frame = CGRectMake(0, -(diffHeight+20), self.view.frame.size.width, self.view.frame.size.height);
                }];
            }
        }
    }
}

//監聽鍵盤所呼叫的事件-鍵盤收合
-(void)keyboadrdWillHide:(NSNotification*)sender
{
    NSLog(@"鍵盤收合");
    //把View移回原來的位置
    [UIView animateWithDuration:0.25 animations:^{
        self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    }];
}

//一旦開始編輯，就取得該元件的Y軸底部位置
- (IBAction)FieldTouched:(UITextField*)sender
{
    //計算目前元件的Y軸底端位置
    currentObjectBottomYPosition = sender.frame.origin.y + sender.frame.size.height;
    NSLog(@"Y軸底端位置：%f",currentObjectBottomYPosition);
}

#pragma mark - UIPickerViewDelegate
//<方法二>回傳『每一列』中用來顯示的文字（使用自訂文字格式）
-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    //初始化一個UILabel
    UILabel *myView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, pickerView.frame.size.width, pickerView.frame.size.height)];
    //準備顯在myView的文字
    if (pickerView.tag == 0)
    {
        myView.text = arrGender[row];
    }
    else
    {
        myView.text = arrClass[row];
    }
    //調整myView文字屬性
    myView.textAlignment = NSTextAlignmentLeft;
    myView.font = [UIFont systemFontOfSize:16];
    return myView;
}

#pragma mark - UIPickerViewDataSource
//一個PickerView有幾個滾輪
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    //只要一個滾輪
    return 1;
}
//每個滾輪有幾筆資料
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    //<方法一>利用tag判斷不同的pickerView
    if (pickerView.tag == 0)
    {
        return arrGender.count;
    }
    else
    {
        return arrClass.count;
    }
    //<方法二>利用property判斷不同的pickerView
    //    if (pkvGender == pickerView)
    //    {
    //        return arrGender.count;
    //    }
    //    else
    //    {
    //        return arrClass.count;
    //    }
}

#pragma mark - UIImagePickerControllerDelegate
//從相機或相簿挑選好照片或影片之後
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    //將挑選好的照片顯示出來
    if ([picker.title isEqualToString:@"camera"])
    {//如果是相機過來呼叫
        //使用編輯過後的圖
        imgPicture.image = info[UIImagePickerControllerEditedImage];
    }
    else
    {//如果是相簿過來呼叫
        //使用原圖
        imgPicture.image = info[UIImagePickerControllerOriginalImage];
    }
    //退掉挑選照片的畫面
    [picker dismissViewControllerAnimated:YES completion:^{
        //清空挑選圖片的物件
        imgPicker = nil;
    }];
}

@end
