#import <Foundation/Foundation.h>
//===================13.6靜態變數(static)====================

@interface Num : NSObject

-(void)show;

@end

@implementation Num

-(void)show
{
    int x = 10;
    static int sx = 10; //靜態變數(此行只有第一次執行時會被呼叫)
    x++;
    sx++;
    NSLog(@"x=%i,sx=%i",x,sx);
}

@end

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        Num *objNum = [Num new];
        for (int i=0; i<5; i++)
        {
            [objNum show];
        }
    }
    return 0;
}
