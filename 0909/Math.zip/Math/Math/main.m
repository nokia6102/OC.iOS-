#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        double x=-2.5,y=5.3;
        
        NSLog(@"%.2f的%.2f次方：%.2f",x,y,pow(x,y));
        NSLog(@"%.2f的平方根：%.2f",x,sqrt(x));
        NSLog(@"%.2f無條件去除小數位數：%.2f",x,floor(x));
        NSLog(@"%.2f無條件進位小數位數：%.2f",y,ceil(y));
        NSLog(@"整數的絕對值：%i",abs((int)x));
        NSLog(@"浮點數的絕對值：%f",fabs(x));
        
    }
    return 0;
}
