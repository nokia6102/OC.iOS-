#import <Foundation/Foundation.h>

//=============定義全域型結構(10.4)=============
struct student
{
    char name[20];
    int score;
};

//判斷學生成績是否合格
void passOrDown(struct student *p);
//統一調整學生成績
void adjust(struct student *p,int arraySize);

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
//        //=============定義區域型結構(10.1)=============
//        struct student
//        {
//            char name[20];
//            int score;
//        };

//        struct student stu = {"Mary",90};
//        
//        NSLog(@"學生姓名：%s,成績：%i",stu.name,stu.score);
        
//        //==============指向結構的指標(10.2)==============
//        struct student *pstu;
//        pstu = &stu;
//        NSLog(@"請輸入姓名：");
//        scanf("%s",stu.name);
//        NSLog(@"請輸入成績：");
//        scanf("%i",&stu.score);
//        
//        NSLog(@"<一般變數>學生姓名：%s,成績：%i",stu.name,stu.score);
////        NSLog(@"<一般變數>學生姓名：%@,成績：%i",[NSString stringWithUTF8String:stu.name],stu.score);
//        
//        NSLog(@"<指標變數>學生姓名：%s,成績：%i",(*pstu).name,(*pstu).score);
////        NSLog(@"<指標變數>學生姓名：%@,成績：%i",[NSString stringWithUTF8String:(*pstu).name],(*pstu).score);
//        
//        NSLog(@"<指標變數>學生姓名：%s,成績：%i",pstu->name,pstu->score);
////        NSLog(@"<指標變數>學生姓名：%@,成績：%i",[NSString stringWithUTF8String:pstu->name],pstu->score);
//        NSLog(@"**************************************************");
        //==============動態配置記憶體空間給『結構指標』(10.3第一例)==============
        struct student *pstu1;
        pstu1 = malloc(sizeof(struct student));
        NSLog(@"請輸入姓名：");
        scanf("%s",(*pstu1).name);
        NSLog(@"請輸入成績：");
        scanf("%i",&(*pstu1).score);
        NSLog(@"<指標變數>學生姓名：%s,成績：%i",(*pstu1).name,(*pstu1).score);
        
        NSLog(@"**************************************************");
        //==============『結構陣列』陣列元素存放結構(10.3第二例)==============
        struct student arrStu[] = {{"John",90},{"Mary",92},{"Peter",88}};
        NSLog(@"共有下列同學：");
        for (int i=0; i<sizeof(arrStu)/sizeof(arrStu[0]); i++)
        {
            NSLog(@"第%i位同學：",i+1);
            NSLog(@"%s",arrStu[i].name);
            NSLog(@"%i",arrStu[i].score);
        }
        
        NSLog(@"**************************************************");
        //==============結構與函式(10.4)==============
        //判斷學生成績是否合格
        passOrDown(pstu1);
        
        NSLog(@"經過調整後的成績：");
        //統一調整學生成績
        adjust(arrStu,sizeof(arrStu)/sizeof(arrStu[0]));
        //印出調整後的成績
        for (int i=0; i<sizeof(arrStu)/sizeof(arrStu[0]); i++)
        {
            NSLog(@"第%i位同學：",i+1);
            NSLog(@"%s",arrStu[i].name);
            NSLog(@"%i",arrStu[i].score);
        }
    }
    return 0;
}

//判斷學生成績是否合格
void passOrDown(struct student *p)
{
    if ((*p).score >= 60)
    {
        NSLog(@"%s成績：%i,合格!",(*p).name,(*p).score);
    }
    else
    {
        NSLog(@"%s成績：%i,當掉!",(*p).name,(*p).score);
    }
}

//統一調整學生成績
void adjust(struct student *p,int arraySize)
{
    for (int k=0; k<arraySize; k++)
    {
        //<方法一>以陣列方式操作
//        p[k].score = sqrt(p[k].score) * 10;
        
        //<方法二>以指標方式操作
        (*p).score = sqrt((*p).score) * 10;
        p++;        //指標指到下一個陣列元素
    }
}
