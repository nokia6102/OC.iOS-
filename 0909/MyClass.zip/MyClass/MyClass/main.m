#import <Foundation/Foundation.h>
//====================類別宣告====================
@interface MyClass : NSObject
{
    //類別內部屬性
    int num1,num2;
}
//設定類別內部屬性
-(void)setDataFor_num1:(int)a and_num2:(int)b;
//列印方法
-(void)output;
//計算總和
-(int)sum;
//物件初始化方法<補充>
-(MyClass *)init;
//setter for num1
-(void)setNum1:(int)n;
//setter for num2
-(void)setNum2:(int)m;
//getter for num1
-(int)num1;
//getter for num2
-(int)num2;
@end
//====================類別實作====================
@implementation MyClass
//設定類別內部屬性
-(void)setDataFor_num1:(int)a and_num2:(int)b
{
    num1 = a;
    num2 = b;
}
//列印方法
-(void)output
{
    NSLog(@"num1=%i,num2=%i",num1,num2);
}
//計算總和
-(int)sum
{
    return num1+num2;
}
//物件初始化方法(Override覆寫)
-(MyClass *)init
{
    self = [super init];
    if (self)
    {
        num1 = 10;
        num2 = 11;
    }
    return self;
}
//setter for num1
-(void)setNum1:(int)n
{
    num1 = n;
}
//setter for num2
-(void)setNum2:(int)m
{
    num2 = m;
}
//getter for num1
-(int)num1
{
    return num1;
}
//getter for num2
-(int)num2
{
    return num2;
}
@end

//====================Main====================
int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        MyClass *obj = [[MyClass alloc] init];
//        MyClass *obj = [MyClass new];
        
//        [obj setDataFor_num1:100 and_num2:200];
        //呼叫setter設定個別的屬性值
        [obj setNum1:100];
        [obj setNum2:200];
        //呼叫getter取得內部屬性值
        NSLog(@"num1=%i",[obj num1]);
        NSLog(@"num2=%i",[obj num2]);
        NSLog(@"**********%i",obj.num1);
        //列印輸入結果
        [obj output];
        //計算總和
        NSLog(@"總和：%i",[obj sum]);
    }
    return 0;
}


