#import <Foundation/Foundation.h>
//11.1(第一例)
#define RATE 33.92
//11.1(第三例)
#define SQUARE(x) x*x

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //============11.1(第一例)============
        double us,nt;
        NSLog(@"請輸入有多少美金：");
        scanf("%lf",&us);
        
        nt = us * RATE;
        
        NSLog(@"您有%.0f台幣",nt);
     
        //============11.1(第三例)============
        int s;
        s = SQUARE(9);
        NSLog(@"s=%i",s);
        
        //============11.6 typedef(第一例)============
        typedef int INTEGER;
        typedef int *POINTER;
        
        INTEGER x = 100, y = 200;
        POINTER ptr = &x;
        
        NSLog(@"%i+%i=%i",x,y,x+y);
        NSLog(@"*ptr=%i",*ptr);
        
        //============11.6 typedef(第二例)============
        //<方式一>分兩行
        struct student
        {
            char name[20];
            int score;
        };
        typedef struct student NODE;
        
        //<方式二>同一行
//        typedef struct student
//        {
//            char name[20];
//            int score;
//        } NODE;
        
        NODE stu[3] = {{"John",90},{"Mary",92},{"Peter",88}};
        NSLog(@"共有下列同學：");
        for (int i=0; i<sizeof(stu)/sizeof(stu[0]); i++)
        {
            NSLog(@"第%i位同學：",i+1);
            NSLog(@"%s",stu[i].name);
            NSLog(@"%i",stu[i].score);
        }
        //點座標結構的使用
        CGPoint currentLocation;
        currentLocation = CGPointMake(100, 200);
        NSLog(@"(x,y):(%.0f,%.0f)",currentLocation.x,currentLocation.y);
    }
    return 0;
}
