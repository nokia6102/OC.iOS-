#import <Foundation/Foundation.h>
//13.3範例
//================類別宣告================
@interface Coordinate : NSObject
{
    //類別內部屬性，紀錄x,y座標
    int x;
    int y;
}
@property int x;
@property int y;
////setter for x
//-(void)setX:(int)a;
////setter for y
//-(void)setY:(int)b;
////getter for x
//-(int)x;
////getter for y
//-(int)y;

//類別的初始化方法
-(Coordinate *)init;
//列印方法
-(void)print;
@end
//================類別實作================
@implementation Coordinate
@synthesize x,y;
////setter for x
//-(void)setX:(int)a
//{
//    x = a;
//}
////setter for y
//-(void)setY:(int)b
//{
//    y = b;
////    [self print];
//}
////getter for x
//-(int)x
//{
//    return x;
//}
////getter for y
//-(int)y
//{
//    return y;
//}
//類別的初始化方法
-(Coordinate *)init
{
    self = [super init];
    if (self)
    {
        //初始化在原點座標
        x = 1;
        y = 1;
    }
    return self;
}
//列印方法
-(void)print
{
    NSLog(@"座標：(%i,%i)",x,y);
}
@end

//================Main================
int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        Coordinate *obj = [Coordinate new];
        //利用getter列印
        NSLog(@"(%i,%i)",[obj x],[obj y]);
        //利用類別的列印方法
        [obj print];
        
        Coordinate *obj1 = [Coordinate new];
        Coordinate *obj2 = [Coordinate new];
        [obj1 setX:150];
        [obj1 setY:250];
        //『點語法』在設定完setter和getter之後就生效
        NSLog(@"********%i",obj1.x);
        obj1.x = 999;
        //列印
        [obj1 print];
        
        
        [obj2 setX:100];
        [obj2 setY:200];
        [obj2 print];
    }
    return 0;
}
