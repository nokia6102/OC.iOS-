#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //============抽取亂數<方法一>C語言============
        //給亂數的種子
        srand((unsigned)time(NULL));
        for (int i=1; i<=10; i++)
        {
            //取1~100之間的亂數
            NSLog(@"%i",rand()%100+1);
        }
        NSLog(@"******************************************");
        //============抽取亂數<方法二>不需給亂數種子的亂數函式============
        for (int i=1; i<=10; i++)
        {
            //取1~100之間的亂數
            NSLog(@"%i",arc4random()%100+1);
        }
    }
    return 0;
}
