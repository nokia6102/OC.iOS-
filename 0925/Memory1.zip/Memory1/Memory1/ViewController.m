#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    //宣告即將加入的色塊
    UIView *tempView;
    //加入一塊特定大小且帶顏色的tempView在self.view之上
    tempView = [[UIView alloc] initWithFrame:CGRectMake(30, 30, 300, 300)];
    tempView.backgroundColor = [UIColor greenColor];
    //抄錄tempView色塊的指標到view1
    __weak UIView *view1;
    view1 = tempView;
    //將色塊加入到畫面上
    [self.view addSubview:view1];
    NSLog(@"色塊加入！");
    if (view1)
    {
        NSLog(@"view1色塊還存在記憶體！");
    }
    else
    {
        NSLog(@"view1色塊不存在記憶體！");
    }
    
    //色塊移除！
    [tempView removeFromSuperview];
    tempView = nil;
    NSLog(@"色塊移除！");
    
    if (tempView)
    {
        NSLog(@"tempView色塊還存在記憶體！");
    }
    else
    {
        NSLog(@"tempView色塊不存在記憶體！");
    }
    //view1若不是宣告成＿＿weak，此處必須自己釋放
//    view1 = nil;
    if (view1)
    {
        NSLog(@"view1色塊還存在記憶體！");
    }
    else
    {
        NSLog(@"view1色塊不存在記憶體！");
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
