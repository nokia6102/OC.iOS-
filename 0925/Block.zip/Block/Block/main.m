#import <Foundation/Foundation.h>
//=============================================
//NSArray擴充功能宣告區
@interface NSArray (MyBlock)
//宣告類別的實體方法，傳入參數為一個Block
-(void)listMembers:(void(^)(id obj, NSUInteger idx))myBlock;

@end
//---------------------------------------------
//NSArray擴充功能實作區
@implementation NSArray (MyBlock)
//實作類別的實體方法，傳入參數為一個Block
-(void)listMembers:(void(^)(id obj, NSUInteger idx))myBlock
{
    for (int i=0; i < self.count; i++)
    {
        //執行Block
        myBlock(self[i],i);
    }
//    myBlock(@"test1",88);
}

@end
//=============================================

//宣告Block
int (^TwoInteger)(int,int);
//int (^TwoInteger)(int a,int b);

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        NSArray *array = [NSArray arrayWithObjects:@"第一個",@"第二個",@"第三個", nil];
//        NSArray *array1 = @[@"第一個",@"第二個"];
        [array enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            if (idx == 1)
            {
                *stop = YES;
            }
            NSLog(@"%@的索引值：%lu",obj,idx);
        }];
        
        //定義Block
        TwoInteger = ^int(int x,int y){
            NSLog(@"Block內：x=%i,y=%i",x,y);
            return x + y;
        };
        
        //執行Block
        int z;
        z = TwoInteger(3,4);
        NSLog(@"Block外：x+y=%i",z);
        
        NSLog(@"********呼叫自訂的類別實體方法********");
        //執行自訂的類別實體方法
        [array listMembers:^(id obj, NSUInteger idx) {
            NSLog(@"%@的索引值：%lu",obj,idx);
        }];
        
    }
    return 0;
}
