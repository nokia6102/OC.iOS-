#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        //19.4.1不可變更的詞典物件
        NSLog(@"*************建立詞典物件<方法一>*************");
        //----建立詞典物件<方法一>----
        NSArray *key = [NSArray arrayWithObjects:@"小叮噹",@"大雄",@"小夫",@"胖虎", nil];
//        key = @[@"小叮噹1",@"大雄1",@"小夫1",@"胖虎1"];
//        NSLog(@"%@",key[0]);
        NSArray *object = @[@"有百寶袋的機器貓",@"心地善良的小孩",@"常有新奇玩具的小朋友",@"常被媽媽打的孩子王"];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjects:object forKeys:key];
        NSLog(@"目前元素數量：%lu",dic.count);
        NSLog(@"大雄是：%@",dic[@"大雄"]);
        
        NSLog(@"*************建立詞典物件<方法二>*************");
        //----建立詞典物件<方法二>value-key----
        NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:@"有百寶袋的機器貓",@"小叮噹",@"心地善良的小孩",@"大雄",@"常有新奇玩具的小朋友",@"小夫",@"常被媽媽打的孩子王",@"胖虎", nil];
        NSLog(@"目前元素數量：%lu",dic1.count);
        NSLog(@"小夫是：%@",dic1[@"小夫"]);
        
        NSLog(@"*************建立詞典物件<方法三>*************");
        //----建立詞典物件<方法三>key:value----
        NSDictionary *dic2 = @{@"小叮噹":@"有百寶袋的機器貓",@"大雄":@"心地善良的小孩",@"小夫":@"常有新奇玩具的小朋友",@"胖虎":@"常被媽媽打的孩子王"};
        NSLog(@"目前元素數量：%lu",dic2.count);
        NSLog(@"小叮噹是：%@",dic2[@"小叮噹"]);
        
        NSLog(@"*************列出不可變更的詞典內容*************");
        for (NSString *tempKey in dic2.keyEnumerator)
        {
            NSLog(@"%@:%@",tempKey,dic2[tempKey]);
        }
        
        //19.4.2可變更的詞典物件
        NSLog(@"*************建立可變詞典物件<方法一>*************");
        //----建立不可變詞典物件<方法一>----
        NSMutableDictionary *mDic = [[NSMutableDictionary alloc] init];
        //逐筆加入詞典鍵值
        [mDic setObject:@9 forKey:@"Jerry"];
        [mDic setObject:@8 forKey:@"Mark"];
        [mDic setObject:@5 forKey:@"Tom"];
        [mDic setObject:@7 forKey:@"Peter"];
        
        NSLog(@"*************列出可變詞典內容*************");
        for (NSString *tempKey in mDic.keyEnumerator)
        {
            NSLog(@"%@:%@",tempKey,mDic[tempKey]);
        }
        
        NSLog(@"*************建立可變詞典物件<方法二>*************");
        //----建立不可變詞典物件<方法二>value-key----
        NSMutableDictionary *mDic1 = [NSMutableDictionary dictionaryWithObjectsAndKeys:@9,@"Jerry",@8,@"Mark",@5,@"Tom",@7,@"Peter", nil];
        NSLog(@"*************列出可變詞典內容*************");
        for (NSString *tempKey in mDic1.keyEnumerator)
        {
            NSLog(@"%@:%@",tempKey,mDic1[tempKey]);
        }
        
        NSLog(@"*************建立可變詞典物件<方法三>*************");
        //----建立不可變詞典物件<方法三>key-value----
        NSMutableDictionary *mDic2 = [NSMutableDictionary dictionaryWithDictionary:@{@"Jerry":@9,@"Mark":@8,@"Tom":@5,@"Peter":@7}];
        NSLog(@"*************列出可變詞典內容*************");
        for (NSString *tempKey in mDic2.keyEnumerator)
        {
            NSLog(@"%@:%@",tempKey,mDic2[tempKey]);
        }
        
        //額外加一筆
        [mDic2 setObject:@999 forKey:@"test"];
        NSLog(@"*************加入可變詞典內容*************");
        for (NSString *tempKey in mDic2.keyEnumerator)
        {
            NSLog(@"%@:%@",tempKey,mDic2[tempKey]);
        }
        //刪除一筆
        [mDic2 removeObjectForKey:@"Mark"];
        NSLog(@"*************刪除可變詞典內容*************");
        for (NSString *tempKey in mDic2.keyEnumerator)
        {
            NSLog(@"%@:%@",tempKey,mDic2[tempKey]);
        }
    }
    return 0;
}
