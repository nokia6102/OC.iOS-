#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak,nonatomic) UIView *view1;
@property int x;

@end

