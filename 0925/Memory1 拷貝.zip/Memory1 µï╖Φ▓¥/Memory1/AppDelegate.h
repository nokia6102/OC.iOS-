//
//  AppDelegate.h
//  Memory1
//
//  Created by perkin on 2015/9/25.
//  Copyright (c) 2015年 perkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

