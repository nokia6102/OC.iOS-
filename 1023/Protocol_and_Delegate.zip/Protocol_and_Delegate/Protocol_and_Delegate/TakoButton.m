#import "TakoButton.h"

@implementation TakoButton
@synthesize delegate,datasource;
//當點按此類別實體時啟動此事件
-(void)tapGestureEvent
{
    NSLog(@"按鈕被按了");
    //由代理人去啟動代理方法
    [delegate didTapButton:self];
    //由資料來源去啟動代理方法
    NSString *buttonText =  [datasource labelTextOnTakoButton];
    NSLog(@"拿到字串：%@",buttonText);
    //=============把文字顯示到按鈕上=============
    //初始化一個跟自己類別大小一樣的UILabel
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    label.text = buttonText;
    [label setTextAlignment:NSTextAlignmentCenter];
    //把文字加到類別實體上
    [self addSubview:label];
}

//類別實體的初始化函式
-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.frame = frame;
        //加上點按手勢去啟動tapGestureEvent
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureEvent)];
        //把手勢加到類別實體上
        [self addGestureRecognizer:tapGesture];
    }
    return self;
}

@end
