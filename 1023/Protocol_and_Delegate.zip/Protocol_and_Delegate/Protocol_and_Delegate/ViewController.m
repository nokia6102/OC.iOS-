#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    //以特定大小初始化
    TakoButton *button = [[TakoButton alloc] initWithFrame:CGRectMake(100, 100, 200, 200)];
    //著色
    button.backgroundColor = [UIColor yellowColor];
    //將button加到畫面上
    [self.view addSubview:button];
    //指派代理人
    button.delegate = self;
    button.datasource = self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

#pragma mark - Delegate & DataSource

-(void)didTapButton:(TakoButton *)takoButton
{
    NSLog(@"代理人啟動了代理方法！");
}

-(NSString *)labelTextOnTakoButton
{
    return @"我是按鈕";
}

@end
