#import <UIKit/UIKit.h>
#import "TakoButton.h"
@interface ViewController : UIViewController<takoButtonDataSource,takoButtonDelegate>


@end

