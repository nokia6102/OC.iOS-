#import "ViewController.h"

@interface ViewController ()
{
    //宣告定位管理員
    CLLocationManager *locationManager;
    //宣告地理資訊編碼器（用於地址與經緯度的轉換）
    CLGeocoder *geocoder;
    //記錄目前所在位置
    CLLocation *myLocation;
}
//定位用
@property (weak, nonatomic) IBOutlet UILabel *lblLatitude;
@property (weak, nonatomic) IBOutlet UILabel *lblLongitude;
@property (weak, nonatomic) IBOutlet UILabel *lblAltitude;
@property (weak, nonatomic) IBOutlet UILabel *lblDirection;
@property (weak, nonatomic) IBOutlet UILabel *lblCity;
@property (weak, nonatomic) IBOutlet UILabel *lblTown;
@property (weak, nonatomic) IBOutlet MKMapView *myMap;
//導航用
@property (weak, nonatomic) IBOutlet UITextField *txtLatitude;
@property (weak, nonatomic) IBOutlet UITextField *txtLongitude;
@property (weak, nonatomic) IBOutlet UITextField *txtAddress;

@end

@implementation ViewController
@synthesize lblLatitude,lblLongitude,lblAltitude,lblDirection,lblCity,lblTown,myMap,txtLatitude,txtLongitude,txtAddress;
#pragma mark - View Lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    //初始化定位管理員
    locationManager = [CLLocationManager new];
    //指派定位管理員的代理人
    locationManager.delegate = self;
    //詢問使用者是否要給App定位的權限
    [locationManager requestAlwaysAuthorization];
    //初始化地理資訊編碼器（用於地址與經緯度的轉換）
    geocoder = [CLGeocoder new];
}
//view即將顯示
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //開始定位
    [locationManager startUpdatingLocation];
    //開始偵測方向
    [locationManager startUpdatingHeading];
}
//view即將隱藏
-(void)viewDidDisappear:(BOOL)animated
{
    //停止定位
    [locationManager stopUpdatingLocation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -Target Action
//經緯度導航
- (IBAction)btnNaviToCoord:(UIButton *)sender
{
    if ([txtLatitude.text isEqualToString:@""] || [txtLongitude.text isEqualToString:@""])
    {
        return;
    }
    //導航起點位置：取得現在所在位置
    MKMapItem *currentMapItem = [MKMapItem mapItemForCurrentLocation];
    //導航終點位置：
    //從介面上取得要導航的經緯度
    NSString *strLatitude = txtLatitude.text;
    NSString *strLongitude = txtLongitude.text;
    //取得導航終點位置，並且標示為一個大頭針
    MKPlacemark *markDestination = [[MKPlacemark alloc] initWithCoordinate:CLLocationCoordinate2DMake(strLatitude.doubleValue, strLongitude.doubleValue) addressDictionary:nil];
    //製作導航終點位置
    MKMapItem *destMapItem = [[MKMapItem alloc] initWithPlacemark:markDestination];
    destMapItem.name = @"導航終點";
    destMapItem.phoneNumber = @"1234567";
    //設定導航的起點與終點
    NSArray *array = @[currentMapItem,destMapItem];
    //設定導航模式為開車模式
    NSDictionary *option = @{MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving};
    //開啟內建的導航地圖(以類別方法呼叫)
    [MKMapItem openMapsWithItems:array launchOptions:option];
}
//地址導航
- (IBAction)btnNaviToAddress:(UIButton *)sender
{
    if ([txtAddress.text isEqualToString:@""])
    {
        return;
    }
    //取得目的地住址
    NSString *strAddress = txtAddress.text;
    //將目的地住址轉為經緯度
    [geocoder geocodeAddressString:strAddress completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (error)
        {
            //準備訊息視窗
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"地址轉換錯誤" message:@"無法成功將地址轉成經緯度！" preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
            //顯示訊息視窗
            [self presentViewController:alert animated:YES completion:nil];
            return;
        }
        //取出住址的經緯度(取第一筆經緯度)
        CLPlacemark *toPlaceMark = placemarks[0];
        //將經緯度物件轉成導航地圖上的目的地大頭針
        MKPlacemark *toPin = [[MKPlacemark alloc] initWithPlacemark:toPlaceMark];
        
        //產生地圖上的大頭針
        MKMapItem *destMapItem = [[MKMapItem alloc] initWithPlacemark:toPin];

        //設定導航模式為走路模式
        NSDictionary *option = @{MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeWalking};
        
        //從現在位置導航到目的地（以物件方法呼叫）
        [destMapItem openInMapsWithLaunchOptions:option];
    }];
}

#pragma mark -CLLocationManagerDelegate
//由定位管理員所呼叫的更新位置事件
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    NSLog(@"定位中");
    //取得記錄定位資訊的陣列中第一筆的位置資訊
    myLocation = locations[0];
//    NSLog(@"(緯度,經度)=(%f,%f)",myLocation.coordinate.latitude,myLocation.coordinate.longitude);
    //顯示經緯度
    lblLatitude.text = [NSString stringWithFormat:@"%f",myLocation.coordinate.latitude];
    lblLongitude.text = [NSString stringWithFormat:@"%f",myLocation.coordinate.longitude];
    lblAltitude.text = [NSString stringWithFormat:@"%f",myLocation.altitude];
    //=================顯示縣市鄉鎮=================
    //利用地理編碼器反查出地址，以取得所在縣市鄉鎮（從Block參數中的placemarks裡面取得）
    [geocoder reverseGeocodeLocation:myLocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (error)
        {
            lblCity.text = @"未知";
            lblTown.text = @"未知";
            return;
        }
        //取得所在行政區的第一筆資料
        CLPlacemark *currentPlacemark = placemarks[0];
        NSDictionary *dicAddress = currentPlacemark.addressDictionary;
        NSLog(@"目前位置的詞典：%@",dicAddress);
        NSLog(@"目前位置：%@/%@/%@",dicAddress[@"Country"],dicAddress[@"SubAdministrativeArea"],dicAddress[@"City"]);
        //顯示縣市鄉鎮
        lblCity.text = dicAddress[@"SubAdministrativeArea"];
        lblTown.text = dicAddress[@"City"];
    }];
    
    //============以下書上沒有============
    //允許顯示目前位置
    myMap.showsUserLocation = YES;
    //制定地圖的顯示範圍（以目前位置往上下左右延伸）
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(myMap.userLocation.coordinate, 500, 500);
    //調整地圖範圍的物件
    MKCoordinateRegion adjustRegion = [myMap regionThatFits:viewRegion];
    //實際調整地圖的顯示範圍
    [myMap setRegion:adjustRegion animated:YES];
    //設定地圖的中心點
    myMap.centerCoordinate = myMap.userLocation.coordinate;
    //==================================
}
//由定位管理員所呼叫的更新方向事件
-(void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading
{
    if (newHeading.magneticHeading < 0)
    {
        lblDirection.text = @"未知";
    }
    else if (newHeading.magneticHeading >=0 && newHeading.magneticHeading < 46)
    {
        lblDirection.text = @"東北";
    }
    else if (newHeading.magneticHeading >=46 && newHeading.magneticHeading < 90)
    {
        lblDirection.text = @"東";
    }
    else if (newHeading.magneticHeading >=90 && newHeading.magneticHeading < 136)
    {
        lblDirection.text = @"東南";
    }
    else if (newHeading.magneticHeading >=136 && newHeading.magneticHeading < 181)
    {
        lblDirection.text = @"南";
    }
    else if (newHeading.magneticHeading >=181 && newHeading.magneticHeading < 226)
    {
        lblDirection.text = @"西南";
    }
    else if (newHeading.magneticHeading >=226 && newHeading.magneticHeading < 271)
    {
        lblDirection.text = @"西";
    }
    else if (newHeading.magneticHeading >=271 && newHeading.magneticHeading < 316)
    {
        lblDirection.text = @"西北";
    }
    else
    {
        lblDirection.text = @"北";
    }
}





@end
