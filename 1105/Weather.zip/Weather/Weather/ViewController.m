#import "ViewController.h"

@interface ViewController ()
{
    //宣告定位管理員
    CLLocationManager *locationManager;
    //宣告地理資訊編碼器
    CLGeocoder *geocoder;
    //目前的開始標籤
    NSString *tagName;
    //目前的標籤內容（要當詞典key的部份）
    NSString *strKey;
}

@property (weak, nonatomic) IBOutlet UILabel *lblCity;
@property (weak, nonatomic) IBOutlet UILabel *lblTown;
@property (weak, nonatomic) IBOutlet UILabel *lblTemp;

@end

@implementation ViewController
@synthesize lblCity,lblTown,lblTemp;

- (void)viewDidLoad
{
    [super viewDidLoad];
    //初始化定位管理員，並且指定代理人
    locationManager = [CLLocationManager new];
    locationManager.delegate = self;
    //詢問使用者是否要給App定位權限
    [locationManager requestWhenInUseAuthorization];
    //初始化地理資訊編碼器
    geocoder = [CLGeocoder new];
    //中央氣象局的URL
    NSString *strURL = @"http://opendata.cwb.gov.tw/opendataapi?dataid=O-A0001-001&authorizationkey=CWB-72F89C13-3FBB-44A0-A9A5-A6E8B78950E1";
    //將網址製成NSURL物件
    NSURL *url = [NSURL URLWithString:strURL];
    //初始化網路存取物件
    NSURLSession *session = [NSURLSession sharedSession];
    //製作用來執行網路資料傳輸任務的物件
    NSURLSessionDataTask *dataTask =
    [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable xmlData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
//        NSLog(@"%@",xmlData);
        //初始化xml解析器
        NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithData:xmlData];
        //指派xml解析器的代理人
        xmlParser.delegate = self;
        //啟動xml解析
        [xmlParser parse];
    }];
    //執行網路資料傳輸任務
    [dataTask resume];
}
//view即將出現
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //開始定位
    [locationManager startUpdatingLocation];
}
//view即將消失
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    //停止定位
    [locationManager stopUpdatingLocation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - CLLocationManagerDelegate
//定位管理員開始更新定位資訊
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
//    NSLog(@"定位中");
    //取得記錄定位資訊的陣列中第一筆的位置資訊
    CLLocation *myLocation = locations[0];
    //利用地理編碼器反查出地址，以取得所在縣市鄉鎮（從Block參數中的placemarks裡面取得）
    [geocoder reverseGeocodeLocation:myLocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (error)
        {
            lblCity.text = @"未知";
            lblTown.text = @"未知";
            return;
        }
        //取得所在行政區的第一筆資料
        CLPlacemark *currentPlacemark = placemarks[0];
        NSDictionary *dicAddress = currentPlacemark.addressDictionary;
        //調整五都合併資料
        NSString *strCity = dicAddress[@"SubAdministrativeArea"];
        if ([strCity isEqualToString:@"台北縣"])
        {
            strCity = @"新北市";
        }
        else if ([strCity isEqualToString:@"桃園縣"])
        {
            strCity = @"桃園市";
        }
        else if ([strCity isEqualToString:@"台中縣"])
        {
            strCity = @"台中市";
        }
        else if ([strCity isEqualToString:@"台南縣"])
        {
            strCity = @"台南市";
        }
        else if ([strCity isEqualToString:@"高雄縣"])
        {
            strCity = @"高雄市";
        }
        //顯示縣市鄉鎮
        lblCity.text = strCity;
        lblTown.text = dicAddress[@"City"];
    }];
}

#pragma mark - NSXMLParserDelegate
//讀到開始標籤
-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict
{
    //抓取可能需要的開始標籤
    if ([elementName isEqualToString:@"elementName"] || [elementName isEqualToString:@"value"] || [elementName isEqualToString:@"parameterName"] || [elementName isEqualToString:@"parameterValue"])
    {
        NSLog(@"開始標籤：%@",elementName);
        tagName = elementName;
    }
}
//讀到標籤內容
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if ([string isEqualToString:@"TEMP"] || [string isEqualToString:@"CITY"] || [string isEqualToString:@"TOWN"])
    {
        NSLog(@"標籤內容：%@",string);
        strKey = string;
    }
}
//讀到結束標籤
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
//    NSLog(@"結束標籤：%@",elementName);
}
//讀完整份xml文件
-(void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"讀完了！");
}

@end
