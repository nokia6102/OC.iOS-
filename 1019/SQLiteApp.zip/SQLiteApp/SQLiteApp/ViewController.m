#import "ViewController.h"
#import "AppDelegate.h"
#import <sqlite3.h>
@interface ViewController ()
{
    //資料庫的指標
    sqlite3 *db;
    //利用詞典來記錄資料表中的單一資料行（不含圖片） {NSString:NSString}
    NSMutableDictionary *dicRow;
    //利用陣列來記錄一個完整的資料表（不含圖片）
    NSMutableArray *arrTable;
    //記錄圖片的陣列
    NSMutableArray *arrPicture;
    //存放PickerView的資料來源陣列
    NSArray *arrGender;
    NSArray *arrClass;
    //記錄目前資料列
    int currentRow;
}

@property (weak, nonatomic) IBOutlet UITextField *txtNo;
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UIImageView *imgPicture;
@property (weak, nonatomic) IBOutlet UITextField *txtPhone;
@property (weak, nonatomic) IBOutlet UITextField *txtAddress;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UIPickerView *pkvGender;
@property (weak, nonatomic) IBOutlet UIPickerView *pkvClass;

@end

@implementation ViewController
@synthesize txtNo,txtName,imgPicture,txtPhone,txtAddress,txtEmail,pkvClass,pkvGender;
#pragma mark - View Lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    //從AppDelegate取得資料庫連線，並儲存於db變數中
    AppDelegate *delegate = [UIApplication sharedApplication].delegate;
    db = [delegate getDB];
    //初始化PickerView的資料來源陣列
    arrGender = @[@"女",@"男"];
    arrClass = @[@"手機程式開發",@"網頁程式設計"];
    //指派代理人
    pkvGender.delegate = self;
    pkvGender.dataSource = self;
    pkvClass.delegate = self;
    pkvClass.dataSource = self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Target Action
//查詢按鈕
- (IBAction)btnQuery:(UIButton *)sender
{
    //目前資料表的指標在第0行
    currentRow = 0;
    //初始化陣列
    arrTable = [NSMutableArray new];
    arrPicture = [NSMutableArray new];
    //先確認資料連線成功
    if (db)
    {
        //準備查詢用的SQL
        const char *sql = "select * from student order by no";
        //宣告儲存查詢結果的變數(也就是資料集recordset)
        sqlite3_stmt *statement;
        //準備查詢(第三個參數若為正數，指的是sql可用的最大長度;若為負數，則不限sql的長度)
        sqlite3_prepare(db, sql, -1, &statement, nil);
        //利用迴圈取出查詢結果
        while (sqlite3_step(statement) == SQLITE_ROW)
        {
            //利用詞典來記錄資料表中的單一資料行（不含圖片）
            dicRow = [NSMutableDictionary new];
            //讀取第0欄
            char *cNo = (char *)sqlite3_column_text(statement, 0);  //注意轉型！
            //將第0欄從C語言的字串轉成NSString
            NSString *strNo = [NSString stringWithUTF8String:cNo];
            //將第0欄存入詞典
            dicRow[@"no"] = strNo;
            
            //讀取第1欄
            char *cName = (char *)sqlite3_column_text(statement, 1);  //注意轉型！
            //將第1欄從C語言的字串轉成NSString
            NSString *strName = [NSString stringWithUTF8String:cName];
            //將第1欄存入詞典
            dicRow[@"name"] = strName;
            
            //讀取第2欄
            int intGender = sqlite3_column_int(statement, 2);
            //將第2欄存入詞典
            dicRow[@"gender"] = [NSString stringWithFormat:@"%i",intGender];
            
            //讀取第4欄
            char *cPhone = (char *)sqlite3_column_text(statement, 4);  //注意轉型！
            //將第4欄從C語言的字串轉成NSString
            NSString *strPhone = [NSString stringWithUTF8String:cPhone];
            //將第4欄存入詞典
            dicRow[@"phone"] = strPhone;
            
            //讀取第5欄
            char *cAddress = (char *)sqlite3_column_text(statement, 5);  //注意轉型！
            //將第5欄從C語言的字串轉成NSString
            NSString *strAddress = [NSString stringWithUTF8String:cAddress];
            //將第5欄存入詞典
            dicRow[@"address"] = strAddress;
            
            //讀取第6欄
            char *cEmail = (char *)sqlite3_column_text(statement, 6);  //注意轉型！
            //將第6欄從C語言的字串轉成NSString
            NSString *strEmail = [NSString stringWithUTF8String:cEmail];
            //將第6欄存入詞典
            dicRow[@"email"] = strEmail;
            
            //讀取第7欄
            char *cClass = (char *)sqlite3_column_text(statement, 7);  //注意轉型！
            //將第7欄從C語言的字串轉成NSString
            NSString *strClass = [NSString stringWithUTF8String:cClass];
            //將第7欄存入詞典
            dicRow[@"class"] = strClass;
            
            //讀取第8欄
            char *cDate = (char *)sqlite3_column_text(statement, 8);  //注意轉型！
            //將第8欄從C語言的字串轉成NSString
            NSString *strDate = [NSString stringWithUTF8String:cDate];
            //將第8欄存入詞典
            dicRow[@"create_date"] = strDate;
            
            //將字典存入陣列
            [arrTable addObject:dicRow];
            
            //讀取第3欄
            int length = sqlite3_column_bytes(statement, 3);  //回傳值為檔案長度
            const void *totalBytes = sqlite3_column_blob(statement, 3);   //回傳值為檔案的Bytes
            NSData *imgData = [NSData dataWithBytes:totalBytes length:length];
            
            //將圖片存入陣列
            [arrPicture addObject:imgData];
            
        }
        NSLog(@"Table在陣列的內容%@",arrTable);
        NSLog(@"圖片在陣列的內容%@",arrPicture);
        //釋放資料庫查詢
        sqlite3_finalize(statement);
        //=================直接顯示第一筆資料=================
        txtNo.text = arrTable[0][@"no"];
        txtName.text = arrTable[0][@"name"];
        txtPhone.text = arrTable[0][@"phone"];
        txtAddress.text = arrTable[0][@"address"];
        txtEmail.text = arrTable[0][@"email"];
        imgPicture.image = [UIImage imageWithData:arrPicture[0]];
        //選定資料欄位中的對應性別
        [pkvGender selectRow:[arrTable[0][@"gender"] integerValue] inComponent:0 animated:YES];
        //取得班別資料
        NSString *myClass = arrTable[0][@"class"];
        //迴圈跑arrClass陣列的內容
        for (int i=0; i<arrClass.count; i++)
        {
            //進行陣列內容與班別資料欄位的比對
            if ([arrClass[i] isEqualToString:myClass])
            {
                //比對arrClass陣列當筆的內容，如果與當筆資料欄位相同，則選定該筆
                [pkvClass selectRow:i inComponent:0 animated:YES];
            }
        }
    }
}

//上一筆按鈕
- (IBAction)btnPrevious:(UIButton *)sender
{
    //若資料指標-1之後，沒有超過總資料筆數
    if (currentRow - 1 >= 0)
    {
        //資料指標-1
        currentRow--;
        //顯示當筆資料
        txtNo.text = arrTable[currentRow][@"no"];
        txtName.text = arrTable[currentRow][@"name"];
        txtPhone.text = arrTable[currentRow][@"phone"];
        txtAddress.text = arrTable[currentRow][@"address"];
        txtEmail.text = arrTable[currentRow][@"email"];
        imgPicture.image = [UIImage imageWithData:arrPicture[currentRow]];
        //選定資料欄位中的對應性別
        [pkvGender selectRow:[arrTable[currentRow][@"gender"] integerValue] inComponent:0 animated:YES];
        //取得班別資料
        NSString *myClass = arrTable[currentRow][@"class"];
        //迴圈跑arrClass陣列的內容
        for (int i=0; i<arrClass.count; i++)
        {
            //進行陣列內容與班別資料欄位的比對
            if ([arrClass[i] isEqualToString:myClass])
            {
                //比對arrClass陣列當筆的內容，如果與當筆資料欄位相同，則選定該筆
                [pkvClass selectRow:i inComponent:0 animated:YES];
            }
        }
    }
}

//下一筆按鈕
- (IBAction)btnNext:(UIButton *)sender
{
    //若資料指標＋1之後，沒有超過總資料筆數
    if (currentRow + 1 < arrTable.count)
    {
        //資料指標＋1
        currentRow++;
        //顯示當筆資料
        txtNo.text = arrTable[currentRow][@"no"];
        txtName.text = arrTable[currentRow][@"name"];
        txtPhone.text = arrTable[currentRow][@"phone"];
        txtAddress.text = arrTable[currentRow][@"address"];
        txtEmail.text = arrTable[currentRow][@"email"];
        imgPicture.image = [UIImage imageWithData:arrPicture[currentRow]];
        //選定資料欄位中的對應性別
        [pkvGender selectRow:[arrTable[currentRow][@"gender"] integerValue] inComponent:0 animated:YES];
        //取得班別資料
        NSString *myClass = arrTable[currentRow][@"class"];
        //迴圈跑arrClass陣列的內容
        for (int i=0; i<arrClass.count; i++)
        {
            //進行陣列內容與班別資料欄位的比對
            if ([arrClass[i] isEqualToString:myClass])
            {
                //比對arrClass陣列當筆的內容，如果與當筆資料欄位相同，則選定該筆
                [pkvClass selectRow:i inComponent:0 animated:YES];
            }
        }
    }
}

//更換照片按鈕
- (IBAction)btnChangePicture:(UIButton *)sender
{
    
}

//新增按鈕
- (IBAction)btnAdd:(UIButton *)sender
{

}

//修改按鈕
- (IBAction)btnUpdate:(UIButton *)sender
{

}

//刪除按鈕
- (IBAction)btnDelete:(UIButton *)sender
{
    
}

#pragma mark - UIPickerViewDelegate
//回傳『每一列』中用來顯示的文字
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView.tag == 0)
    {
        return arrGender[row];
    }
    else
    {
        return arrClass[row];
    }
}

#pragma mark - UIPickerViewDataSource
//一個PickerView有幾個滾輪
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    //只要一個滾輪
    return 1;
}
//每個滾輪有幾筆資料
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView.tag == 0)
    {
        return arrGender.count;
    }
    else
    {
        return arrClass.count;
    }
}

@end
