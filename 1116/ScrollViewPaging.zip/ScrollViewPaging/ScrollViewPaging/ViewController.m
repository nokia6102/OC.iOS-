#import "ViewController.h"

@interface ViewController ()
{
    //記錄scrollview的大小
    CGFloat scrollViewWidth;
    CGFloat scrollViewHeight;
    //宣告計時器
    NSTimer *timer;
    //由timer計算的頁數
    int pageCounter;
}
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;

@end

@implementation ViewController
@synthesize scrollView,pageControl;

- (void)viewDidLoad
{
    [super viewDidLoad];
    //初始化由timer計算的頁數
    pageCounter = 0;
    //==========設定UIPageControll元件==========
    pageControl.numberOfPages = 5;  //換頁的頁數
    pageControl.currentPage = 0;    //起始頁
    //===========設定UIScrollView元件===========
    scrollView.pagingEnabled = YES; //可以換頁
    //不要顯示捲軸
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    //不要往上捲動
    scrollView.scrollsToTop = NO;
    //指定scrollView的代理人
    scrollView.delegate = self;
    //取得scrollView的大小
    scrollViewWidth = scrollView.frame.size.width;
    scrollViewHeight = scrollView.frame.size.height;
    //指定可以捲動的區域大小
    scrollView.contentSize = CGSizeMake(scrollViewWidth * pageControl.numberOfPages, scrollViewHeight);
    //-------------製作scrollView的顯示內容-------------
    for (int i=0; i<pageControl.numberOfPages; i++)
    {
        //準備圖片
        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat:@"%i.gif",i+1]]];
        //錯開x軸的位置
        CGRect imgFrame = CGRectMake(scrollViewWidth*(CGFloat)i, 0, scrollViewWidth, scrollViewHeight);
        //設定imageView位置（即錯開的x軸位置）
        imageView.frame = imgFrame;
        //將錯開位置的圖片加入到scrollView
        [scrollView addSubview:imageView];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //初始化計時器
    timer = [NSTimer scheduledTimerWithTimeInterval:1.5 target:self selector:@selector(TurnPage) userInfo:nil repeats:YES];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    //停止timer
    [timer invalidate];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Target Action
//點擊換頁元件(由value chaged事件觸發)
- (IBAction)btnPageChange:(UIPageControl *)sender
{
    //計算imageView對應到目前頁數的位置
    CGRect imgFrame = CGRectMake(scrollViewWidth*sender.currentPage, 0, scrollViewWidth, scrollViewHeight);
    //捲動到frame的位置
    [scrollView scrollRectToVisible:imgFrame animated:YES];
    //記錄目前頁到pageCounter變數供timer使用(避免自行換頁時，受到timer的干擾)
    pageCounter = (int)pageControl.currentPage;
}

#pragma mark - 自訂方法
-(void)TurnPage
{
    //計算imageView對應到目前頁數的位置
    CGRect imgFrame = CGRectMake(scrollViewWidth*pageCounter, 0, scrollViewWidth, scrollViewHeight);
    //捲動到frame的位置
    [scrollView scrollRectToVisible:imgFrame animated:YES];
    //每次timer來呼叫時，就調整頁數指標
    if (pageCounter < pageControl.numberOfPages - 1)
    {
        pageCounter++;
    }
    else
    {
        pageCounter = 0;
    }
}

#pragma mark - UIScrollViewDelegate
//scrollView發生捲動時
-(void)scrollViewDidScroll:(UIScrollView *)aScrollView
{
    NSLog(@"contentOffset.x=%f,scrollViewWidth=%f",scrollView.contentOffset.x,scrollViewWidth);
    NSLog(@"計算：%f",(scrollView.contentOffset.x - scrollViewWidth / 2) / scrollViewWidth);
    //翻動超過scrollView一半寬度才換頁
    int currentPage;
    double diff = (scrollView.contentOffset.x - scrollViewWidth / 2) / scrollViewWidth;
    if (diff >= 0.5)    //第二頁以上的差值時
    {
        currentPage = ((int)((scrollView.contentOffset.x - scrollViewWidth / 2) / scrollViewWidth)) + 1;
    }
    else if (diff < 0.5 && diff >= -0.5)    //第一頁的差值時
    {
        currentPage = 0;
    }
    //更換目前頁的顯示元件
    pageControl.currentPage = currentPage;
    //記錄目前頁到pageCounter變數供timer使用(避免自行換頁時，受到timer的干擾)
    pageCounter = (int)pageControl.currentPage;
}


@end
