#import <UIKit/UIKit.h>

@interface MyTableViewController : UITableViewController <UISearchResultsUpdating,UISearchBarDelegate>
//記錄從xml解析出來的完整資料表
@property (nonatomic,strong) NSMutableArray *arrTable;
//搜尋後的資料表
@property (nonatomic,strong) NSMutableArray *arrFilteredTable;
//目前選定的儲存格
@property NSInteger selectedRow;
@end
