//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print("Hello, world!")

print("\(str)")
//===========Simple Values===========
var myVariable = 42     //變數可以變更
myVariable = 50
let myConstant = 42     //常數不可變更

//swift會做型別推測
let implicitInteger = 70    //型別：Int
let implicitDouble = 70.0   //型別：Double
let explicitDouble: Double = 70     //明確指定型別為Double

//----------EXPERIMENT 01----------
//作法1
let myFloat: Float=4
//作法2
let aFloat:Float
aFloat = 4
//---------------------------------

//沒有隱性型別轉換，不同型別需自行轉型
let label = "The width is "  //String型別
let width = 94               //Int型別
let widthLabel = label + String(width)

//----------EXPERIMENT 02----------
//let widthLabel2 = label + width
//---------------------------------

//更簡易的方式在字串中插入數值
let apples = 3
let oranges = 5
let appleSummary = "I have \(apples) apples."
let fruitSummary = "I have \(apples + oranges) pieces of fruit."

//----------EXPERIMENT 03----------
//計算某人的BMI值  公式：體重(公斤)/身高(公尺)平方
let bodyHeight = 1.7
let bodyWeight = 60.5
let name = "Perkin"
print("\(name)早安！您的BMI值是：\(bodyWeight/(bodyHeight*bodyHeight))")
let helloString = String(format: "%@早安！您的BMI值是：%.1f", name,bodyWeight/(bodyHeight*bodyHeight))
//---------------------------------

//陣列和詞典都用[]宣告
//陣列的宣告方法
var shoppingList = ["catfish", "water", "tulips", "blue paint"]  //等同OBJC的NSMutableArray
shoppingList[1] = "bottle of water"
shoppingList
//詞典的宣告方法
var occupations = [
    "Malcolm": "Captain",
    "Kaylee": "Mechanic",       //最後逗點結尾也沒關係
]       //等同OBJC的NSMutableDictionary
//加一筆詞典的key-value配對
occupations["Jayne"] = "Public Relations"
//更動value值
occupations["Malcolm"] = "測試！"
occupations

//初始化陣列或詞典的方法：使用型別的初始化語法()  //相當於OBJC的new
let emptyArray = [String]()                //相當於OBJC的NSArray
let emptyDictionary = [String: Float]()    //相當於OBJC的NSDictionary
//當型別可以被推測出來時，可以不指定型別（例如：設定新值給變數，或傳遞參數給某個函式時）
shoppingList = []   //與 [String]() 的作用相同
occupations = [:]    //與 [String:String]() 的作用相同

//=============Control Flow=============
//判斷式和迴圈的()可以省略，但{}部分不可省略！
let individualScores = [75, 43, 103, 87, 12]
var teamScore = 0
for score in individualScores
{
    if score > 50       //條件判斷式必須是Boolean敘述
    {
        teamScore += 3
    }
    else
    {
        teamScore += 1
    }
}
print(teamScore)

//型別後方加上?或!時，該變數的值才可以為nil
var optionalString: String? = "Hello"
//optionalString = nil
print(optionalString == nil)

var optionalName: String? = "John Appleseed"
optionalName = nil      //----------EXPERIMENT 04----------
var greeting = "Hello!"
if let name = optionalName  //name若不為nil時，才會進入{}區段執行
{
    greeting = "Hello, \(name)"
}
//----------EXPERIMENT 04----------
else
{
    greeting = "你好！"
}
//---------------------------------
let nickName: String? = nil
let fullName: String = "John Appleseed"
//以下兩行語法功用相同
let informalGreeting = "Hi \(nickName ?? fullName)"     //swift2的精簡語法
let informalGreeting1 = "Hi \(nickName != nil ? nickName! : fullName)"


var test1:Int?      //包含包裝的變數
var test2:Int!      //自動解開包裝的變數
test1 = 5
//test2 = 6
print("\(test1)")       //未解開包裝
print("\(test1!)")      //解開包裝
print("\(test2)")       //已經自動解開包裝

//switch支援任意型別，而且可以使用比較運算
let vegetable = "red pepper"
switch vegetable
{
case "celery":
    print("Add some raisins and make ants on a log.")
case "cucumber", "watercress":
    print("That would make a good tea sandwich.")
case let x where x.hasSuffix("pepper"):  //x以pepper結尾
    print("Is it a spicy \(x)?")
default:  //----------EXPERIMENT 05----------  //一定要有default
    print("Everything tastes good in soup.")
}

//for-in迴圈可以同時列舉詞典的key和value
let interestingNumbers = [
    "Prime": [2, 3, 5, 7, 11, 13],
    "Fibonacci": [1, 1, 2, 3, 5, 8],
    "Square": [1, 4, 9, 16, 25],
]
//記錄詞典的最大數值
var largest = 0
var largestKind = ""  //----------EXPERIMENT 06----------
//列舉詞典
for (kind, numbers) in interestingNumbers  //當不關心kind變數時，可以把kind改成 ＿
{
    print("\(kind),\(numbers)")
    //列舉陣列
    for number in numbers
    {
        if number > largest
        {
            largest = number
            largestKind = kind //----------EXPERIMENT 06----------
        }
    }
}
print(largest)
print("最大數：\(largest)是\(largestKind)")  //----------EXPERIMENT 06----------

//while迴圈的兩種形式
var n = 2
while n < 100   //直接比對判斷條件
{
    n = n * 2
}
print(n)

var m = 2
repeat           //先執行一次（一般這裡使用do）
{
    m = m * 2
} while m < 100  //才比對判斷條件
print(m)

//for-in迴圈的執行範圍
//以下兩個迴圈的意義相同(不包含上限)
var firstForLoop = 0
for i in 0..<4          //精簡版
{
    firstForLoop += i
}
print(firstForLoop)

var secondForLoop = 0
for var i = 0; i < 4; ++i   //原始版
{
    secondForLoop += i
}
print(secondForLoop)

//以下兩個迴圈的意義相同(包含上限)
var firstForLoop1 = 0
for i in 0...4          //精簡版
{
    firstForLoop1 += i
}
print(firstForLoop1)

var secondForLoop1 = 0
for var i = 0; i <= 4; ++i   //原始版
{
    secondForLoop1 += i
}
print(secondForLoop1)

//=============Functions and Closures================
//定義函式（回傳值在->後方）
func greet(name: String, day: String) -> String
{
    return "Hello \(name), today is \(day)."
}
//呼叫函式
greet("Bob", day: "Tuesday")

//----------EXPERIMENT 07----------
//定義函式
func greet1(name:String,lunch:String) -> String
{
    return "\(name)你好！今日午間特餐是：\(lunch)"
}
//呼叫函式
greet1("Perkin", lunch: "金牌排骨飯")
//---------------------------------

//--------------Tuple(多筆資料的組合)--------------
func calculateStatistics(scores: [Int]) -> (min: Int, max: Int, sum: Int)
{
    var min = scores[0] //記錄陣列最小值
    var max = scores[0] //記錄陣列最大值
    var sum = 0         //記錄陣列總和
    //迴圈在找出陣列中的最大值和最小值，並計算陣列總和
    for score in scores
    {
        if score > max
        {
            max = score
        }
        else if score < min
        {
            min = score
        }
        sum += score
    }
    //一次回傳三筆數字：最大值、最小值、總和
    return (min, max, sum)
}
//statistics為函數所回傳的Tuple型態
let statistics = calculateStatistics([5, 3, 100, 3, 9])
print(statistics.sum)   //使用名稱存取Tuple值
print(statistics.2)     //使用索引存取Tuple值

//函式的參數可以不定個數，不定個數的參數將存放到陣列中
func sumOf(numbers: Int...) -> Int
{
    var sum = 0
    //加總別人傳入的不定個數整數
    for number in numbers       //傳入的參數當做陣列處理
    {
        sum += number
    }
    return sum
}
sumOf()                 //不定個數的參數，也可以不傳參數
sumOf(42, 597, 12)

//----------EXPERIMENT 08----------
//定義一個可以計算參數平均值的函式（參數是不定個數的）
func averageOf(numbers:Int...) -> Double
{
    var sum=0
    for number in numbers
    {
       sum+=number
    }
    //此行錯誤！因為整數除以整數，還是整數
//    return Double(sum/numbers.count)
    return Double(sum)/Double(numbers.count)
}
averageOf(45,50,61,75,80)
//---------------------------------

//可以使用巢狀函式
func returnFifteen() -> Int
{
    var y = 10
    func add()  //定義巢狀函式
    {
        y += 5
    }
    add()       //呼叫巢狀函式
    return y
}
returnFifteen()

//函式的回傳值也可以是一個函式
func makeIncrementer() -> ((Int) -> Int)
{
    //定義一個要回傳的函式
    func addOne(number: Int) -> Int
    {
        return 1 + number
    }
    return addOne
}
//定義一個變數increment去執行makeIncrementer函式
var increment = makeIncrementer()
//使用變數
increment(7)

//函式的參數也可以是一個函式
/*
此函式在找出第一個參數的陣列中是否有任何一個元素，可以符合第二個參數的運作邏輯
*/
func hasAnyMatches(list: [Int], condition: (Int) -> Bool) -> Bool
{
    //列舉第一個參數的陣列
    for item in list
    {
        if condition(item)  //特定的陣列元素是否小於10(此處在呼叫第二個參數的函式)
        {
            return true
        }
    }
    return false
}
//定義用來傳入第二個參數的函式
func lessThanTen(number: Int) -> Bool
{
    //判斷傳入的數字是否小於10
    return number < 10
}
//製作第一個參數的陣列
var numbers = [20, 19, 7, 12]
//呼叫函式傳入第一個參數和第二個參數
hasAnyMatches(numbers, condition: lessThanTen)

//----------使用Closure----------
//針對每一個陣列元素乘以3（『let resultNumbers = 』為承接numbers.map的執行結果）
let resultNumbers = numbers.map({
    (number: Int) -> Int in
    let result = 3 * number
    return result
})
//檢視執行結果
resultNumbers

//----------EXPERIMENT 09----------
//重寫上述的closure部份，當陣列元素是奇數時，回傳0
let resultNumbers1 = numbers.map { (number) -> Int in
    if number%2 != 0
    {
        return 0
    }
    else
    {
        return number
    }
}
//檢視執行結果
resultNumbers1
//---------------------------------

//呼叫Closure可以有好幾種方法
let mappedNumbers = numbers.map({ number in 3 * number })
print(mappedNumbers)

//以下兩段排序方法功用相同
let sortedNumbers = numbers.sort { $0 > $1 }    //精簡版
print(sortedNumbers)
//正常版
let sortedNumbers1 = numbers.sort { (number1:Int, number2:Int) -> Bool in
    number1 < number2
}

//=============Objects and Classes===========
//類別宣告
class Shape
{
    //類別屬性
    var numberOfSides = 0
    //物件方法
    func simpleDescription() -> String
    {
        return "A shape with \(numberOfSides) sides."
    }
    //----------EXPERIMENT 10----------
    let dimension = "3D"
    func whatKindOfModel(name:String) -> String
    {
        return "這是\(name)的\(dimension)模型！"
    }
    //---------------------------------
    //類別方法
    class func ThisIsAClassMethod() -> String
    {
        return "這是類別方法！"
    }
}
//類別初始化
var shape = Shape()
//使用類別屬性
shape.numberOfSides = 7
//呼叫物件方法
var shapeDescription = shape.simpleDescription()
//呼叫物件方法
shape.whatKindOfModel("車子")
//呼叫類別方法
Shape.ThisIsAClassMethod()


class NamedShape
{
    var numberOfSides: Int = 0
    var name: String        //此屬性不能是nil
    //---------不能是nil的屬性，必須初始化---------
    //帶參數的初始化方法
    init(name: String)
    {
        self.name = name
    }
    //簡易初始化方法，不帶參數
    init()
    {
        self.name = ""
    }
    
    deinit  //類別實體被從記憶體移除時
    {
        //清除的程式碼寫在這裡
    }
    
    func simpleDescription() -> String
    {
        return "A shape with \(numberOfSides) sides."
    }
}
//初始化NamedShape類別
let namedShape = NamedShape(name: "形狀")

//繼承自其他類別時
class Square: NamedShape
{
    var sideLength: Double
    
    init(sideLength: Double, name: String)
    {
        self.sideLength = sideLength    //設定自己類別的屬性
        super.init(name: name)      //呼叫父類別的初始化方法
        numberOfSides = 4       //設定父類別的屬性
    }
    
    func area() ->  Double
    {
        return sideLength * sideLength
    }
    
    override func simpleDescription() -> String
    {
        return "A square with sides of length \(sideLength)."
    }
//    override func simpleDescription() -> String
//    {
//        super.simpleDescription()
//        return "test"
//    }
}
let test = Square(sideLength: 5.2, name: "my test square")
test.area()
test.simpleDescription()

//----------EXPERIMENT 11----------
/*
做一個Circle類別，繼承自NamedShape類別
Circle類別的初始化函式要有兩個參數radius和name
再加上兩個物件方法：area()和simpleDescription()
*/
class Circle: NamedShape
{
    var radius:Double
    init(radius:Double,name:String)   //注意:第二個參數預設使用父類別屬性
    {
        self.radius = radius
        super.init(name: name)  //將第二個參數，傳給父類別去初始化
    }
    //計算圓面積
    func area() -> Double
    {
        return radius*radius*M_PI
    }
    
    override func simpleDescription() -> String
    {
        let message = String(format: "%@的半徑：%.1f 圓面積：%.4f)", name,radius,self.area())
        return message
    }
}
let aCircle = Circle(radius: 11, name: "水晶球")
aCircle.simpleDescription()
//--------------------------------------------

//----------使用屬性的setter與getter()----------
class EquilateralTriangle: NamedShape
{
    var sideLength: Double = 0.0    //單邊長度
    
    init(sideLength: Double, name: String)
    {
        self.sideLength = sideLength
        super.init(name: name)
        numberOfSides = 3       //父類別的屬性
    }
    
    var perimeter: Double       //三角形周邊總長度
    {
        get     //將單邊長度乘以三，以復原周邊總長度，並回傳
        {
            return 3.0 * sideLength
        }
        set     //將設定值除以3以後，設定給自己的單邊長度屬性
        {
            sideLength = newValue / 3.0
        }
    }
    
    override func simpleDescription() -> String
    {
        return "An equilateral triangle with sides of length \(sideLength)."
    }
}
var triangle = EquilateralTriangle(sideLength: 3.1, name: "a triangle")
print(triangle.perimeter)   //呼叫perimeter屬性的getter
triangle.perimeter = 9.9    //呼叫perimeter屬性的setter
print(triangle.sideLength)

//屬性即將設值之時與已經設值之時
/*
此類別的triangle和square屬性，邊長必須相等
相等的感應事件為willSet
*/
class TriangleAndSquare
{
    var triangle: EquilateralTriangle
    {
        willSet
        {
            square.sideLength = newValue.sideLength
        }
    }
    var square: Square
    {
        willSet
        {
            triangle.sideLength = newValue.sideLength
        }
    }
    init(size: Double, name: String)
    {
        square = Square(sideLength: size, name: name)
        triangle = EquilateralTriangle(sideLength: size, name: name)
    }
}
var triangleAndSquare = TriangleAndSquare(size: 10, name: "another test shape")
print(triangleAndSquare.square.sideLength)
print(triangleAndSquare.triangle.sideLength)
triangleAndSquare.square = Square(sideLength: 50, name: "larger square")
print(triangleAndSquare.triangle.sideLength)


let optionalSquare: Square? = Square(sideLength: 2.5, name: "optional square")
let sideLength = optionalSquare?.sideLength
print("\(sideLength)")

if let sideLength1 = optionalSquare?.sideLength
{
    print("\(sideLength1)")
}

//===========Enumerations and Structures===========
//撲克牌的數字列舉
enum Rank: Int
{
    case Ace = 1
    case Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten
    case Jack, Queen, King
    func simpleDescription() -> String
    {
        switch self
        {
            case .Ace:  //Rank.Ace
                return "ace"
            case .Jack:
                return "jack"
            case .Queen:
                return "queen"
            case .King:
                return "king"
            default:
                return String(self.rawValue)
        }
    }
}
let ace = Rank.Ace
let aceRawValue = ace.rawValue
ace.simpleDescription()
//----------EXPERIMENT 12----------
func compare(rank1:Rank,rank2:Rank) -> String
{
    var higher:Rank = rank1
    if rank2.rawValue > rank1.rawValue
    {
        higher = rank2
    }
    return "比較結果：\(higher.simpleDescription())較大"
}
compare(Rank.Queen, rank2: Rank.Nine)
//---------------------------------

//花色列舉
enum Suit       //:Int  沒有繼承自Int，無法存取rawValue
{
    case Spades, Hearts, Diamonds, Clubs
    func simpleDescription() -> String
    {
        switch self
        {
        case .Spades:
            return "spades"
        case .Hearts:
            return "hearts"
        case .Diamonds:
            return "diamonds"
        case .Clubs:
            return "clubs"
        }
    }
    //----------EXPERIMENT 13----------
    func color() -> String
    {
        switch self
        {
            case .Clubs,.Spades:
                return "黑色"
            case .Hearts, .Diamonds:
                return "紅色"
        }
    }
    //------------------------------------
}
let hearts = Suit.Hearts
let heartsDescription = hearts.simpleDescription()
hearts.color()   //----------EXPERIMENT 13----------

//結構
struct Card
{
    var rank: Rank  //牌數列舉
    var suit: Suit  //花色列舉
    func simpleDescription() -> String
    {
        return "The \(rank.simpleDescription()) of \(suit.simpleDescription())"
    }
}
let threeOfSpades = Card(rank: .Three, suit: .Spades)  //注意：結構初始化的方法

let threeOfSpadesDescription = threeOfSpades.simpleDescription()







