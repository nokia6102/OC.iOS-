#import <UIKit/UIKit.h>
#import "MyTableViewController.h"  //引入上一頁的類別
@interface DetailViewController : UIViewController <UIPickerViewDelegate,UIPickerViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate,NSURLSessionTaskDelegate>
//接收上一頁傳來的參數(接收參數為上一頁的類別實體)
-(void)passData:(MyTableViewController*)sourceVC;
@end
