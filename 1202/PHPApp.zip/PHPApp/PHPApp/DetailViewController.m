#import "DetailViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>   //使用相簿的Framework
@interface DetailViewController ()
{
    //網路傳輸物件
    NSURLSession *session;
    NSURLSessionDataTask *dataTask;
    //網址字串
    NSString *strURL;
    //網址物件
    NSURL *url;
    //記錄上一頁的類別實體
    MyTableViewController *theSourceVC;
    //存放PickerView的資料來源陣列
    NSArray *arrGender;
    NSArray *arrClass;
    //記錄目前輸入元件的Y軸底部位置
    CGFloat currentObjectBottomYPosition;
    //記錄目前資料的辭典
    NSMutableDictionary *dicRow;
    //記錄檔案的上傳狀態
    Boolean isFileUploaded;
}
@property (weak, nonatomic) IBOutlet UILabel *lblNo;
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UIImageView *imgPicture;
@property (weak, nonatomic) IBOutlet UIPickerView *pkvGender;
@property (weak, nonatomic) IBOutlet UITextField *txtPhone;
@property (weak, nonatomic) IBOutlet UITextField *txtAddress;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UIPickerView *pkvClass;
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;
@property UIImagePickerController *imgPicker;
@end

@implementation DetailViewController
@synthesize lblNo,txtName,imgPicture,pkvGender,txtPhone,txtAddress,txtEmail,pkvClass,progressView,imgPicker;
#pragma mark - View Life Cycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    //預設檔案已上傳
    isFileUploaded = YES;
    //加入點按手勢收回鍵盤
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(CloseKeyboard)];
    [self.view addGestureRecognizer:tapGesture];
    //初始化Y軸底部位置
    currentObjectBottomYPosition = 0;
    //註冊鍵盤的監聽事件
    //1.鍵盤彈出
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboadrdWillShow:) name:UIKeyboardWillShowNotification object:nil];
    //2.鍵盤收合
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboadrdWillHide:) name:UIKeyboardWillHideNotification object:nil];
    //指定session configuration
    NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
    //變數初始化
    session = [NSURLSession sessionWithConfiguration:sessionConfiguration delegate:self delegateQueue:nil];
    //初始化PickerView的資料來源陣列
    arrGender = @[@"女",@"男"];
    arrClass = @[@"手機程式開發",@"網頁程式設計"];
    //指派代理人
    pkvGender.delegate = self;
    pkvGender.dataSource = self;
    pkvClass.delegate = self;
    pkvClass.dataSource = self;
    NSLog(@"上一頁點選了:%lu",theSourceVC.selectedRow);
    //顯示對應筆數的資料
    lblNo.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"no"];
    txtName.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"name"];
    txtPhone.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"phone"];
    txtAddress.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"address"];
    txtEmail.text = theSourceVC.arrTable[theSourceVC.selectedRow][@"email"];
    //選定資料欄位中的對應性別
    [pkvGender selectRow:[theSourceVC.arrTable[theSourceVC.selectedRow][@"gender"] integerValue] inComponent:0 animated:YES];
    //取得班別資料
    NSString *myClass = theSourceVC.arrTable[theSourceVC.selectedRow][@"class"];
    //迴圈跑arrClass陣列的內容
    for (int i=0; i<arrClass.count; i++)
    {
        //進行陣列內容與班別資料欄位的比對
        if ([arrClass[i] isEqualToString:myClass])
        {
            //比對arrClass陣列當筆的內容，如果與當筆資料欄位相同，則選定該筆
            [pkvClass selectRow:i inComponent:0 animated:YES];
        }
    }
    //======================顯示照片======================
    //準備圖片網址（譬如：http://perkinsung.2fh.co/images/101.jpg）
    strURL = [NSString stringWithFormat:@"http://perkinsung.2fh.co/%@",theSourceVC.arrTable[theSourceVC.selectedRow][@"picture"]];
    //    NSLog(@"圖片路徑：%@",strURL);
    //將圖片網址製成NSURL
    url = [NSURL URLWithString:strURL];
    //製作網路任務
    dataTask = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable imageData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //顯示圖片
            imgPicture.image = [UIImage imageWithData:imageData];
        });
        
    }];
    //執行網路任務
    [dataTask resume];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Target Action
//收起鍵盤的Did End On Exit觸發事件
- (IBAction)didEndOnExit:(id)sender
{
    [sender resignFirstResponder];
}

//更換照片
- (IBAction)btnChangePhoto:(UIButton *)sender
{
    //標示照片未上傳
    isFileUploaded = NO;
    //初始化挑選照片的畫面
    imgPicker = [UIImagePickerController new];
    //指派代理人
    imgPicker.delegate = self;
    //辨識imgPicker的識別文字
    imgPicker.title = @"album";
    //指定使用的媒體為相簿
    imgPicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    //允許對照片進行編輯  注意：需配合挑選完成的代理事件中的info[UIImagePickerControllerEditedImage]
    imgPicker.allowsEditing = YES;
    //開啟相簿
    [self presentViewController:imgPicker animated:YES completion:nil];
}
//拍照
- (IBAction)btnCamera:(UIButton *)sender
{
    //檢查裝置是否支援相機
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])  //不支援相機時（注意驚嘆號）
    {
        //準備訊息視窗
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"找不到相機" message:@"無法使用相機" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
        //顯示訊息視窗
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    //標示照片未上傳
    isFileUploaded = NO;
    //初始化挑選照片的畫面
    imgPicker = [UIImagePickerController new];
    //指派代理人
    imgPicker.delegate = self;
    //辨識imgPicker的識別文字
    imgPicker.title = @"camera";
    //指定使用的媒體為相機
    imgPicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    //指定取用相機的功能
    imgPicker.mediaTypes = @[(NSString *)kUTTypeImage];  //影片 @[kUTTypeMovie]
    //允許對照片進行編輯  注意：需配合挑選完成的代理事件中的info[UIImagePickerControllerEditedImage]
    imgPicker.allowsEditing = YES;
    //開啟相簿
    [self presentViewController:imgPicker animated:YES completion:nil];
}
//檔案上傳
- (IBAction)btnUploadPhoto:(UIButton *)sender
{
    //制定上傳檔名（第四個參數）
    NSString *serverFileName = [NSString stringWithFormat:@"%@.jpg",lblNo.text];
    //取得上傳服務的網址（第二個參數）
    strURL = @"http://perkinsung.2fh.co/photo_upload.php";
    //呼叫檔案上傳封裝方法
    [self FileUpload:imgPicture.image withURLString:strURL byFormInputID:@"userfile" andNewFileName:serverFileName];
    //============刪除已cache住的檔案============
    //宣告檔案管理員
    NSFileManager *fm = [NSFileManager new];
    //取得Caches所在的路徑
    NSString *cachesPath = [NSString stringWithFormat:@"%@/Library/Caches",NSHomeDirectory()];
    //刪除暫存檔案
    [fm removeItemAtPath:cachesPath error:nil];
}
//更新資料
- (IBAction)btnUpdateData:(UIButton *)sender
{
    if ([txtName.text isEqualToString:@""] || [txtAddress.text isEqualToString:@""] || [txtPhone.text isEqualToString:@""] || [txtEmail.text isEqualToString:@""])
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"輸入資料缺漏" message:@"所有資料皆不可空白" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDestructive handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    if (!imgPicture.image)
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"缺少圖片" message:@"尚未選擇照片" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDestructive handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }

    //製作要送交伺服器的update_data.php(需代入參數以更新table資料)
    NSString *strOriginalURL = [NSString stringWithFormat:@"http://perkinsung.2fh.co/update_data.php?name=%@&gender=%lu&phone=%@&address=%@&email=%@&class=%@&no=%@",txtName.text,[pkvGender selectedRowInComponent:0],txtPhone.text,txtAddress.text,txtEmail.text,arrClass[[pkvClass selectedRowInComponent:0]],lblNo.text];
    //將網址用UTF8編碼，以避免中文在網址上的辨識問題
//    strURL = [strOriginalURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    strURL = [strOriginalURL stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
    //製作NSURL物件
    url = [NSURL URLWithString:strURL];
    //設定網路任務
    dataTask = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable echoData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSString *strEchoMessage = [[NSString alloc] initWithData:echoData encoding:NSUTF8StringEncoding];
        //如果伺服器更新成功時，還多傳出其他訊息時，必須做字串擷取
        strEchoMessage = [strEchoMessage substringWithRange:NSMakeRange(0, 1)];
        
        if ([strEchoMessage isEqualToString:@"1"])
        {
            //Todo:建議加上更新中的動畫
            
            dispatch_async(dispatch_get_main_queue(), ^{
                //準備訊息視窗
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"伺服器回應" message:@"資料修改成功" preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
                //顯示訊息視窗
                [self presentViewController:alert animated:YES completion:nil];
            });
            //-----------同步更新上一頁的陣列資料-----------
            //取得目前資料的詞典
            dicRow = theSourceVC.arrTable[theSourceVC.selectedRow];
            //逐一更動詞典對應的值
            dicRow[@"name"] = txtName.text;
            dicRow[@"phone"] = txtPhone.text;
            dicRow[@"address"] = txtAddress.text;
            dicRow[@"email"] = txtEmail.text;
            dicRow[@"gender"] = [NSString stringWithFormat:@"%i",(int)[pkvGender selectedRowInComponent:0]];
            dicRow[@"class"] = arrClass[[pkvClass selectedRowInComponent:0]];
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                //準備訊息視窗
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"伺服器回應" message:@"資料修改失敗" preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDestructive handler:nil]];
                //顯示訊息視窗
                [self presentViewController:alert animated:YES completion:nil];
            });
        }
    }];
    //執行網路任務
    [dataTask resume];
}

#pragma mark - 自訂方法
//接收上一頁傳來的參數(接收參數為上一頁的類別實體)
-(void)passData:(MyTableViewController*)sourceVC
{
    //記錄上ㄧ頁的實體到全域變數（供viewDidLoad顯示資料時使用）
    theSourceVC = sourceVC;
    NSLog(@"上一頁的陣列：%@",sourceVC.arrTable);
}

//收起鍵盤
-(void)CloseKeyboard
{
    for (UIView *view in self.view.subviews)
    {
        if ([view isKindOfClass:[UITextField class]])
        {
            //如果是UITextField的類別實體，則收起鍵盤
            [view resignFirstResponder];
        }
    }
}

//監聽鍵盤所呼叫的事件-鍵盤彈出
-(void)keyboadrdWillShow:(NSNotification*)sender
{
    NSLog(@"鍵盤彈出");
    //================把畫面往上移================
    //取得通知中心的資料
    NSDictionary *userInfo = sender.userInfo;
    if (userInfo)
    {
        //從通知中心的資料中取得鍵盤高度
        CGFloat keyboardHeight = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
        if (keyboardHeight > 0)
        {
            //計算可視高度
            CGFloat visibleHeight = self.view.frame.size.height - keyboardHeight;
            NSLog(@"鍵盤彈出後的可視高度：%f",visibleHeight);
            //計算可視高度與特定元件的Y軸底緣之間的差值(正值表示元件被遮住了)
            CGFloat diffHeight = currentObjectBottomYPosition - visibleHeight;
            if (diffHeight > 0)     //如果有遮住才移動
            {
                //整個View往上移動其差值
                [UIView animateWithDuration:0.25 animations:^{
                    self.view.frame = CGRectMake(0, -(diffHeight+20), self.view.frame.size.width, self.view.frame.size.height);
                }];
            }
        }
    }
}

//監聽鍵盤所呼叫的事件-鍵盤收合
-(void)keyboadrdWillHide:(NSNotification*)sender
{
    NSLog(@"鍵盤收合");
    //把View移回原來的位置
    [UIView animateWithDuration:0.25 animations:^{
        self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    }];
}

//一旦開始編輯，就取得該元件的Y軸底部位置
- (IBAction)FieldTouched:(UITextField*)sender
{
    //計算目前元件的Y軸底端位置
    currentObjectBottomYPosition = sender.frame.origin.y + sender.frame.size.height;
    NSLog(@"Y軸底端位置：%f",currentObjectBottomYPosition);
}

//檔案上傳封裝方法(第一個參數：已選定的圖片，第二個參數：處理上傳檔案的photo_upload.php，第三個參數：提交檔案的input file id，第四個參數：存放到伺服器端的檔名)
-(void)FileUpload:(UIImage*)image withURLString:(NSString*)urlString byFormInputID:(NSString*)idName andNewFileName:(NSString*)newFileName
{
    //轉換圖檔成為NSData(壓縮jpg)
    NSData *imageData = UIImageJPEGRepresentation(image, 0.5);
    //準備URLRequest
    NSMutableURLRequest *request = [NSMutableURLRequest new];
    //從參數取得上傳檔案的網址
    request.URL = [NSURL URLWithString:urlString];
    request.HTTPMethod = @"POST";
    
    //產生boundary識別碼來界定要傳送的資料
    NSString *boundary = [NSProcessInfo processInfo].globallyUniqueString;
    
    //設定HTTP header當中的Content-Type
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType forHTTPHeaderField:@"Content-Type"];
    
    //準備Post Body
    NSMutableData *body = [NSMutableData new];
    
    //以boundary識別碼來製作分隔界線（開始）
    NSString *boundaryStart = [NSString stringWithFormat:@"\r\n--%@\r\n", boundary];
    //Post Body加入分隔界線（開始）
    [body appendData:[boundaryStart dataUsingEncoding:NSUTF8StringEncoding]];
    
    //加入Form
    NSString *formData = [NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n", idName, newFileName];    //此行的userfile需對應到接收上傳的php內變數名稱，newFileName為上傳後存檔的名稱
    //Post Body加入Form
    [body appendData:[formData dataUsingEncoding:NSUTF8StringEncoding]];
    
    //檔案型態
//    NSString *fileType = [NSString stringWithFormat:@"Content-Type: application/octet-stream\r\n\r\n"];
    NSString *fileType = @"Content-Type: application/octet-stream\r\n\r\n";
    [body appendData:[fileType dataUsingEncoding:NSUTF8StringEncoding]];
    
    //加入圖檔
    [body appendData:imageData];
    
    //以boundary識別碼來製作分隔界線（結束）
    NSString *boundaryEnd = [NSString stringWithFormat:@"\r\n--%@--\r\n", boundary];
    //Post Body加入分隔界線（結束）
    [body appendData:[boundaryEnd dataUsingEncoding:NSUTF8StringEncoding]];
    
    //把Post Body交給URL Reqeust
    request.HTTPBody = body;
    
    //設定上傳任務
    dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable echoData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        //注意：一定要呼叫dispatch_async轉回主執行緒才更新UI，否則會影響顯示效能
        dispatch_async(dispatch_get_main_queue(), ^{
            //取得伺服器上傳檔案的回應訊息
            NSString *strEchoMessage = [[NSString alloc] initWithData:echoData encoding:NSUTF8StringEncoding];
            if ([strEchoMessage isEqualToString:@"success"])
            {
                //標示檔案已上傳
                isFileUploaded = YES;
            }
        });
    }];
    //執行上傳任務
    [dataTask resume];
}

#pragma mark - UIPickerViewDelegate
//<方法二>回傳『每一列』中用來顯示的文字（使用自訂文字格式）
-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    //初始化一個UILabel
    UILabel *myView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, pickerView.frame.size.width, pickerView.frame.size.height)];
    //準備顯在myView的文字
    if (pickerView.tag == 0)
    {
        myView.text = arrGender[row];
    }
    else
    {
        myView.text = arrClass[row];
    }
    //調整myView文字屬性
    myView.textAlignment = NSTextAlignmentLeft;
    myView.font = [UIFont systemFontOfSize:16];
    return myView;
}

#pragma mark - UIPickerViewDataSource
//一個PickerView有幾個滾輪
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    //只要一個滾輪
    return 1;
}
//每個滾輪有幾筆資料
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    //<方法一>利用tag判斷不同的pickerView
    if (pickerView.tag == 0)
    {
        return arrGender.count;
    }
    else
    {
        return arrClass.count;
    }
    //<方法二>利用property判斷不同的pickerView
    //    if (pkvGender == pickerView)
    //    {
    //        return arrGender.count;
    //    }
    //    else
    //    {
    //        return arrClass.count;
    //    }
}

#pragma mark - UIImagePickerControllerDelegate
//從相機或相簿挑選好照片或影片之後
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    //將挑選好的照片顯示出來
    if ([picker.title isEqualToString:@"camera"])
    {//如果是相機過來呼叫
        //使用編輯過後的圖
        imgPicture.image = info[UIImagePickerControllerEditedImage];
    }
    else
    {//如果是相簿過來呼叫
        //使用原圖
        imgPicture.image = info[UIImagePickerControllerOriginalImage];
    }
    //退掉挑選照片的畫面
    [picker dismissViewControllerAnimated:YES completion:^{
        //清空挑選圖片的物件
        imgPicker = nil;
    }];
}

#pragma mark - NSURLSessionTaskDelegate
-(void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didSendBodyData:(int64_t)bytesSent totalBytesSent:(int64_t)totalBytesSent totalBytesExpectedToSend:(int64_t)totalBytesExpectedToSend
{
    dispatch_async(dispatch_get_main_queue(), ^{
        //顯示進度元件
        progressView.hidden = NO;
        //計算目前上傳進度
        float currentProgress = (float)totalBytesSent / (float)totalBytesExpectedToSend;
        //顯示上傳進度
        [progressView setProgress:currentProgress animated:YES];
    });
}

@end
