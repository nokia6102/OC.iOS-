#import "MyTableViewController.h"
#import "MyTableViewCell.h"             //自訂儲存格的類別
#import "DetailViewController.h"        //下一頁的類別
#import "AddViewController.h"

@interface MyTableViewController ()
{
    //網路傳輸物件
    NSURLSession *session;
    NSURLSessionDataTask *dataTask;
    //網址字串
    NSString *strURL;
    //網址物件
    NSURL *url;
    //記錄xml開始標籤的名稱
    NSString *tagName;
    //記錄xml的標籤內容
    NSString *tagContent;
    //記錄從xml解析出來的單一資料行
    NSMutableDictionary *dicRow;
    //下一頁的畫面
    DetailViewController *detailVC;
    //篩選資料的key
    NSString *filterKey;
    //搜尋控制器
    UISearchController *searchController;
}

@end

@implementation MyTableViewController
@synthesize arrTable,arrFilteredTable,selectedRow;
#pragma mark - View Life Cycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"根目錄：%@",NSHomeDirectory());
    //變數初始化
    session = [NSURLSession sharedSession];
    selectedRow = -1;
    dicRow = [NSMutableDictionary new];
    arrTable = [NSMutableArray new];
    arrFilteredTable = [NSMutableArray new];
    
    //從網站上重新取得MySQL資料庫資料
    [self getTableDataFromWeb];
    
    //在導覽列上加上左右按鈕
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"編輯" style:UIBarButtonItemStylePlain target:self action:@selector(btnEditPressed:)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"新增" style:UIBarButtonItemStylePlain target:self action:@selector(btnAddPressed:)];
    //加上navigationItem的標題<方法一>
    self.navigationItem.title = @"PHP App";
    //更改titleView<方法二>
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"paging.jpg"]];
//    imageView.frame = self.navigationItem.titleView.frame;
    imageView.frame = CGRectMake(0, 0, 400, 30);
    self.navigationItem.titleView = imageView;
    
    //設定搜尋控制器
    searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    searchController.searchResultsUpdater = self;  //引入UISearchResultsUpdating協定
    searchController.dimsBackgroundDuringPresentation = NO;
    searchController.searchBar.scopeButtonTitles = @[@"姓名",@"學號",@"性別"];
    searchController.searchBar.delegate = self;     //引入UISearchBarDelegate協定
    //加入搜尋bar
    self.tableView.tableHeaderView = searchController.searchBar;
    self.definesPresentationContext = YES;  //注意：缺少此行會造成搜尋從下一頁返回時，搜尋列上方空白
    [searchController.searchBar sizeToFit];
    //預設以姓名搜尋
    filterKey = @"name";
    
    //初始化下拉更新元件
    self.refreshControl = [UIRefreshControl new];
    self.refreshControl.attributedTitle = [[NSAttributedString alloc] initWithString:@"更新中..."];
    [self.refreshControl addTarget:self action:@selector(handleRefresh) forControlEvents:UIControlEventValueChanged];
    //=====以下兩行需同時運作，才能讓TableView調回原點位置，蓋住更新元件的位置，而且搜尋列不會被更新元件蓋住=====
    //調整tableView的偏移量，往上減回更新元件的高度
    self.tableView.contentOffset = CGPointMake(0, -self.refreshControl.frame.size.height);
    //將TableView調回原點位置
    self.tableView.frame = CGRectMake(0, 0, self.tableView.frame.size.width, self.tableView.frame.size.height-self.refreshControl.frame.size.height);
}
//這段可能不需要！
//-(void)viewWillDisappear:(BOOL)animated
//{
//    [super viewWillDisappear:animated];
//    //隱藏searchController
//    if (searchController.active)
//    {
//        searchController.active = NO;
//        [searchController.searchBar removeFromSuperview];
//    }
//}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//準備轉換到下一頁
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    //從導覽箭頭取得下一頁的畫面
    detailVC = segue.destinationViewController;
    //呼叫下一頁『接收上一頁參數』的方法
    [detailVC passData:self];
}

//view即將重現
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //重整tableView的資料
    [self.tableView reloadData];
}

#pragma mark - Target Action
//編輯按鈕
-(void)btnEditPressed:(UIBarButtonItem*)sender
{
    if (self.tableView.editing)
    {
        self.tableView.editing = NO;
        sender.title = @"編輯";
    }
    else
    {
        self.tableView.editing = YES;
        sender.title = @"完成";
    }
}

//新增按鈕
-(void)btnAddPressed:(UIBarButtonItem*)sender
{
    //加入一個新增資料的畫面
    AddViewController *addVC = [self.storyboard instantiateViewControllerWithIdentifier:@"AddViewController"];
    [addVC passData:self];
    [self presentViewController:addVC animated:YES completion:nil];
}

#pragma mark - 自訂函式
-(void)handleRefresh
{
    //進行更新資料程序：從網站上重新取得MySQL資料庫資料
    [self getTableDataFromWeb];
    //資料更新結束
    [self.refreshControl endRefreshing];
}

//從網站上重新取得MySQL資料庫資料
-(void)getTableDataFromWeb
{
    //先清空陣列資料
    [arrTable removeAllObjects];
    //取得網站上的xml，並且進行解析
    strURL = @"http://perkinsung.2fh.co/select_data.php";
    //製作NSURL物件
    url = [NSURL URLWithString:strURL];
    //製作網路任務
    dataTask = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable xmlData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        //啟動xml解析
        NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithData:xmlData];
        xmlParser.delegate = self;
        [xmlParser parse];
    }];
    //執行網路任務
    [dataTask resume];
}

#pragma mark - Table view data source
//TableView有幾個區段(預設值是一個區段)
//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
//{
//    return 1;
//}

//每一段有幾筆資料
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//    NSLog(@"有幾筆資料：%lu",(unsigned long)arrTable.count);
    if (!searchController.active)
    {
        return arrTable.count;
    }
    else
    {
        return arrFilteredTable.count;
    }
}

//準備每一筆的TableView儲存格資料
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyCell" forIndexPath:indexPath];
    if (!searchController.active)
    {
        cell.lblNo.text = arrTable[indexPath.row][@"no"];
        cell.lblName.text = arrTable[indexPath.row][@"name"];
        
        if ([arrTable[indexPath.row][@"gender"] intValue] == 0)
        {
            cell.lblGender.text = @"女";
        }
        else
        {
            cell.lblGender.text = @"男";
        }
        //準備圖片網址（譬如：http://perkinsung.2fh.co/images/101.jpg）
        strURL = [NSString stringWithFormat:@"http://perkinsung.2fh.co/%@",arrTable[indexPath.row][@"picture"]];
    }
    else
    {
        cell.lblNo.text = arrFilteredTable[indexPath.row][@"no"];
        cell.lblName.text = arrFilteredTable[indexPath.row][@"name"];
        
        if ([arrFilteredTable[indexPath.row][@"gender"] intValue] == 0)
        {
            cell.lblGender.text = @"女";
        }
        else
        {
            cell.lblGender.text = @"男";
        }
        //準備圖片網址（譬如：http://perkinsung.2fh.co/images/101.jpg）
        strURL = [NSString stringWithFormat:@"http://perkinsung.2fh.co/%@",arrFilteredTable[indexPath.row][@"picture"]];
    }
    //將圖片網址製成NSURL
    url = [NSURL URLWithString:strURL];
    //製作網路任務
    dataTask = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable imageData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //顯示圖片
            cell.imgPicture.image = [UIImage imageWithData:imageData];
        });
    }];
    //執行網路任務
    [dataTask resume];
    
    return cell;
}

#pragma mark - Table view delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    NSLog(@"點選了：%lu",indexPath.row);

    //記錄目前點選的儲存格是哪一行
    selectedRow = indexPath.row;
    
    NSLog(@"點選了：%lu",selectedRow);
}

//=====================以下兩個代理事件必須互相配合，才能移動、交換儲存格=====================
//讓儲存格可以移動
-(BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

//移動儲存格時
-(void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{
    //同時對調陣列資料
    [arrTable exchangeObjectAtIndex:sourceIndexPath.row withObjectAtIndex:destinationIndexPath.row];
}

//===========================
//編輯過儲存格的時候
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Step0.刪除MySQL的資料(一定要先做！)
    //取得刪除網站
    strURL = [NSString stringWithFormat:@"http://perkinsung.2fh.co/delete_data.php?no=%@",arrTable[indexPath.row][@"no"]];
    //製作NSURL物件
    url = [NSURL URLWithString:strURL];
    //製作刪除任務
    dataTask = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable echoData, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSString *strEchoMessage = [[NSString alloc] initWithData:echoData encoding:NSUTF8StringEncoding];
        //如果伺服器更新成功時，還多傳出其他訊息時，必須做字串擷取
        strEchoMessage = [strEchoMessage substringWithRange:NSMakeRange(0, 1)];
        
        if ([strEchoMessage isEqualToString:@"1"])
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                //準備訊息視窗
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"伺服器回應" message:@"資料刪除成功" preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:nil]];
                //顯示訊息視窗
                [self presentViewController:alert animated:YES completion:nil];
            });
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                //準備訊息視窗
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"伺服器回應" message:@"資料刪除失敗" preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDestructive handler:nil]];
                //顯示訊息視窗
                [self presentViewController:alert animated:YES completion:nil];
            });
        }
    }];
    //執行刪除任務
    [dataTask resume];

    //注意:Step1.和Step2.的順序不可以相反！
    //Stpe1.刪除該儲存格對應的陣列資料
    [arrTable removeObjectAtIndex:indexPath.row];
    //Step2.刪除TableView上對應的儲存格
    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
}
//滑動時要出現的按鈕
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //出現刪除按鈕
    return UITableViewCellEditingStyleDelete;
}


#pragma mark - NSXMLParserDelegate
//找到開始標籤
-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict
{
    NSLog(@"開始標籤：%@",elementName);
    //記下開始標籤
    tagName = elementName;
}
//找到標籤內容
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)strContent
{
    NSLog(@"標籤內容：%@",strContent);
    //記下標籤內容
    tagContent = strContent;
}
//找到結束標籤
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    NSLog(@"結束標籤：%@",elementName);
    if ([elementName isEqualToString:@"student"])  //整筆資料的結束標籤
    {
        //將一整本詞典寫入陣列
        [arrTable addObject:dicRow];
        //清除整本詞典(Swift可以不寫這行！)
        dicRow = [NSMutableDictionary new];
    }
    else if ([elementName isEqualToString:@"xmlTable"])  //不關心的結束標籤
    {
        //不處理
    }
    else  //欄位的結束標籤
    {
        //逐一將欄位寫入詞典
        dicRow[tagName] = tagContent;
    }
}
//讀完整份xml文件
-(void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"讀完了!");
    NSLog(@"陣列內容：%@",arrTable);
    //轉回主執行才能更動UI的資料
    dispatch_async(dispatch_get_main_queue(), ^{
        //更新tableView的資料
        [self.tableView reloadData];
    });
}

#pragma mark - UISearchResultsUpdating
//開始篩選資料
-(void)updateSearchResultsForSearchController:(UISearchController *)aSearchController
{
//    arrFilteredTable = [NSMutableArray new];
    [arrFilteredTable removeAllObjects];
    //取得正在搜尋的字串
    NSString *strCurrentSearching = searchController.searchBar.text;
    //先處理性別字串
    if ([filterKey isEqualToString:@"gender"])
    {
        if ([strCurrentSearching isEqualToString:@"男"])
        {
            strCurrentSearching = @"1";
        }
        else
        {
            strCurrentSearching = @"0";
        }
    }
    //設定搜尋條件
    NSPredicate *searchPredict = [NSPredicate predicateWithFormat:@"%K contains[cd] %@",filterKey,strCurrentSearching];
    //依條件篩選陣列
    arrFilteredTable = [[arrTable filteredArrayUsingPredicate:searchPredict] mutableCopy];
    //重整tableView的資料
    [self.tableView reloadData];
}

#pragma mark - UISearchBarDelegate
//點選搜尋分類按鈕
-(void)searchBar:(UISearchBar *)searchBar selectedScopeButtonIndexDidChange:(NSInteger)selectedScope
{
    //@"姓名",@"學號",@"性別"
    switch (selectedScope)
    {
        case 0:  //姓名按鈕
            filterKey = @"name";
            break;
        case 1:  //學號按鈕
            filterKey = @"no";
            break;
        case 2:  //性別按鈕
            filterKey = @"gender";
            break;
        default:
            filterKey = @"name";
            break;
    }
    //開始搜尋
    [self updateSearchResultsForSearchController:searchController];
}

@end
