import UIKit

class MyTableViewController: UITableViewController,NSXMLParserDelegate,UISearchResultsUpdating,UISearchBarDelegate
{
    //網路傳輸物件
    let session = NSURLSession.sharedSession()  //初始化
    var dataTask:NSURLSessionDataTask!
    //記錄xml的標籤名稱
    var tagName = ""
    //記錄xml的標籤內容
    var tagContent = ""
    //記錄從xml解析出來的單一資料行
    var dicRow = [String:String]()
    //記錄從xml解析出來的完整資料表
    var arrTable = [[String:String]]()
    //下一頁的畫面
    var detailVC:DetailViewController!
    //目前選定的儲存格
    var selectedRow = -1
    //網址字串
    var strURL = ""
    //網址物件
    var url:NSURL!
    //搜尋控制器
    var searchController:UISearchController!
    //篩選資料的key(預設搜尋姓名，即詞典的key值為name)
    var filterKey = "name"
    //搜尋後的資料表陣列
    var arrFilteredTable = [[String:String]]()
    //MARK: View Life Cycle
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //在導覽列上加上左右按鈕
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "編輯", style: UIBarButtonItemStyle.Plain, target: self, action: "btnEditPressed:")
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "新增", style: UIBarButtonItemStyle.Plain, target: self, action: "btnAddPressed:")
        //從網站上取得MySQL資料庫資料
        self.getTableDataFromWeb()
        //設定搜尋控制器
        searchController = UISearchController(searchResultsController: nil);
        searchController.searchResultsUpdater = self   //此行必須引入search協定
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.scopeButtonTitles = ["姓名","學號","性別"]
        searchController.searchBar.delegate = self
        //加入搜尋bar
        self.tableView.tableHeaderView = searchController.searchBar
        self.definesPresentationContext = true  //注意：此行缺少會造成搜尋後從下一頁返回時，搜尋列上方空白！
        searchController.searchBar.sizeToFit()
        //初始化下拉更新元件
        self.refreshControl = UIRefreshControl()
        self.refreshControl!.attributedTitle = NSAttributedString(string: "更新中...");
        self.refreshControl?.addTarget(self, action: "handleRefresh", forControlEvents: UIControlEvents.ValueChanged)
        //避免加入下拉更新元件後，上方空白或searchBar被遮蓋(注意：以下兩行缺一不可！缺少第二行會先看到更新元件)
        self.tableView.contentOffset = CGPointMake(0, -self.refreshControl!.frame.size.height)
        self.tableView.frame = CGRectMake(0, 0, self.tableView.frame.size.width, self.tableView.frame.size.height-self.refreshControl!.frame.size.height)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //非常重要！
    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        //重載tableView的資料
        self.tableView.reloadData()
//        //通知要重繪tableView
//        self.tableView.setNeedsDisplay()
//        //立即更新表格顯示資料
//        self.tableView.layoutIfNeeded()
    }
    
    override func viewWillDisappear(animated: Bool)
    {
        super.viewWillDisappear(animated)
        //隱藏searchController
        if searchController.active
        {
            searchController.active = false
            searchController.searchBar.removeFromSuperview()
        }
    }
    
    //即將轉到下一頁
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
//        print("prepareForSegue")
        //取得下一頁畫面
        detailVC = segue.destinationViewController as! DetailViewController
    }
    
    //MARK: 自訂方法
    //從網站上取得MySQL資料庫資料
    func getTableDataFromWeb()
    {
        //==================取得網站服務的資訊有兩種方法==================
        //<方法一>取得網站上的xml，並且進行解析
//                strURL = "http://perkinsung.honor.es/select_data.php"
        //        strURL = "http://www.studio-pj.com/class_exercise/select_data.php"
        //        url = NSURL(string: strURL)!
        //        dataTask = session.dataTaskWithURL(url) { (xmlData, response, error) -> Void in
        //            //啟動xml解析
        //            let xmlParser = NSXMLParser(data: xmlData!)
        //            xmlParser.delegate = self
        //            xmlParser.parse()
        //        }
        
        //<方法二>取得網站上的JSon資料
        strURL = "http://perkinsung.honor.es/select_to_json.php"
//        strURL = "http://www.studio-pj.com/class_exercise/select_to_json.php"
        url = NSURL(string: strURL)!
        dataTask = session.dataTaskWithURL(url) { (jsonData, response, error) -> Void in
            self.arrTable = (try? NSJSONSerialization.JSONObjectWithData(jsonData!, options: NSJSONReadingOptions.MutableContainers)) as! Array
            //轉回主要執行緒更新介面上的資料
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.tableView.reloadData()
            })
        }
        //執行連線任務（<方法一>或<方法二>）
        dataTask.resume()
    }
    
    //由下拉更新元件呼叫的方法
    func handleRefresh()
    {
        //開始更新資料：從網站上取得MySQL資料庫資料
        self.getTableDataFromWeb()
        //資料更新結束
        self.refreshControl?.endRefreshing()
    }
    
    //編輯按鈕
    func btnEditPressed(sender:UIBarButtonItem)
    {
        if self.tableView.editing == true
        {
            self.tableView.editing = false
            sender.title = "編輯"
        }
        else
        {
            self.tableView.editing = true
            sender.title = "完成"
        }
    }
    //新增按鈕
    func btnAddPressed(sender:UIBarButtonItem)
    {
        //從Storyboard載入新增畫面
        let addVC = self.storyboard!.instantiateViewControllerWithIdentifier("AddViewController") as! AddViewController
        //將自己傳給下一頁
        addVC.passData(sourceViewController: self)
        //顯示新增畫面
        self.presentViewController(addVC, animated: true, completion: nil)
    }


    //MARK: UITableViewDelegate
    //表格有幾個區段
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    //資料筆數
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        print("陣列筆數：\(arrTable.count)");
        //注意：此處發生於網路解析資料完成之前，所以資料解析完成時，必需重整tableView資料
        if !searchController.active
        {
            return arrTable.count
        }
        else
        {
            return arrFilteredTable.count;
        }
    }

    //準備每一個儲存格
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("MyCell", forIndexPath: indexPath) as! MyTableViewCell
        //下一頁指示符號
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        if !searchController.active
        {
            //顯示資料
            cell.lblNo.text = arrTable[indexPath.row]["no"]
            cell.lblName.text = arrTable[indexPath.row]["name"]
            if arrTable[indexPath.row]["gender"] == "1"
            {
                cell.lblGender.text = "男"
            }
            else
            {
                cell.lblGender.text = "女"
            }
            //以非同步方式取得欄位圖片
            strURL = String(format: "http://perkinsung.honor.es/%@", self.arrTable[indexPath.row]["picture"]!)
//            strURL = String(format: "http://www.studio-pj.com/class_exercise/%@", self.arrTable[indexPath.row]["picture"]!)
        }
        else
        {
            //顯示資料
            cell.lblNo.text = arrFilteredTable[indexPath.row]["no"]
            cell.lblName.text = arrFilteredTable[indexPath.row]["name"]
            if arrFilteredTable[indexPath.row]["gender"] == "1"
            {
                cell.lblGender.text = "男"
            }
            else
            {
                cell.lblGender.text = "女"
            }
            //以非同步方式取得欄位圖片
            strURL = String(format: "http://perkinsung.honor.es/%@", self.arrFilteredTable[indexPath.row]["picture"]!)
//            strURL = String(format: "http://www.studio-pj.com/class_exercise/%@", self.arrFilteredTable[indexPath.row]["picture"]!)
        }
        url = NSURL(string: strURL)!
        //制定資料傳輸任務以取得圖片
        dataTask = session.dataTaskWithURL(url, completionHandler: { (imageData, response, error) -> Void in
            //注意：一定要呼叫dispatch_async轉回主執行緒，否則會影響顯示效能
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                cell.imgPicture.image = UIImage(data: imageData!)
//                //需要重繪儲存格
//                cell.setNeedsDisplay()
//                //立即重繪儲存格
//                cell.layoutIfNeeded()
            })
        })
        //執行資料傳輸
        dataTask.resume()
        
        return cell
    }
    
    //MARK: UITableViewDelegate
    //儲存格被點選時
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
//        print("點選第\(indexPath.row)格")
        selectedRow = indexPath.row
        //傳參數到下一頁(將目前的類別實體傳遞給下一頁)
        detailVC.passData(sourceViewController: self)
    }
    
    //===============以下兩個代理事件必須互相配合，才能移動、交換儲存格===============
    //讓儲存格可以移動
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool
    {
        return true
    }
    
    //移動儲存格時
    override func tableView(tableView: UITableView, moveRowAtIndexPath sourceIndexPath: NSIndexPath, toIndexPath destinationIndexPath: NSIndexPath)
    {
        //同時對調陣列資料
        swap(&arrTable[sourceIndexPath.row], &arrTable[destinationIndexPath.row])
    }
    
    //===============以下兩個代理事件必須互相配合，才能讓滑動的刪除按鈕作用===============
    //允許滑動時出現刪除按鈕
    override func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle
    {
        return UITableViewCellEditingStyle.Delete
    }
    //實際刪除該筆資料
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath)
    {
        //1.從資料庫刪除該筆資料
        //原始的刪除網址
        let strOriginalURL = String(format: "http://perkinsung.honor.es/delete_data.php?no=%@", arrTable[indexPath.row]["no"]!)
//        let strOriginalURL = String(format: "http://studio-pj.com/class_exercise/delete_data.php?no=%@", arrTable[indexPath.row]["no"]!)
        //將原始網址作Unicode編碼
        strURL = strOriginalURL.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLFragmentAllowedCharacterSet())!
        //將編碼後的網址製作成URL物件
        url = NSURL(string: strURL)!
        //製作網路資料刪除任務
        dataTask = session.dataTaskWithURL(url, completionHandler: { (echoData, response, error) -> Void in
            //讀取伺服器回傳訊息
            let strEchoMessage = String(NSString(data: echoData!, encoding: NSUTF8StringEncoding)!)
            if strEchoMessage == "1"
            {
                let alert = UIAlertController(title: "伺服器回應", message: "資料刪除成功！", preferredStyle: UIAlertControllerStyle.Alert)
                alert.addAction(UIAlertAction(title: "確定", style: UIAlertActionStyle.Default, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)
            }
            else
            {
                let alert = UIAlertController(title: "伺服器回應", message: "資料刪除失敗！", preferredStyle: UIAlertControllerStyle.Alert)
                alert.addAction(UIAlertAction(title: "確定", style: UIAlertActionStyle.Destructive, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)
            }
        })
        //執行刪除
        dataTask.resume()
        //2.將該筆陣列資料刪除
        arrTable.removeAtIndex(indexPath.row)
        //3.實際刪除表格中的一列，並選擇喜歡的刪除動畫
        self.tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Top)
    }
    
    //MARK: NSXMLParserDelegate
    //抓到xml開始標籤
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        //print("開始標籤：\(elementName)")
        tagName = elementName
    }
    
    //讀取xml標籤內容
    func parser(parser: NSXMLParser, foundCharacters string: String)
    {
        //print("標籤內容：\(string!)")
        tagContent = string
    }
    //抓到結束xml標籤
    func parser(parser: NSXMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        //        print("結束標籤：\(elementName),標籤內容：\(tagContent)")
        //當elementName為資料行時，將字典存入陣列
        if elementName == "student"
        {
            //將整本詞典寫入陣列
            arrTable.append(dicRow)
            //清空辭典(注意：swift的詞典key-value特性為覆蓋，所以也可以不必清空)
            dicRow = [String:String]()      //此行在swift可以省略（OBJC不可省略！）
        }
        else if elementName == "xmlTable"
        {
            //不做事
        }
            //當elementName為欄位時，將欄位存入字典
        else
        {
            //製作辭典key-value配對
            dicRow[elementName] = tagContent    //或是：dicRow[tagName] = tagContent
        }
    }
    //xml解析器已完成資料解析
    func parserDidEndDocument(parser: NSXMLParser)
    {
        print("讀完了！");
        //        print("\(arrTable.count)")
        //        print("\(arrTable)")
        //轉回主要執行緒，重新載入TableView資料
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            self.tableView.reloadData()
        }
    }
    
    //MARK: UISearchResultUpdating
    //開始搜尋
    func updateSearchResultsForSearchController(aSearchController: UISearchController)
    {
        arrFilteredTable.removeAll()
        //取得正在搜尋的字串
        var strCurrentSearching = aSearchController.searchBar.text!
        //先處理性別字串，需轉回0或1
        if filterKey == "gender"
        {
            if aSearchController.searchBar.text == "男"
            {
                strCurrentSearching = "1"
            }
            else
            {
                strCurrentSearching = "0"
            }
        }
        //        //依條件篩選陣列<寫法一>
        //        arrFilteredTable = arrTable.filter() {
        //            ($0[filterKey]?.containsString(strCurrentSearching))!
        //        }
        //依條件篩選陣列<寫法二>
        arrFilteredTable = arrTable.filter { (aDicRow) -> Bool in
            return (aDicRow[filterKey]?.containsString(strCurrentSearching))!
        }
        //重整表格檢視資料
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            self.tableView.reloadData()
        }
    }
    //點選搜尋分類鈕
    func searchBar(searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int)
    {
        //依使用者選定的搜尋按鈕，設定要針對詞典內的哪個key去搜尋
        switch selectedScope
        {
        case 0:
            filterKey = "name"
        case 1:
            filterKey = "no"
        case 2:
            filterKey = "gender"
        default:
            filterKey = "name"
        }
        //開始搜尋
        self.updateSearchResultsForSearchController(searchController)
    }

}
