import UIKit
import MobileCoreServices  //供imagePicker的mediaType使用
import CoreLocation
import MapKit

class DetailViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,NSURLSessionTaskDelegate
{
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var lblNo: UILabel!
    @IBOutlet weak var imgPicture: UIImageView!
    @IBOutlet weak var pkvGender: UIPickerView!
    @IBOutlet weak var pkvClass: UIPickerView!
    @IBOutlet weak var btnChangePhoto: UIButton!
    
    //PickerView的資料來源
    let arrGender = ["女","男"]
    let arrClass = ["手機程式開發","網頁程式設計"]
    //記錄來源VC
    var theSourceVC:MyTableViewController!
    //記錄目前的字典資料
    var dicRow = [String:String]()
    //圖片挑選器
    var imgPicker:UIImagePickerController!
    //記錄目前輸入元件的Y軸底部位置
    var currentObjectBottomYPosition:CGFloat = 0.0
    //判斷檔案是否上傳
    var isFileUploaded = true
    //網路傳輸物件
    var session:NSURLSession!
    var dataTask:NSURLSessionDataTask!
    //網址字串
    var strURL:String!
    //網址物件
    var url:NSURL!
    //MARK: View Life Cycle
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //隱藏上傳進度條
        progressView.hidden = true
        //指定pickerView的代理人
        pkvGender.delegate = self
        pkvGender.dataSource = self
        pkvClass.delegate = self
        pkvClass.dataSource = self
        //加上點按手勢收起鍵盤
        let tapGesture = UITapGestureRecognizer(target: self, action: "CloseKeyBoard")
        self.view.addGestureRecognizer(tapGesture)
        //監聽鍵盤顯示
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillShow:", name: UIKeyboardWillShowNotification, object: nil)
        //監聽鍵盤收合
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillHide:", name: UIKeyboardWillHideNotification, object: nil)
        //語系本地化
        //NSLocalizedString("btnChangePhoto", tableName: "InfoPlist", bundle: NSBundle.mainBundle(), value: "", comment: "")
        btnChangePhoto.setTitle(NSLocalizedString("btnChangePhoto", tableName: "InfoPlist", bundle: NSBundle.mainBundle(), value: "", comment: ""), forState: UIControlState.Normal)
        //=======================顯示上一頁資料=======================
        //取得目前這一筆資料的字典
        dicRow = theSourceVC.arrTable[theSourceVC.selectedRow]
        //將資料顯示於介面上
        lblNo.text = dicRow["no"]
        txtName.text = dicRow["name"]
        txtAddress.text = dicRow["address"]
        txtPhone.text = dicRow["phone"]
        txtEmail.text = dicRow["email"]
        //選定對應的性別
        pkvGender.selectRow((dicRow["gender"]! as NSString).integerValue, inComponent: 0, animated: false)
        //選定對應的班別
        for (arrIndex,item) in arrClass.enumerate()
        {
            if item == dicRow["class"]
            {
                pkvClass.selectRow(arrIndex, inComponent: 0, animated: false)
            }
            //println("(\(arrIndex),\(item))")
        }
        
        //---------------------顯示圖片---------------------
        //1.初始化網路傳輸物件    *very important!
        let sessionConfiguration = NSURLSessionConfiguration.defaultSessionConfiguration()
        session = NSURLSession(configuration: sessionConfiguration, delegate: self, delegateQueue: nil)
        //2.制定資料傳輸任務
        strURL = "http://perkinsung.honor.es/" + dicRow["picture"]!
//        strURL = "http://www.studio-pj.com/class_exercise/" + dicRow["picture"]!
        url = NSURL(string: strURL)
        dataTask = session.dataTaskWithURL(url!, completionHandler: { (imageData, response, error) -> Void in
            //注意：一定要呼叫dispatch_async轉回主執行緒，否則會嚴重影響顯示效能
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.imgPicture.image = UIImage(data: imageData!)
            })
        })
        //2.執行資料傳輸
        dataTask.resume()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK: Target Action
    //更換照片
    @IBAction func btnSelectPicture(sender: UIButton)
    {
        //初始化imgPicker
        imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        //指定使用相簿
        imgPicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
//        imgPicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum
        //允許裁切照片
        imgPicker.allowsEditing = true
        //開啟相簿
        self.presentViewController(imgPicker, animated: true, completion: nil)
        //標示檔案未上傳
        isFileUploaded = false
        //隱藏進度條
        self.progressView.hidden = true
    }
    //上傳照片
    @IBAction func btnFileUpload(sender: UIButton!)
    {
        //制定上傳檔名
        let serverFileName = String(format: "%@.jpg", lblNo.text!)
        //取得上傳服務的網址
        strURL = "http://perkinsung.honor.es/photo_upload.php"
//        strURL = "http://www.studio-pj.com/class_exercise/photo_upload.php"
        //呼叫檔案上傳封裝方法
        FileUpload(imgPicture.image!, withURLString: strURL, byFormInputID: "userfile", andNewFileName: serverFileName)
//        //===================清除cache資料（防止App一直讀到舊的圖片）===================
//        //宣告檔案管理員
//        let fm = NSFileManager()
//        //取得Caches所在路徑
//        let cachesPath = String(format: "%@/Library/Caches", NSHomeDirectory())
//        //刪除暫存檔案
//        let _ = try? fm.removeItemAtPath(cachesPath)
    }
    //拍照
    @IBAction func btnOpenCamera(sender: UIButton)
    {
        //初始化imgPicker
        imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        //檢查裝置是否支援相機
        if !UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        {
            let alert = UIAlertController(title: "找不到設備", message: "無法使用相機", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "確定", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            return
        }
        //指定使用相機
        imgPicker.sourceType = UIImagePickerControllerSourceType.Camera
        //指定相機的功能
        imgPicker.mediaTypes = [String(kUTTypeImage)]
        //允許裁切照片
        imgPicker.allowsEditing = true
        //開啟相機
        self.presentViewController(imgPicker, animated: true, completion: nil)
        //標示檔案未上傳
        isFileUploaded = false
    }
    //帶我去
    @IBAction func btnMapNavigation(sender: UIButton)
    {
        //宣告地址與經緯度轉換的物件
        let geocoder = CLGeocoder()
        //取得目的地住址
        let strAddress = txtAddress.text
        //將目的地住址轉為經緯度
        geocoder.geocodeAddressString(strAddress!, completionHandler: { (placemarks, error) -> Void in
            if error != nil
            {
                print("地址轉換發生錯誤！")
                return
            }
            //取出住址的經緯度
            let toPlaceMark: CLPlacemark = placemarks![0]
            //將經緯度轉為地圖上的大頭針
            let toPin = MKPlacemark(placemark: toPlaceMark)
            //指定導航模式
            let option = [MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving]
            //產生地圖上的大頭針
            let destMapItem = MKMapItem(placemark: toPin)
            //從現在位置導航到目的地
            destMapItem.openInMapsWithLaunchOptions(option)
        })
    }
    //更新資料
    @IBAction func btnSaveData(sender: UIButton)
    {
        //原始的網址(注意：性別需代入%d)
        let strOriginalURL = String(format: "http://perkinsung.honor.es/update_data.php?name=%@&gender=%d&phone=%@&address=%@&email=%@&class=%@&no=%@",txtName.text!,pkvGender.selectedRowInComponent(0),txtPhone.text!,txtAddress.text!,txtEmail.text!,arrClass[pkvClass.selectedRowInComponent(0)],lblNo.text!)
//        let strOriginalURL = String(format: "http://www.studio-pj.com/class_exercise/update_data.php?name=%@&gender=%d&phone=%@&address=%@&email=%@&class=%@&no=%@",txtName.text!,pkvGender.selectedRowInComponent(0),txtPhone.text!,txtAddress.text!,txtEmail.text!,arrClass[pkvClass.selectedRowInComponent(0)],lblNo.text!)
        //網址編碼（避免中文亂碼）
        strURL = strOriginalURL.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLFragmentAllowedCharacterSet())!
        //傳送網址
        url = NSURL(string: strURL)
        //設定更新任務
        dataTask = session.dataTaskWithURL(url!, completionHandler: { (echoData, response, error) -> Void in
            //如果伺服器為付費主機，不會傳出額外訊息時
            //            let strEchoMessage = String(NSString(data: echoData, encoding: NSUTF8StringEncoding)!)
            //如果伺服器更新成功時，還多傳出其他訊息時，必須做字串擷取
            let strEchoMessage = String(NSString(data: echoData!, encoding: NSUTF8StringEncoding)!.substringWithRange(NSMakeRange(0, 1)))
            if strEchoMessage == "1"
            {
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    let alert = UIAlertController(title: "伺服器回應", message: "資料修改成功", preferredStyle: UIAlertControllerStyle.Alert)
                    alert.addAction(UIAlertAction(title: "確定", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)
                });
                //同步異動上一頁arrTable內對應的資料（返回時viewWillAppear需做tableView資料重載）
                self.theSourceVC.arrTable[self.theSourceVC.selectedRow]["name"] = self.txtName.text
                self.theSourceVC.arrTable[self.theSourceVC.selectedRow]["phone"] = self.txtPhone.text
                self.theSourceVC.arrTable[self.theSourceVC.selectedRow]["address"] = self.txtAddress.text
                self.theSourceVC.arrTable[self.theSourceVC.selectedRow]["email"] = self.txtEmail.text
                self.theSourceVC.arrTable[self.theSourceVC.selectedRow]["gender"] = String(self.pkvGender.selectedRowInComponent(0))
                self.theSourceVC.arrTable[self.theSourceVC.selectedRow]["class"] = self.arrClass[self.pkvClass.selectedRowInComponent(0)]
                //如果檔案未上傳
                if !self.isFileUploaded  //注意驚嘆號
                {
                    //按一下『上傳檔案』按鈕
                    self.btnFileUpload(nil)
                }
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    let alert = UIAlertController(title: "伺服器回應", message: "資料修改失敗", preferredStyle: UIAlertControllerStyle.Alert)
                    alert.addAction(UIAlertAction(title: "確定", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)
                });
            }
        })
        //執行更新任務
        dataTask.resume()
        //更新上一頁的儲存格畫面
        theSourceVC.tableView.reloadRowsAtIndexPaths([NSIndexPath(forRow: theSourceVC.selectedRow, inSection: 0)], withRowAnimation: UITableViewRowAnimation.None)
        
    }
    //按下return鍵收起鍵盤
    @IBAction func didEndOnExit(sender: UITextField)
    {
        sender.resignFirstResponder()
    }
    
    //點選輸入欄位時 (連結：Editing Did Begin）
    @IBAction func FieldTouched(sender: UITextField)
    {
        //計算目前元件的y軸底端位置
        currentObjectBottomYPosition = sender.frame.origin.y + sender.frame.size.height
//        print("元件的y軸底端位置:\(currentObjectBottomYPosition)")
    }
    
    //MARK: 自訂方法
    //接收上一頁傳來的參數(這裏不能動UI)
    func passData(sourceViewController sourceVC:MyTableViewController)
    {
//        print("上一頁的陣列：\(sourceVC.arrTable)")
        //將來源VC記錄到全域變數
        theSourceVC = sourceVC
    }
    
    //收回鍵盤（配合view上的點按手勢）
    func CloseKeyBoard()
    {
        //請所有會喚起鍵盤的物件都要交出第一回應權
        for subView in self.view.subviews
        {
            if subView is UITextField
            {
                subView.resignFirstResponder()
            }
        }
    }
    
    //鍵盤顯示時被呼叫的事件
    func keyboardWillShow(sender:NSNotification)
    {
        print("鍵盤顯示")
        //取得通知中心的資料
        if let userInfo = sender.userInfo
        {
            //從通知中心的資料去取得鍵盤高度
            if let keyboardHeight = userInfo[UIKeyboardFrameEndUserInfoKey]?.CGRectValue.size.height
            {
                print("鍵盤彈出後的可視高度：\(self.view.frame.height - keyboardHeight)")
                //如果『元件所在位置的底緣高度』比『鍵盤彈出後的可視高度』還高
                if currentObjectBottomYPosition > self.view.frame.height - keyboardHeight
                {
                    //計算兩者間的差值，並移動view的高度位置
                    //currentObjectBottomYPosition - (self.view.frame.height - keyboardHeight)
                    UIView.animateWithDuration(0.25, animations: { () -> Void in
                        self.view.frame = CGRectMake(0, -(self.currentObjectBottomYPosition - (self.view.frame.height - keyboardHeight)+20), self.view.frame.width, self.view.frame.height)
                    })
                }
            }
        }
    }
    
    //鍵盤收合時被呼叫的事件
    func keyboardWillHide(sender:NSNotification)
    {
        print("鍵盤收合")
        //view回復到原來位置
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            self.view.frame = CGRectMake(0, 0, self.view.frame.width, self.view.frame.height)
        })
        //將元件的底緣位置歸零
        currentObjectBottomYPosition = 0
    }
    
    //檔案上傳封裝方法(第一個參數：已選定的圖片，第二個參數：處理上傳檔案的photo_upload.php，第三個參數：提交檔案的input file id，第四個參數：存放到伺服器端的檔名)
    func FileUpload(image:UIImage,withURLString urlString:String,byFormInputID idName:String,andNewFileName newFileName:String)
    {
        //轉換圖檔成為NSData(壓縮jpg)
        let imageData:NSData = UIImageJPEGRepresentation(image, 0.5)!
        //準備URLRequest
        let request = NSMutableURLRequest()     //注意不能寫成：var request = NSURLRequest()
        //從參數取得上傳檔案的網址
        request.URL = NSURL(string: urlString)
        request.HTTPMethod = "POST"
        
        //產生boundary識別碼來界定要傳送的資料
        let boundary = NSProcessInfo.processInfo().globallyUniqueString
        // set Content-Type in HTTP header
        let contentType = "multipart/form-data; boundary=" + boundary
        request.addValue(contentType, forHTTPHeaderField: "Content-Type")
        
        //準備Post Body
        let body = NSMutableData()
        
        //以boundary識別碼來製作分隔界線（開始）
        let boundaryStart = String(format: "\r\n--%@\r\n", boundary)
        //Post Body加入分隔界線（開始）
        body.appendData(boundaryStart.dataUsingEncoding(NSUTF8StringEncoding)!)
        
        //加入Form
        let formData = String(format: "Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n", idName, newFileName)    //此行的userfile需對應到接收上傳的php內變數名稱，newFileName為上傳後存檔的名稱
        //Post Body加入Form
        body.appendData(formData.dataUsingEncoding(NSUTF8StringEncoding)!)
        
        //檔案型態
        let fileType = String(format: "Content-Type: application/octet-stream\r\n\r\n")
        body.appendData(fileType.dataUsingEncoding(NSUTF8StringEncoding)!)
        
        //加入圖檔
        body.appendData(imageData)
        
        //以boundary識別碼來製作分隔界線（結束）
       let boundaryEnd = String(format: "\r\n--%@--\r\n", boundary)
        //Post Body加入分隔界線（結束）
        body.appendData(boundaryEnd.dataUsingEncoding(NSUTF8StringEncoding)!)
        
        //把Post Body交給URL Reqeust
        request.HTTPBody = body
        
        //設定上傳任務
        dataTask = session.dataTaskWithRequest(request, completionHandler: { (echoData, response, error) -> Void in
            //取得伺服器上傳檔案的回應訊息
            let strEchoMessage = String(NSString(data: echoData!, encoding: NSUTF8StringEncoding)!)
            if strEchoMessage == "success"
            {
                //標示檔案已上傳
                self.isFileUploaded = true
            }
        })
        //執行上傳任務
        dataTask.resume()
    }
    
    //MARK: UIPickerViewDataSource
    //滾輪數量
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    //可滾動的資料行數
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if pickerView.tag == 0
        {
            return arrGender.count
        }
        else
        {
            return arrClass.count
        }
    }
    
    //MARK: UIPickerViewDelegate
    //<方法一>單一滾輪上顯示的資料（使用預設文字）
//    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String!
//    {
//        if pickerView.tag == 0
//        {
//            return arrGender[row]
//        }
//        else
//        {
//            return arrClass[row]
//        }
//    }
    //<方法二>單一滾輪上顯示的資料（自行製作顯示文字的view）
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView
    {
        //初始化一個UILabel(長寬與PickerView一樣)
        let myView = UILabel(frame: CGRectMake(0, 0, pickerView.frame.size.width, pickerView.frame.size.height))
        if pickerView.tag == 0
        {
//            return arrGender[row]
            myView.text = arrGender[row]
        }
        else
        {
//            return arrClass[row]
            myView.text = arrClass[row]
        }
        //設定Label的屬性
        myView.textAlignment = NSTextAlignment.Left
        myView.font = UIFont.systemFontOfSize(16)
        myView.backgroundColor = UIColor.clearColor()
        return myView
    }
    
    //MARK: UIImagePickerControllerDelegate
    //選定圖片之後
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo: [NSObject : AnyObject]!)
    {
        //顯示圖片
        imgPicture.image = image
        //退掉圖片挑選畫面
        self.dismissViewControllerAnimated(true, completion: { () -> Void in
            //Todo: 記錄檔案的上傳狀態
            
            //清除imgPicker
            self.imgPicker = nil
        })
    }
    //MARK: NSURLSessionTaskDelegate
    func URLSession(session: NSURLSession, task: NSURLSessionTask, didSendBodyData bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
        dispatch_async(dispatch_get_main_queue()) { () -> Void in
            //顯示進度元件
            self.progressView.hidden = false
            //計算目前上傳進度
            let currentProgress = Float(totalBytesSent) / Float(totalBytesExpectedToSend)
            //顯示上傳進度
            self.progressView.setProgress(currentProgress, animated: true)
        }
    }
    
}
